<?php
return [

    // 1 - Cấu hình bot telegram gửi contact

    "telegram_bot_token" => "7727156334:AAGtVUO8sFT756f-BPs5oJtD0z03AnHKPRY", // Telegram BOT
    "telegram_chat_id" => "-4587638305", // Group gửi contact

    // 2 - Cấu hình Logo
    "logo_dark" => "/assets/customs/logo-dark.png",
    "logo_white" => "/assets/customs/logo-white.png",
    "fav" => "/assets/customs/fav.png",

    // 3 - Cấu hình thông tin công ty
    "address" => "XQQP+46C, Dau Alley, Mo Lao Ward, Ha Dong District, Hanoi City, Vietnam",
    "mail" => "info@example.com",
    "phone" => "+84909090909",


    // 4 - Cấu hình Socials công ty
    "web_name" => "Hiu Agency",
    "telegram1" => "https://t.me/fuwatu_Agency",
    "telegram2" => "https://t.me/Hana1609_AG",
    "facebook" => "https://fb.com",
    "whatsapp" => "https://wa.me/0976857256",
    "instagram" => 'https://www.instagram.com/adsasia.pro'

];