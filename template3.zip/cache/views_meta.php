<?php class_exists('Template') or exit; ?>
