<?php class_exists('Template') or exit; ?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8" />
    <title> <?php echo $title ?> </title>
    <meta
        content="Experience seamless digital advertising solutions with AdsAsia. We help businesses scale campaigns, drive growth, and achieve long-term success efficiently."
        name="description" />
    <meta content="Agency Accounts &amp; Advertising Solutions | AdsAsia" property="og:title" />
    <meta
        content="Experience seamless digital advertising solutions with AdsAsia. We help businesses scale campaigns, drive growth, and achieve long-term success efficiently."
        property="og:description" />
    <meta
        content="assets/img1.png"
        property="og:image" />
    <meta content="Agency Accounts &amp; Advertising Solutions | AdsAsia" property="twitter:title" />
    <meta
        content="Experience seamless digital advertising solutions with AdsAsia. We help businesses scale campaigns, drive growth, and achieve long-term success efficiently."
        property="twitter:description" />
    <meta
        content="assets/img1.png"
        property="twitter:image" />
    <meta property="og:type" content="website" />
    <meta content="summary_large_image" name="twitter:card" />
    <meta content="width=device-width, initial-scale=1" name="viewport" />
    <link href="https://cdn.prod.website-files.com/668b3733f80ed0dcd2c46207/css/agency-aurora.shared.dc0bd0013.min.css"
        rel="stylesheet" type="text/css" />
    <link href="https://fonts.googleapis.com" rel="preconnect" />
    <link href="https://fonts.gstatic.com" rel="preconnect" crossorigin="anonymous" />
    <script src="https://ajax.googleapis.com/ajax/libs/webfont/1.6.26/webfont.js" type="text/javascript"></script>
    <script
        type="text/javascript">WebFont.load({ google: { families: ["Plus Jakarta Sans:200,300,regular,500,600,700,800,200italic,300italic,italic,500italic,600italic,700italic,800italic", "Plus Jakarta Sans:regular:cyrillic-ext,latin,latin-ext"] } });</script>
    <script
        type="text/javascript">!function (o, c) { var n = c.documentElement, t = " w-mod-"; n.className += t + "js", ("ontouchstart" in o || o.DocumentTouch && c instanceof DocumentTouch) && (n.className += t + "touch") }(window, document);</script>
    <link rel="shortcut icon" type="image/x-icon" href="assets/imgs/template/favicon.svg">

    <script>
        window.dataLayer = window.dataLayer || [];
        function gtag() { dataLayer.push(arguments); }
        gtag('js', new Date());
        gtag('config', 'G-P88VC5CC9W');
    </script>
    <script src="https://unpkg.com/three@0.149.0/build/three.js"></script>
    <script src="https://unpkg.com/three-globe@2.25.1/dist/three-globe.min.js"></script>
    <style>
        /**
    .aurora-box {
        transform: rotate3d(0, 2, 1, 45deg);
    }
    .bg-container {
            -webkit-transform: scaleX(-1);
        transform: scaleX(-1);
    }**/

    .i18n-switcher select {
  background: transparent;
  color: #fff;       /* đổi theo nền navbar của bạn */
  border: 1px solid rgba(255,255,255,.25);
  padding: 6px 10px;
  border-radius: 6px;
  font-size: 14px;
  outline: none;
}
.i18n-switcher select:focus {
  border-color: #ff4d4f; /* màu nhấn */
}
@media (max-width: 768px) {
  .i18n-switcher select {
      background: #00000085;   /* màu nền bạn muốn */
      color: #fff;             /* chữ trắng cho dễ đọc */
      border: 1px solid #444;  /* viền nhẹ */
  }
}


        .hero-toggle,
        .hero-logo-icon-box {
            display: none;
            transition: transform 200ms ease-in-out, opacity 200ms ease-in-out, background-color 200ms ease-in-out;
        }

        .moving-icon {
            transition: transform 200ms ease-in-out, opacity 200ms ease-in-out;
        }

        .hero-toggle.no-dice {
            display: block;
            transition: transform 300ms ease-in-out;
        }

        .hero-option {
            transform: scale(0);
            transition: background-color .2s ease-in-out, color .2s ease-in-out, transform 200ms ease-in-out, opacity 200ms ease-in-out;
        }

        .move-top {
            transform: translate(0, -100%);
        }

        #gimmick {
            display: block;
            pointer-events: none;
            position: absolute;
            top: 0;
            left: 0;
        }

        [data-whitelist-logo] {
            transition: opacity 200ms ease-in-out, transform 200ms ease-in-out;
        }

        [data-anim-show-up],
        [data-whitelist-content],
        [data-whitelist-image-box],
        [data-load="box"] {
            transition: opacity 500ms ease-in-out, transform 500ms ease-in-out;
        }

        [data-anim-ad-box][data-show="false"],
        [data-feature-image-box][data-show="false"],
        [data-anim-show-up][data-show="false"],
        [data-whitelist-image-box][data-show="false"],
        [data-load="box"][data-show="false"] {
            opacity: 0;
            transform: translate(0, 50px);
        }

        [data-whitelist-content][data-show="false"] {
            opacity: 0;
        }

        [data-whitelist-logo][data-show="false"] {
            opacity: 0;
            transform: scale(0.2);
        }
    </style>
    <link href="https://cdn.jsdelivr.net/npm/@splidejs/splide@4.1.4/dist/css/splide.min.css" rel="stylesheet">
    <style>
        .splide__track {
            overflow: visible;
        }

        .splide__arrow {
            z-index: -999;
        }

        .splide__arrows {
            opacity: 0;
        }

        .splide__pagination {
            bottom: 0;
            bottom: 0;
            position: relative;
            justify-content: flex-start;
            margin-top: 1.5rem;
        }

        .splide:not(.is-overflow) .splide__pagination {
            max-width: 1600px;
            position: relative;
            display: flex;
            justify-content: flex-start;
            padding: 0;
        }

        .splide__pagination__page {
            background-color: #475467;
            border-radius: 100%;
            width: .75rem;
            height: .75rem;
            opacity: 1;
            margin: 0;
        }

        .splide__pagination__page.is-active {
            background: #e9394b;
            transform: scale(1);
            z-index: 1;
        }

        /**
    .aurora-box {
        transform: rotate3d(0, 2, 1, 45deg);
    }
    .bg-container {
            -webkit-transform: scaleX(-1);
        transform: scaleX(-1);
    }**/
    </style>

     
</head>

<body>



    <div class="page-wrapper">
        <div class="global-styles w-embed">
            <style>
                /*Scroll Bar Style*/
                /*width*/
                ::-webkit-scrollbar {
                    width: 5px;
                }

                /*track*/
                ::-webkit-scrollbar-track {
                    background: white;
                }

                /*thumb*/
                ::-webkit-scrollbar-thumb {
                    background: #E9394B;
                }

                /*Custom Highlight Color on Select*/

                ::-moz-selection {
                    /* Firefox */
                    color: #ffffff;
                    background: #E9394B;
                }

                ::selection {
                    color: #ffffff;
                    background: #E9394B;
                }

                html {
                    font-size: calc(0.5rem + 0.41666666666666663vw);
                }

                @media screen and (max-width:1920px) {
                    html {
                        font-size: calc(0.49999999999999994rem + 0.41666666666666674vw);
                    }
                }

                @media screen and (max-width:1440px) {
                    html {
                        font-size: calc(0.8126951092611863rem + 0.20811654526534862vw);
                    }
                }

                @media screen and (max-width:479px) {
                    html {
                        font-size: calc(0.7494769874476988rem + 0.8368200836820083vw);
                    }
                }

                /* Make text look crisper and more legible in all browsers */
                body {
                    -webkit-font-smoothing: antialiased;
                    -moz-osx-font-smoothing: grayscale;
                    font-smoothing: antialiased;
                    text-rendering: optimizeLegibility;
                }

                /* Get rid of top margin on first element in any rich text element */
                .w-richtext> :not(div):first-child,
                .w-richtext>div:first-child> :first-child {
                    margin-top: 0 !important;
                }

                /* Get rid of bottom margin on last element in any rich text element */
                .w-richtext>:last-child,
                .w-richtext ol li:last-child,
                .w-richtext ul li:last-child {
                    margin-bottom: 0 !important;
                }

                /*Reset buttons, and links styles*/
                a {
                    color: inherit;
                    text-decoration: inherit;
                    font-size: inherit;
                }

                /* Apply "..." after 3 lines of text */
                .text-style-3lines {
                    display: -webkit-box;
                    overflow: hidden;
                    -webkit-line-clamp: 3;
                    -webkit-box-orient: vertical;
                }

                /* Apply "..." after 2 lines of text */
                .text-style-2lines {
                    display: -webkit-box;
                    overflow: hidden;
                    -webkit-line-clamp: 2;
                    -webkit-box-orient: vertical;
                }

                /*  Identify Blank Links 
    [href="#"] {
    color: red;
    outline: 3px solid red;
    }
    */

                /* Hide Section if it has no CMS Items inside (Give section an attribute name of data-cms-section)*/

                [data-cms-section]:not(:has(.w-dyn-item)) {
                    display: none;
                }

                .nav-red-line {
                    display: none;
                }

                /** , .nav-link-box:has(.w--open) > .nav-red-line **/
                .nav-link-box:has(.w--current)>.nav-red-line {
                    display: block;
                }

                .nav-link-box:has(.w--current) .nav-dropdown-toggle,
                .nav-link-box:has(.w--current) .nav-text-link,
                .nav-link-box:has(.w--current) .white-link {
                    font-weight: 600;
                    color: #fff;
                }

                .transparent-bg,
                .hero-account-item {
                    -webkit-backdrop-filter: blur(5px);
                    backdrop-filter: blur(5px);
                }

                .hide-this {
                    display: none;
                }

                .meta-hero-slider {
                    gap: 0;
                }

                .onboarding-button:disabled,
                .onboarding-button[disabled],
                .onboarding-button[data-disabled="true"] {
                    background-color: #f8abb3;
                    cursor: default;
                }

                [data-onboard-arrow="open"] {
                    transform: rotate(180deg);
                }

                .onboarding-block-two[data-fill-page="open"] {
                    flex-grow: 1;
                }

                [data-button-all="hide"] {
                    display: none;
                }

                [data-user-icon] {
                    border-spacing: 0;
                    transition: transform 500ms ease-in-out, color 200ms ease-in-out, opacity 500ms ease-in-out;
                }

                [data-box-scale="small"] {
                    opacity: 0;
                    transform: scale(0);
                }

                [data-user-icon="hover"] {
                    color: #1018281a;
                }

                [data-dropdown] {
                    transform: translateX(-100%);
                    transition: transform 200ms ease-in-out;
                }

                .dropdown-link:hover [data-dropdown] {
                    transform: translate(0);
                }

                .error-message,
                .error-box {
                    display: none;
                }

                .footer-field.error+.error-box,
                .footer-field.error+.error-message {
                    color: #FDA29B;
                }

                .footer-field.warning+.error-box,
                .footer-field.warning+.error-message {
                    color: #FEF0C7;
                }

                .footer-field.success+.error-message {
                    color: #75E0A7;
                }

                .footer-field.error+.error-message,
                .footer-field.warning+.error-message,
                .footer-field.success+.error-message {
                    display: block;
                }

                .footer-field.error+.error-box,
                .footer-field.warning+.error-box {
                    display: flex;
                }

                @media screen and (max-width: 991px) {
                    .navbar:has(.w--open) .nav-menu-block {
                        margin-left: 0;
                    }

                    .nav-menu-block {
                        transition-delay: 500ms;
                    }

                    .nav-red-line {
                        display: none !important;
                    }

                    .nav-double-box .dropdown-link {
                        padding-left: 0;
                        padding-right: 0;
                    }

                    .nav-dropdown-toggle.w--open .embed {
                        transform: rotate(180deg);
                    }

                    .nav-dropdown-toggle.w--open {
                        color: var(--gray-900);
                    }

                    .nav-menu {
                        height: calc(100vh - 145px);
                    }

                    .nav-link-box:has(.w--current) .nav-dropdown-toggle,
                    .nav-link-box:has(.w--current) .nav-text-link,
                    .nav-link-box:has(.w--current) .white-link {
                        font-weight: 600;
                        color: var(--gray-900);
                    }

                    .nav-dropdown-toggle.w--open:hover,
                    .nav-link-box:has(.w--current) .nav-dropdown-toggle:hover,
                    .nav-link-box:has(.w--current) .nav-text-link:hover,
                    .nav-link-box:has(.w--current) .white-link:hover {
                        color: white;
                    }
                }

                @media screen and (max-width: 767px) {
                    .platform-list-item .embed {
                        width: 1.125rem;
                        height: 1.125rem;
                    }

                    .nav-menu {
                        height: calc(100vh - 72px);
                    }

                    .hide-this {
                        display: none !important;
                    }

                    .meta-hero-slider {
                        display: flex !important;
                        gap: 1.5rem;
                    }
                }

                @media screen and (max-width: 479px) {
                    .platform-list-item .embed {
                        padding-top: 0.25rem;
                    }
                }

                @media screen and (max-width: 479px) {
                    .platform-item-box .text-color-gray-300 {
                        display: none;
                    }

                    .platform-item-box.w--current .text-color-gray-300 {
                        display: block;
                    }
                }
            </style>

            <style>
                .button-bottom-line {
                    width: 0%;
                    transition: width ease-in-out 200ms;
                }

                .blank-button:hover .button-bottom-line {
                    width: 100%;
                }

                .embed {
                    transition: opacity ease-in-out 200ms, transform 200ms ease-in-out;
                }

                [data-button-icon],
                [data-read-icon] {
                    transition: opacity ease-in-out 200ms, width ease-in-out 200ms;
                }

                [data-button-icon="hover"],
                [data-read-icon="hover"] {
                    opacity: 0;
                    width: 0;
                }

                [data-button-icon="normal"] {
                    width: 1.5rem;
                    opacity: 1;
                }

                [data-read-icon="normal"] {
                    width: 1rem;
                    opacity: 1;
                }

                .blank-button:hover [data-button-icon="normal"],
                .subheading-link-box:hover [data-read-icon="normal"],
                .blog-box:hover [data-button-icon="normal"],
                .infrastracture-box:hover [data-button-icon="normal"],
                .testimonial-link-source:hover [data-button-icon="normal"],
                .platform-testimonial-arrow:hover [data-button-icon="normal"],
                .this-arrow:hover [data-button-icon="normal"],
                .filter-partner-link:hover [data-button-icon="normal"],
                [data-case-to]:hover [data-button-icon="normal"],
                [data-move-link]:hover [data-read-icon="normal"] {
                    width: 0;
                    opacity: 0;
                }

                .blank-button:hover [data-button-icon="hover"],
                .blog-box:hover [data-button-icon="hover"],
                .infrastracture-box:hover [data-button-icon="hover"],
                .testimonial-link-source:hover [data-button-icon="hover"],
                .platform-testimonial-arrow:hover [data-button-icon="hover"],
                .this-arrow:hover [data-button-icon="hover"],
                .filter-partner-link:hover [data-button-icon="hover"],
                [data-case-to]:hover [data-button-icon="hover"] {
                    width: 1.5rem;
                    opacity: 1;
                }

                .subheading-link-box:hover [data-read-icon="hover"],
                [data-move-link]:hover [data-read-icon="hover"] {
                    width: 1rem;
                    opacity: 1;
                }

                .blank-button:hover .button-bottom-line,
                .subheading-link-box:hover .button-bottom-line {
                    width: 100%;
                }

                .blog-box:hover .image-box>img {
                    transform: scale(1.3);
                }

                [data-case-to]:hover .image-box>img {
                    transform: scale(1.2);
                }

                .blog-box:hover .blog-title-box,
                [data-case-to]:hover .case-studies-title-header {
                    color: white;
                }

                .image-box img {
                    transition: transform 300ms ease-in-out;
                }

                option {
                    background-color: var(--gray-900);
                }

                .partner-header .embed,
                .partner-header h3 {
                    transition: color 200ms ease-in-out;
                }

                .partner-header .embed,
                .partner-header h3 {
                    opacity: 0.6;
                }

                .filter-partner-link:hover .partner-header .embed {
                    color: #A983F9;
                    opacity: 1;
                }

                .filter-partner-link:hover .partner-header h3 {
                    color: white;
                    opacity: 1;
                }

                [data-strike="red"] {
                    text-decoration-color: #E9394B;
                }

                .dbc-link-box .box-20 .embed {
                    transition: transform 200ms ease-in-out;
                    transform: translateX(-100%);
                }

                .dbc-link-box:hover .box-20 .embed {
                    transform: translateX(0%);
                }
            </style>
        </div>
        <div class="main-wrapper">
            <div id="aurora-bg" class="section_home-hero no-bg set-0">

                <?php
$lang = $_GET['lang'] ?? 'en'; // mặc định 'en' nếu không có ?lang
?>

<div data-animation="over-right" data-collapse="medium" data-duration="400" data-easing="ease" data-easing2="ease"
    role="banner" class="navbar w-nav">
    <div class="padding-global">
        <div class="container-1600">
            <div class="nav-menu-wrapper"><a href="/?lang=<?php echo $lang; ?>" aria-current="page" class="nav-logo-link w-nav-brand"
                    aria-label="home">
                    <div class="embed w-embed">
                        <img src="assets/logo.png" width="142" alt="Logo" class="logo-image">
                    </div>
                </a>
                <nav role="navigation" class="nav-menu w-nav-menu"
                    style="transition: all; transform: translateX(0px) translateY(0px);">
                    <div class="nav-menu-block">
                        <div class="nav-right-block">

                            <div class="nav-link-box"><a href="/google.php?lang=<?php echo $lang; ?>"  class="nav-text-link w-nav-link">Google</a>
                                <div class="nav-red-line"></div>
                            </div>

                            <div class="nav-link-box"><a href="/tiktok.php?lang=<?php echo $lang; ?>" class="nav-text-link w-nav-link">Tiktok</a>
                                <div class="nav-red-line"></div>
                            </div>

                            <div class="nav-link-box"><a href="/meta.php?lang=<?php echo $lang; ?>" class="nav-text-link w-nav-link">Meta</a>
                                <div class="nav-red-line"></div>
                            </div>
                            <div class="nav-link-box">
                                <?php echo i18n_select_html(); ?>
                            </div>

                        </div>
                        <div class="nav-left-block">
                            <div class="nav-link-box"><a href="javascript:void(0)" onclick="scrollToContact()"
                                    class="white-link w-nav-link">Contact us</a>
                                <div class="nav-red-line"></div>
                            </div>
                        </div>
                    </div>
                </nav>

                <div class="menu-button w-nav-button" style="-webkit-user-select: text;" aria-label="menu" role="button"
                    tabindex="0" aria-controls="w-nav-overlay-0" aria-haspopup="menu" aria-expanded="false">
                    <div class="hide w-icon-nav-menu"></div>
                    <div class="menu-line top"
                        style="background-color: rgb(255, 255, 255); transform: translate3d(0px, 8px, 0px) scale3d(1, 1, 1) rotateX(0deg) rotateY(0deg) rotateZ(-45deg) skew(0deg, 0deg); transform-style: preserve-3d;">
                    </div>
                    <div class="menu-line middle"
                        style="background-color: rgb(255, 255, 255); transform: translate3d(0px, 0px, 0px) scale3d(0, 0, 1) rotateX(0deg) rotateY(0deg) rotateZ(0deg) skew(0deg, 0deg); transform-style: preserve-3d;">
                    </div>
                    <div class="menu-line bottom"
                        style="background-color: rgb(255, 255, 255); transform: translate3d(0px, -8px, 0px) scale3d(1, 1, 1) rotateX(0deg) rotateY(0deg) rotateZ(45deg) skew(0deg, 0deg); transform-style: preserve-3d;">
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="w-nav-overlay" data-wf-ignore="" id="w-nav-overlay-0" style="display: none;"></div>
</div>

                

            </div>


            
<?php
$lang = $_GET['lang'] ?? 'en'; // mặc định 'en' nếu không có ?lang
?>

<div class="section_meta-hero">
    <div class="platform-side-slider">
        <div class="position-relative"><img src="<?php echo $image1 ?>" loading="lazy" sizes="(max-width: 675px) 100vw, 675px" srcset="<?php echo $image1 ?> 500w, <?php echo $image1 ?> 675w" alt="<?php echo $platform ?> Posts" /></div>
    </div>
    <div class="position-relative">
        <div class="padding-global">
            <div class="container-1600">
                <div class="margin-bottom-50 set-margin-bottom-48">
                    <div class="horizontal-drag">
                        <div class="flex-container">
                            <div class="platform-tabs">
                                <a href="/meta.php?lang=<?php echo $lang; ?>" aria-current="page" class="platform-tab w-inline-block <?php if ($platform == 'Meta'): ?> w--current <?php endif; ?>">
                                    <div data-colored="no" class="embed _24 gray w-embed">
                                        <svg width="26" height="18" viewBox="0 0 26 18" fill="none" xmlns="http://www.w3.org/2000/svg">
                                            <g clip-path="url(#clip0_798_2833)">
                                                <path
                                                    d="M3.34498 11.5948C3.34498 12.5301 3.55027 13.2482 3.8186 13.6826C4.1704 14.2516 4.69513 14.4927 5.23007 14.4927C5.92005 14.4927 6.55125 14.3215 7.76766 12.6391C8.74214 11.2907 9.8904 9.39796 10.663 8.21136L11.9714 6.20106C12.8803 4.80492 13.9323 3.2529 15.1385 2.20089C16.1232 1.34226 17.1854 0.865234 18.2545 0.865234C20.0493 0.865234 21.7589 1.90531 23.0673 3.85599C24.4992 5.99236 25.1943 8.68328 25.1943 11.4602C25.1943 13.1111 24.8689 14.3241 24.3152 15.2824C23.7802 16.2091 22.7376 17.1351 20.9837 17.1351V14.4927C22.4855 14.4927 22.8603 13.1128 22.8603 11.5335C22.8603 9.28296 22.3356 6.78541 21.1796 5.00084C20.3593 3.73503 19.2962 2.96157 18.1267 2.96157C16.8617 2.96157 15.8438 3.91562 14.6998 5.61671C14.0916 6.52049 13.4672 7.6219 12.7662 8.86471L11.9944 10.2319C10.4441 12.9807 10.0514 13.6068 9.27624 14.6401C7.91758 16.4494 6.75739 17.1351 5.23007 17.1351C3.41824 17.1351 2.27254 16.3505 1.56297 15.1682C0.983728 14.2048 0.699219 12.9407 0.699219 11.5003L3.34498 11.5948Z"
                                                    fill="white"
                                                />
                                                <path
                                                    d="M2.78516 4.04254C3.99815 2.17278 5.74865 0.865234 7.7564 0.865234C8.91914 0.865234 10.0751 1.20937 11.2821 2.19493C12.6024 3.27249 14.0096 5.04684 15.7653 7.97115L16.3947 9.0206C17.9144 11.5522 18.779 12.8547 19.285 13.4688C19.9358 14.2576 20.3915 14.4927 20.9835 14.4927C22.4853 14.4927 22.8601 13.1128 22.8601 11.5335L25.1941 11.4602C25.1941 13.1111 24.8687 14.3241 24.315 15.2824C23.7801 16.2091 22.7374 17.1351 20.9835 17.1351C19.8932 17.1351 18.9272 16.8983 17.859 15.8906C17.0379 15.1171 16.0779 13.7431 15.3393 12.508L13.1425 8.83831C12.0402 6.99666 11.0291 5.62352 10.4439 5.00169C9.81441 4.33301 9.00518 3.52548 7.71381 3.52548C6.66862 3.52548 5.78102 4.2589 5.03823 5.38075L2.78516 4.04254Z"
                                                    fill="white"
                                                />
                                                <path
                                                    d="M7.71399 3.52548C6.6688 3.52548 5.7812 4.2589 5.03841 5.38075C3.98811 6.966 3.34498 9.32726 3.34498 11.5948C3.34498 12.5301 3.55027 13.2482 3.8186 13.6826L1.56297 15.1682C0.983728 14.2048 0.699219 12.9407 0.699219 11.5003C0.699219 8.8809 1.41816 6.1508 2.78534 4.04254C3.99833 2.17278 5.74883 0.865234 7.75658 0.865234L7.71399 3.52548Z"
                                                    fill="white"
                                                />
                                            </g>
                                            <defs>
                                                <clipPath id="clip0_798_2833">
                                                    <rect width="25" height="16.6667" fill="white" transform="translate(0.5 0.666748)" />
                                                </clipPath>
                                            </defs>
                                        </svg>
                                    </div>
                                    <div data-colored="yes" class="embed _24 colored w-embed">
                                        <svg width="26" height="18" viewBox="0 0 26 18" fill="none" xmlns="http://www.w3.org/2000/svg">
                                            <g clip-path="url(#clip0_86_29187)">
                                                <path
                                                    d="M3.34498 11.5947C3.34498 12.53 3.55027 13.2481 3.8186 13.6825C4.1704 14.2515 4.69513 14.4926 5.23007 14.4926C5.92005 14.4926 6.55125 14.3214 7.76766 12.639C8.74214 11.2906 9.8904 9.39782 10.663 8.21123L11.9714 6.20092C12.8803 4.80478 13.9323 3.25276 15.1385 2.20076C16.1232 1.34212 17.1854 0.865097 18.2545 0.865097C20.0493 0.865097 21.7589 1.90517 23.0673 3.85585C24.4992 5.99223 25.1943 8.68314 25.1943 11.4601C25.1943 13.1109 24.8689 14.3239 24.3152 15.2822C23.7802 16.209 22.7376 17.1349 20.9837 17.1349V14.4926C22.4855 14.4926 22.8603 13.1126 22.8603 11.5333C22.8603 9.28282 22.3356 6.78527 21.1796 5.0007C20.3593 3.73489 19.2962 2.96144 18.1267 2.96144C16.8617 2.96144 15.8438 3.91548 14.6998 5.61657C14.0916 6.52036 13.4672 7.62177 12.7662 8.86458L11.9944 10.2318C10.4441 12.9806 10.0514 13.6067 9.27624 14.6399C7.91758 16.4492 6.75739 17.1349 5.23007 17.1349C3.41824 17.1349 2.27254 16.3504 1.56297 15.1681C0.983728 14.2047 0.699219 12.9406 0.699219 11.5001L3.34498 11.5947Z"
                                                    fill="#0081FB"
                                                />
                                                <path
                                                    d="M2.78516 4.0424C3.99815 2.17265 5.74865 0.865097 7.7564 0.865097C8.91914 0.865097 10.0751 1.20923 11.2821 2.19479C12.6024 3.27235 14.0096 5.0467 15.7653 7.97101L16.3947 9.02046C17.9144 11.5521 18.779 12.8545 19.285 13.4687C19.9358 14.2575 20.3915 14.4926 20.9835 14.4926C22.4853 14.4926 22.8601 13.1126 22.8601 11.5333L25.1941 11.4601C25.1941 13.1109 24.8687 14.3239 24.315 15.2822C23.7801 16.209 22.7374 17.1349 20.9835 17.1349C19.8932 17.1349 18.9272 16.8981 17.859 15.8904C17.0379 15.117 16.0779 13.743 15.3393 12.5078L13.1425 8.83817C12.0402 6.99653 11.0291 5.62339 10.4439 5.00155C9.81441 4.33287 9.00518 3.52534 7.71381 3.52534C6.66862 3.52534 5.78102 4.25876 5.03823 5.38062L2.78516 4.0424Z"
                                                    fill="url(#paint0_linear_86_29187)"
                                                />
                                                <path
                                                    d="M7.71399 3.52534C6.6688 3.52534 5.7812 4.25876 5.03841 5.38062C3.98811 6.96586 3.34498 9.32712 3.34498 11.5947C3.34498 12.53 3.55027 13.2481 3.8186 13.6825L1.56297 15.1681C0.983728 14.2047 0.699219 12.9406 0.699219 11.5001C0.699219 8.88076 1.41816 6.15067 2.78534 4.0424C3.99833 2.17265 5.74883 0.865097 7.75658 0.865097L7.71399 3.52534Z"
                                                    fill="url(#paint1_linear_86_29187)"
                                                />
                                            </g>
                                            <defs>
                                                <linearGradient id="paint0_linear_86_29187" x1="5.89517" y1="10.8314" x2="22.7613" y2="11.6833" gradientUnits="userSpaceOnUse">
                                                    <stop stop-color="#0064E1" />
                                                    <stop offset="0.4" stop-color="#0064E1" />
                                                    <stop offset="0.83" stop-color="#0073EE" />
                                                    <stop offset="1" stop-color="#0082FB" />
                                                </linearGradient>
                                                <linearGradient id="paint1_linear_86_29187" x1="4.53243" y1="12.7055" x2="4.53243" y2="6.48714" gradientUnits="userSpaceOnUse">
                                                    <stop stop-color="#0082FB" />
                                                    <stop offset="1" stop-color="#0064E0" />
                                                </linearGradient>
                                                <clipPath id="clip0_86_29187">
                                                    <rect width="25" height="16.6667" fill="white" transform="translate(0.5 0.666672)" />
                                                </clipPath>
                                            </defs>
                                        </svg>
                                    </div>
                                    <div class="platform-text-box">
                                        <div class="platform-text"><?php echo $platform ?></div>
                                    </div>
                                </a>
                                <a href="/tiktok.php?lang=<?php echo $lang; ?>" class="platform-tab w-inline-block <?php if ($platform == 'Tiktok'): ?> w--current <?php endif; ?>">
                                    <div data-colored="no" class="embed _24 gray w-embed">
                                        <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                                            <path
                                                d="M19.3214 5.56219C19.1695 5.4837 19.0217 5.39765 18.8784 5.30438C18.4618 5.02896 18.0799 4.70445 17.7408 4.33781C16.8923 3.36703 16.5754 2.38219 16.4587 1.69266H16.4634C16.3659 1.12031 16.4062 0.75 16.4123 0.75H12.5479V15.6928C12.5479 15.8934 12.5479 16.0917 12.5395 16.2877C12.5395 16.312 12.5372 16.3345 12.5358 16.3608C12.5358 16.3716 12.5358 16.3828 12.5334 16.3941C12.5334 16.3969 12.5334 16.3997 12.5334 16.4025C12.4927 16.9386 12.3208 17.4566 12.0329 17.9107C11.7451 18.3648 11.35 18.7413 10.8825 19.0069C10.3952 19.2841 9.84414 19.4295 9.28357 19.4288C7.4831 19.4288 6.02388 17.9606 6.02388 16.1475C6.02388 14.3344 7.4831 12.8663 9.28357 12.8663C9.62439 12.8659 9.96311 12.9196 10.2872 13.0252L10.2918 9.09047C9.30811 8.9634 8.30872 9.04158 7.35671 9.32008C6.4047 9.59858 5.52074 10.0714 4.7606 10.7086C4.09454 11.2873 3.53457 11.9778 3.10591 12.7491C2.94279 13.0303 2.32732 14.1605 2.25279 15.9947C2.20591 17.0358 2.51857 18.1144 2.66763 18.5602V18.5695C2.76138 18.832 3.12466 19.7278 3.71669 20.483C4.19409 21.0887 4.75811 21.6208 5.3906 22.0622V22.0528L5.39997 22.0622C7.27076 23.3334 9.34497 23.25 9.34497 23.25C9.70404 23.2355 10.9068 23.25 12.2728 22.6027C13.7878 21.885 14.6503 20.8158 14.6503 20.8158C15.2013 20.1769 15.6394 19.4488 15.9459 18.6628C16.2956 17.7436 16.4123 16.6411 16.4123 16.2005V8.27297C16.4592 8.30109 17.0836 8.71406 17.0836 8.71406C17.0836 8.71406 17.9831 9.29063 19.3865 9.66609C20.3934 9.93328 21.75 9.98953 21.75 9.98953V6.15328C21.2747 6.20484 20.3095 6.05484 19.3214 5.56219Z"
                                                fill="white"
                                            />
                                        </svg>
                                    </div>
                                    <div data-colored="yes" class="embed _24 colored w-embed">
                                        <svg width="20" height="22" viewBox="0 0 20 22" fill="none" xmlns="http://www.w3.org/2000/svg">
                                            <g clip-path="url(#clip0_845_3400)">
                                                <path
                                                    d="M3.70945 14.1605C3.83968 13.0822 4.28191 12.4785 5.11526 11.8596C6.30764 11.0215 7.7971 11.4956 7.7971 11.4956V8.68296C8.15921 8.67371 8.52145 8.69517 8.87961 8.74711V12.3667C8.87961 12.3667 7.3906 11.8926 6.19822 12.7312C5.36531 13.3496 4.92218 13.9537 4.79241 15.032C4.78834 15.6175 4.89822 16.3828 5.4042 17.0446C5.2791 16.9805 5.15159 16.9074 5.02166 16.8253C3.90705 16.0769 3.70403 14.954 3.70945 14.1605ZM15.0296 3.4824C14.2094 2.58357 13.8992 1.67608 13.787 1.03857H14.8189C14.8189 1.03857 14.6132 2.71012 16.1126 4.35393L16.1334 4.37603C15.7293 4.12183 15.3587 3.82179 15.0296 3.4824ZM20.0004 6.03068V9.57746C20.0004 9.57746 18.6836 9.52589 17.7092 9.278C16.3486 8.93129 15.4741 8.39953 15.4741 8.39953C15.4741 8.39953 14.87 8.02033 14.8212 7.99389V15.318C14.8212 15.7258 14.7095 16.7443 14.369 17.5937C13.9245 18.7049 13.2386 19.4343 13.1124 19.5833C13.1124 19.5833 12.2781 20.5693 10.8063 21.2332C9.47964 21.8321 8.31484 21.817 7.96667 21.8321C7.96667 21.8321 5.95314 21.9119 4.14128 20.7344C3.74948 20.4749 3.38375 20.1809 3.04883 19.8564L3.05787 19.8629C4.87018 21.0404 6.88326 20.9606 6.88326 20.9606C7.23189 20.9455 8.39669 20.9606 9.72291 20.3617C11.1934 19.6978 12.029 18.7118 12.029 18.7118C12.1538 18.5627 12.8429 17.8334 13.2856 16.7217C13.6252 15.8727 13.7378 14.8539 13.7378 14.4461V7.1228C13.7866 7.14967 14.3902 7.52887 14.3902 7.52887C14.3902 7.52887 15.2652 8.06106 16.6258 8.40734C17.6007 8.65523 18.917 8.7068 18.917 8.7068V5.92753C19.3673 6.02851 19.7512 6.05581 20.0004 6.03068Z"
                                                    fill="#FD355A"
                                                />
                                                <path
                                                    d="M18.9167 5.92753V8.70593C18.9167 8.70593 17.6005 8.65436 16.6256 8.40647C15.265 8.05976 14.39 7.52801 14.39 7.52801C14.39 7.52801 13.7864 7.1488 13.7375 7.12193V14.4469C13.7375 14.8547 13.6258 15.8736 13.2854 16.7226C12.8409 17.8342 12.1549 18.5636 12.0288 18.7127C12.0288 18.7127 11.1941 19.6986 9.72268 20.3626C8.39646 20.9615 7.23166 20.9463 6.88303 20.9615C6.88303 20.9615 4.86996 21.0412 3.05764 19.8637L3.0486 19.8572C2.85726 19.672 2.67715 19.4763 2.50916 19.2713C1.93083 18.5662 1.57632 17.7324 1.48724 17.4944C1.48709 17.4934 1.48709 17.4924 1.48724 17.4914C1.3439 17.078 1.04276 16.0851 1.0839 15.1234C1.1567 13.4267 1.75357 12.3853 1.91138 12.1244C2.32933 11.413 2.87292 10.7764 3.51796 10.2431C4.08717 9.78294 4.73235 9.41678 5.42703 9.15968C6.17802 8.85782 6.98218 8.69602 7.79642 8.68296V11.4956C7.79642 11.4956 6.30696 11.0232 5.11503 11.8596C4.28168 12.4785 3.83945 13.0822 3.70923 14.1605C3.7038 14.954 3.90683 16.0769 5.02053 16.8257C5.15045 16.9081 5.27797 16.9812 5.40307 17.045C5.59763 17.2979 5.83444 17.5183 6.10394 17.6973C7.19187 18.3859 8.10345 18.434 9.26915 17.9868C10.0464 17.6877 10.6316 17.0138 10.9029 16.2671C11.0733 15.8008 11.0711 15.3314 11.0711 14.8461V1.03857H13.7841C13.8962 1.67608 14.2064 2.58357 15.0267 3.4824C15.3557 3.82179 15.7263 4.12183 16.1304 4.37603C16.2498 4.49955 16.8602 5.11018 17.6439 5.48505C18.0491 5.67883 18.4761 5.82729 18.9167 5.92753V5.92753Z"
                                                    fill="black"
                                                />
                                                <path d="M0.408203 16.6309V16.633L0.475523 16.8155C0.46779 16.7942 0.442773 16.7297 0.408203 16.6309Z" fill="#33F3ED" />
                                                <path
                                                    d="M5.42735 9.15979C4.73266 9.41688 4.08748 9.78304 3.51827 10.2432C2.87302 10.7777 2.32957 11.4156 1.91215 12.1284C1.75434 12.3885 1.15747 13.4307 1.08467 15.1274C1.04352 16.0891 1.34467 17.082 1.48801 17.4954C1.48786 17.4964 1.48786 17.4974 1.48801 17.4984C1.57845 17.7342 1.93159 18.568 2.50992 19.2753C2.67792 19.4803 2.85803 19.676 3.04937 19.8612C2.43631 19.4549 1.88955 18.9635 1.42697 18.4033C0.853611 17.7043 0.500012 16.8791 0.407768 16.6356C0.407659 16.6339 0.407659 16.6321 0.407768 16.6304V16.6274C0.263977 16.2143 -0.0380748 15.221 0.00397737 14.2581C0.0767773 12.5614 0.673646 11.52 0.831455 11.2591C1.24875 10.5462 1.79222 9.90829 2.43758 9.37388C3.00667 8.91352 3.65188 8.54735 4.34665 8.29043C4.78002 8.11809 5.23147 7.99096 5.69323 7.91122C6.3891 7.79479 7.09983 7.7847 7.799 7.88132V8.68307C6.984 8.69585 6.17903 8.85765 5.42735 9.15979Z"
                                                    fill="#33F3ED"
                                                />
                                                <path
                                                    d="M13.7871 1.03871H11.0741V14.8466C11.0741 15.332 11.0741 15.8001 10.9059 16.2677C10.6319 17.014 10.049 17.6879 9.27219 17.9869C8.10604 18.4359 7.19445 18.386 6.10698 17.6974C5.83702 17.5193 5.5996 17.2996 5.4043 17.0473C6.3308 17.521 7.16009 17.5128 8.18743 17.1175C8.96381 16.8185 9.54756 16.1446 9.82068 15.3979C9.9916 14.9316 9.98934 14.4622 9.98934 13.9773V0.166748H13.7356C13.7356 0.166748 13.6935 0.509985 13.7871 1.03871ZM18.9175 5.15929V5.92767C18.4777 5.82727 18.0514 5.6788 17.6469 5.48519C16.8633 5.11031 16.2528 4.49968 16.1335 4.37617C16.272 4.46333 16.4157 4.54263 16.5639 4.61366C17.5167 5.06958 18.4549 5.20566 18.9175 5.15929Z"
                                                    fill="#33F3ED"
                                                />
                                            </g>
                                            <defs>
                                                <clipPath id="clip0_845_3400">
                                                    <rect width="20" height="22" fill="white" />
                                                </clipPath>
                                            </defs>
                                        </svg>
                                    </div>
                                    <div class="platform-text-box">
                                        <div class="platform-text">TikTok</div>
                                    </div>
                                </a>
                                <a href="/google.php?lang=<?php echo $lang; ?>" class="platform-tab w-inline-block <?php if ($platform == 'Google'): ?> w--current <?php endif; ?>">
                                    <div data-colored="no" class="embed _24 gray w-embed">
                                        <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                                            <path
                                                fill-rule="evenodd"
                                                clip-rule="evenodd"
                                                d="M22.8805 12.2576C22.8805 11.454 22.8084 10.6813 22.6744 9.93945H12.0005V14.3234H18.0999C17.8372 15.7401 17.0387 16.9404 15.8384 17.744V20.5877H19.5011C21.6441 18.6146 22.8805 15.7092 22.8805 12.2576Z"
                                                fill="white"
                                            />
                                            <path
                                                fill-rule="evenodd"
                                                clip-rule="evenodd"
                                                d="M11.9995 23.3333C15.0595 23.3333 17.6249 22.3185 19.5001 20.5876L15.8374 17.7439C14.8225 18.4239 13.5243 18.8258 11.9995 18.8258C9.04765 18.8258 6.54916 16.8321 5.65795 14.1533H1.87158V17.0897C3.73643 20.7936 7.56917 23.3333 11.9995 23.3333Z"
                                                fill="white"
                                            />
                                            <path
                                                fill-rule="evenodd"
                                                clip-rule="evenodd"
                                                d="M5.65833 14.1542C5.43166 13.4742 5.30288 12.7478 5.30288 12.0008C5.30288 11.2539 5.43166 10.5275 5.65833 9.8475V6.91113H1.87196C1.10438 8.44114 0.666504 10.172 0.666504 12.0008C0.666504 13.8296 1.10438 15.5605 1.87196 17.0905L5.65833 14.1542Z"
                                                fill="white"
                                            />
                                            <path
                                                fill-rule="evenodd"
                                                clip-rule="evenodd"
                                                d="M11.9995 5.17461C13.6634 5.17461 15.1574 5.74643 16.3319 6.86946L19.5825 3.61885C17.6198 1.79005 15.0543 0.667023 11.9995 0.667023C7.56917 0.667023 3.73643 3.20672 1.87158 6.91067L5.65795 9.84704C6.54916 7.16825 9.04765 5.17461 11.9995 5.17461Z"
                                                fill="white"
                                            />
                                        </svg>
                                    </div>
                                    <div data-colored="yes" class="embed _24 colored w-embed">
                                        <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                                            <path
                                                fill-rule="evenodd"
                                                clip-rule="evenodd"
                                                d="M22.88 12.2576C22.88 11.454 22.8079 10.6813 22.674 9.93945H12V14.3234H18.0994C17.8367 15.7401 17.0382 16.9404 15.8379 17.744V20.5877H19.5006C21.6437 18.6146 22.88 15.7092 22.88 12.2576Z"
                                                fill="#4285F4"
                                            />
                                            <path
                                                fill-rule="evenodd"
                                                clip-rule="evenodd"
                                                d="M11.999 23.3333C15.059 23.3333 17.6244 22.3185 19.4996 20.5876L15.8369 17.7439C14.822 18.4239 13.5238 18.8258 11.999 18.8258C9.04716 18.8258 6.54868 16.8321 5.65746 14.1533H1.87109V17.0897C3.73594 20.7936 7.56868 23.3333 11.999 23.3333Z"
                                                fill="#34A853"
                                            />
                                            <path
                                                fill-rule="evenodd"
                                                clip-rule="evenodd"
                                                d="M5.65784 14.1534C5.43118 13.4734 5.30239 12.7471 5.30239 12.0001C5.30239 11.2531 5.43118 10.5268 5.65784 9.84677V6.9104H1.87147C1.1039 8.4404 0.666016 10.1713 0.666016 12.0001C0.666016 13.8289 1.1039 15.5598 1.87147 17.0898L5.65784 14.1534Z"
                                                fill="#FBBC05"
                                            />
                                            <path
                                                fill-rule="evenodd"
                                                clip-rule="evenodd"
                                                d="M11.999 5.17433C13.6629 5.17433 15.1569 5.74615 16.3314 6.86918L19.582 3.61857C17.6193 1.78978 15.0538 0.666748 11.999 0.666748C7.56868 0.666748 3.73595 3.20645 1.87109 6.91039L5.65746 9.84676C6.54868 7.16797 9.04717 5.17433 11.999 5.17433Z"
                                                fill="#EA4335"
                                            />
                                        </svg>
                                    </div>
                                    <div class="platform-text-box">
                                        <div class="platform-text">Google</div>
                                    </div>
                                </a>
                            </div>
                            <div class="hide w-embed">
                                <style>
                                    .embed.colored {
                                        transform: scale(0);
                                    }

                                    /**.platform-tab > .platform-text {
width: 0;
opacity: 0;
transition: opacity 300ms ease-in-out, width 400ms ease-in-out;
} */

                                    .platform-text-box {
                                        transition: width 400ms ease-in-out, padding-left 450ms ease-in-out;
                                    }

                                    .platform-tab:hover .platform-text-box {
                                        width: 100%;
                                        padding-left: 0.25rem;
                                    }

                                    .platform-tab.w--current .gray {
                                        display: none;
                                    }

                                    .platform-tab.w--current .colored {
                                        display: flex;
                                        opacity: 1;
                                        transform: scale(1);
                                    }

                                    .platform-tab.w--current.off .colored {
                                        display: none;
                                    }

                                    .platform-tab.w--current.off .gray {
                                        display: flex;
                                        opacity: 1;
                                        transform: scale(1);
                                    }

                                    [data-home="load"],
                                    [data-home="side"],
                                    [data-feature="image"],
                                    [data-feature="content"] {
                                        transition: opacity 300ms ease-in-out, transform 300ms ease-in-out;
                                    }

                                    [data-show="false"] {
                                        opacity: 0;
                                        transform: translateY(6.25rem);
                                    }

                                    [data-show="side"] {
                                        opacity: 0;
                                        transform: translateX(-6.25rem);
                                    }

                                    [data-show="sider"] {
                                        opacity: 0;
                                        transform: translateX(6.25rem);
                                    }

                                    [data-show="opacity"] {
                                        opacity: 0;
                                    }
                                </style>
                            </div>
                            <div class="hide w-embed w-script">
                                <script
                                    src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.7.1/jquery.min.js"
                                    integrity="sha512-v2CJ7UaYy4JwqLDIrZUI/4hqeoQieOmAZNXBeQyjo21dadnwR+8ZaIJVT8EE2iyI61OV8e6M8PP2/4hpQINQ/g=="
                                    crossorigin="anonymous"
                                    referrerpolicy="no-referrer"
                                ></script>
                                <script>
                                    function toTrue(el) {
                                        el.attr("data-show", true);
                                    }

                                    $(document).ready(function (e) {
                                        toTrue($('[data-home="load"]'));
                                    });

                                    $.fn.isInViewport = function () {
                                        let elementTop = $(this).offset().top;
                                        let elementBottom = elementTop + $(this).outerHeight();

                                        let viewportTop = $(window).scrollTop();
                                        let viewportBottom = viewportTop + window.innerHeight;

                                        return elementBottom > viewportTop && elementTop < viewportBottom;
                                    };

                                    $(window).scroll(function () {
                                        $('[data-home="side"][data-animated="false"]').each(function () {
                                            var el = $(this);
                                            let getOffset = detectOffset(el);

                                            if (getOffset <= 550) {
                                                el.attr("data-animated", "true");
                                                el.attr("data-show", "true");
                                            }
                                        });

                                        $('[data-load="feature"][data-animated="false"]').each(function () {
                                            var el = $(this);
                                            let getOffset = detectOffset(el);

                                            if (getOffset <= 550) {
                                                el.attr("data-animated", "true");

                                                var image = el.find('[data-feature="image"]').attr("data-show", "true");
                                                var content = el.find('[data-feature="content"]').attr("data-show", "true");
                                            }
                                        });
                                    });

                                    function detectOffset(el) {
                                        let f = el.offset().top - $(window).scrollTop();
                                        return f;
                                    }
                                </script>
                            </div>
                        </div>
                        <div class="hide w-embed">
                            <style>
                                .horizontal-drag::-webkit-scrollbar {
                                    height: 0px;
                                }

                                .horizontal-drag {
                                    overflow-y: hidden;
                                }
                            </style>
                        </div>
                        <div class="hide w-embed w-script">
                            <script>
                                let pointerFrom = 0;
                                let elementFrom = 0;

                                const scrollable = document.querySelector(".horizontal-drag");

                                const onDrag = (event) => {
                                    // Ensure we only do this for pointers that don't have native
                                    // drag-scrolling behavior and when the pointer is down.
                                    if (event.pointerType == "mouse") {
                                        scrollable.scrollLeft = elementFrom - event.clientX + pointerFrom;
                                    }
                                };

                                scrollable.addEventListener("pointerdown", (event) => {
                                    // Ensure we only do this for pointers that don't have native
                                    // drag-scrolling behavior.
                                    if (event.pointerType == "mouse") {
                                        pointerDown = true;
                                        // Set the position where the mouse is starting to drag from.
                                        pointerFrom = event.clientX;
                                        // Set the position of the element is scrolled from.
                                        elementFrom = scrollable.scrollLeft;

                                        // React on pointer move.
                                        document.addEventListener("pointermove", onDrag);
                                    }
                                });

                                // Stop reacting on pointer move when pointer is no longer clicked.
                                document.addEventListener("pointerup", (event) => {
                                    // Ensure we only do this for pointers that don't have native
                                    // drag-scrolling behavior.
                                    if (event.pointerType == "mouse") {
                                        document.removeEventListener("pointermove", onDrag);
                                    }
                                });
                            </script>
                        </div>
                    </div>
                </div>
                <div class="meta-hero-component">
                    <div class="position-relative">
                        <div class="max-width-918 set-tab-max-width-none">
                            <div class="margin-bottom-48 set-margin-bottom-24">
                                <h1><?php echo $text1 ?></h1>
                            </div>
                            <div class="margin-bottom-48 set-mobile-margin-bottom-249">
                                <div class="max-width-586">
                                    <div class="text-size-20 text-color-gray-300 text-weight-medium set-text-size-16">
                                        <?php echo $text2 ?>
                                    </div>
                                </div>
                            </div>
                            <div class="button-wrapper">
                                <div class="button-flex-block">
                                    <a data-button-all="" href="javascript:void(0)" onclick="scrollToContact()" class="blank-button w-inline-block">
                                        <div class="position-relative">
                                            <div>Contact us</div>
                                            <div class="button-bottom-line"></div>
                                        </div>
                                        <div class="fix-24">
                                            <div data-button-icon="hover" class="embed w-embed">
                                                <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                    <path d="M5 12H19M19 12L12 5M19 12L12 19" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" />
                                                </svg>
                                            </div>
                                            <div data-button-icon="normal" class="embed w-embed">
                                                <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                    <path d="M9 18L15 12L9 6" stroke="white" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" />
                                                </svg>
                                            </div>
                                        </div>
                                    </a>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div>
                        <div class="meta-hero-slider-container splide">
                            <div class="splide__track">
                                <div class="meta-hero-slider splide__list">
                                    <div class="hero-meta-slide-box _541 splide__slide">
                                        <div>
                                            <div class="margin-bottom-16">
                                                <div class="heading-24 set-text-size-20 text-weight-semibold">
                                                    Lower CPM &amp; CPA
                                                </div>
                                            </div>
                                            <div class="text-color-gray-300">Cut advertising costs with an auction advantage. Leverage media buying strategies and trusted infrastructure.</div>
                                        </div>
                                        <div class="go-left">
                                            <div class="slider-price-block">
                                                <div class="text-size-12 text-color-gray-400">You saved</div>
                                                <div class="padding-bottom-5">
                                                    <div class="embed w-embed">
                                                        <svg width="10" height="8" viewBox="0 0 10 8" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                            <path
                                                                d="M8.98085 6.63325L5.74935 1.03625C5.33685 0.32125 4.66185 0.32125 4.24935 1.03625L1.01785 6.63325C0.605349 7.34825 0.942849 7.93225 1.76785 7.93225H8.23085C9.05585 7.93225 9.39335 7.34725 8.98085 6.63325Z"
                                                                fill="#17B26A"
                                                            />
                                                        </svg>
                                                    </div>
                                                </div>
                                                <div class="text-color-green-success text-weight-bold">
                                                    05.84
                                                </div>
                                            </div>
                                            <div class="heading-36 letter-spacing-minus-2">-65%</div>
                                        </div>
                                        <div class="slider-right-chart-image-box">
                                            <div class="embed w-embed">
                                                <svg width="323" height="133" viewBox="0 0 323 133" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                    <mask id="mask0_86_29296" style="mask-type: alpha;" maskUnits="userSpaceOnUse" x="1" y="1" width="321" height="131">
                                                        <rect width="321" height="131" transform="translate(1 1)" fill="url(#paint0_linear_86_29296)" />
                                                    </mask>
                                                    <g mask="url(#mask0_86_29296)">
                                                        <path
                                                            d="M312.781 124.967L322 132H1V1C2.48999 4.90705 5.58176 24.1654 6.02875 24.1654C6.47576 24.1654 9.38125 8.82643 10.7781 11.1707L22.7912 18.2034L29.7755 47.6077L40.9504 23.9255L46.8172 16.8928L55.1984 47.6077H63.859L71.1227 31.1981C73.9164 28.8538 79.6157 24.1654 80.0627 24.1654C80.5097 24.1654 84.1601 19.4769 85.9295 17.1327H90.3995L101.016 32.7486L110.235 31.1981L114.426 47.6077L126.997 54.6404L133.423 61.6731L140.687 73.3942L147.671 61.4702H150.744L159.125 77.326L167.227 73.3942L174.211 61.6731H178.402L185.666 77.5289L196.003 61.6731L205.781 50.2288L215.559 73.3942L225.337 116.07L232.601 101.525L240.423 108.558L251.039 101.525L267.802 115.59L275.624 108.558L286.24 124.967L295.18 115.59L304.12 124.967H312.781Z"
                                                            fill="#ED2C40"
                                                        />
                                                    </g>
                                                    <path
                                                        d="M322 132L312.781 124.967H304.12L295.18 115.59L286.24 124.967L275.624 108.558L267.802 115.59L251.039 101.525L240.423 108.558L232.601 101.525L225.337 116.07L215.559 73.3942L205.781 50.2288L196.003 61.6731L185.666 77.5289L178.402 61.6731H174.211L167.227 73.3942L159.125 77.3259L150.744 61.4702H147.671L140.687 73.3942L133.423 61.6731L126.997 54.6404L114.426 47.6077L110.235 31.1981L101.016 32.7486L90.3995 17.1327H85.9295C84.1601 19.4769 80.5097 24.1654 80.0627 24.1654C79.6157 24.1654 73.9164 28.8538 71.1227 31.1981L63.859 47.6077H55.1984L46.8172 16.8928L40.9504 23.9255L29.7755 47.6077L22.7912 18.2034L10.7781 11.1707C9.38125 8.82643 6.47576 24.1654 6.02875 24.1654C5.58176 24.1654 2.48999 4.90705 1 1"
                                                        stroke="#ED2C40"
                                                        stroke-width="2"
                                                        stroke-linecap="round"
                                                        stroke-linejoin="round"
                                                    />
                                                    <defs>
                                                        <linearGradient id="paint0_linear_86_29296" x1="160.5" y1="0" x2="160.5" y2="131" gradientUnits="userSpaceOnUse">
                                                            <stop />
                                                            <stop offset="1" stop-opacity="0" />
                                                        </linearGradient>
                                                    </defs>
                                                </svg>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="hero-meta-slide-box center-282 splide__slide">
                                        <div>
                                            <div class="margin-bottom-24">
                                                <div class="embed left hide-this w-embed">
                                                    <svg width="97" height="48" viewBox="0 0 97 48" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                        <path
                                                            d="M47.1003 46.35L83.3403 1.64999H91.7403L55.5003 46.35H47.1003ZM54.0603 24.33C51.8603 24.33 49.8603 23.81 48.0603 22.77C46.3003 21.69 44.9003 20.27 43.8603 18.51C42.8203 16.75 42.3003 14.79 42.3003 12.63C42.3003 10.47 42.8203 8.50999 43.8603 6.74999C44.9003 4.94999 46.3003 3.52999 48.0603 2.48999C49.8603 1.44999 51.8603 0.929993 54.0603 0.929993C56.3003 0.929993 58.3003 1.44999 60.0603 2.48999C61.8203 3.52999 63.2203 4.94999 64.2603 6.74999C65.3003 8.50999 65.8203 10.47 65.8203 12.63C65.8203 14.79 65.3003 16.75 64.2603 18.51C63.2203 20.27 61.8203 21.69 60.0603 22.77C58.3003 23.81 56.3003 24.33 54.0603 24.33ZM54.0603 18.27C55.2603 18.27 56.2603 18.01 57.0603 17.49C57.8603 16.93 58.4603 16.23 58.8603 15.39C59.3003 14.51 59.5203 13.59 59.5203 12.63C59.5203 11.63 59.3003 10.71 58.8603 9.86999C58.4603 9.02999 57.8603 8.32999 57.0603 7.76999C56.2603 7.20999 55.2603 6.92999 54.0603 6.92999C52.9403 6.92999 51.9603 7.20999 51.1203 7.76999C50.3203 8.32999 49.7003 9.04999 49.2603 9.92999C48.8203 10.77 48.6003 11.67 48.6003 12.63C48.6003 13.55 48.8203 14.45 49.2603 15.33C49.7003 16.21 50.3203 16.93 51.1203 17.49C51.9603 18.01 52.9403 18.27 54.0603 18.27ZM84.5403 47.07C82.3403 47.07 80.3403 46.55 78.5403 45.51C76.7803 44.43 75.3803 43.01 74.3403 41.25C73.3003 39.49 72.7803 37.53 72.7803 35.37C72.7803 33.21 73.3003 31.25 74.3403 29.49C75.3803 27.69 76.7803 26.27 78.5403 25.23C80.3403 24.19 82.3403 23.67 84.5403 23.67C86.7803 23.67 88.7803 24.19 90.5403 25.23C92.3003 26.27 93.7003 27.69 94.7403 29.49C95.7803 31.25 96.3003 33.21 96.3003 35.37C96.3003 37.53 95.7803 39.49 94.7403 41.25C93.7003 43.01 92.3003 44.43 90.5403 45.51C88.7803 46.55 86.7803 47.07 84.5403 47.07ZM84.5403 41.01C85.7003 41.01 86.6803 40.75 87.4803 40.23C88.3203 39.67 88.9403 38.97 89.3403 38.13C89.7803 37.25 90.0003 36.33 90.0003 35.37C90.0003 34.37 89.7803 33.45 89.3403 32.61C88.9403 31.77 88.3203 31.07 87.4803 30.51C86.6803 29.95 85.7003 29.67 84.5403 29.67C83.4203 29.67 82.4403 29.95 81.6003 30.51C80.8003 31.07 80.1803 31.79 79.7403 32.67C79.3003 33.51 79.0803 34.41 79.0803 35.37C79.0803 36.29 79.3003 37.19 79.7403 38.07C80.1803 38.95 80.8003 39.67 81.6003 40.23C82.4403 40.75 83.4203 41.01 84.5403 41.01Z"
                                                            fill="#ED2C40"
                                                        />
                                                        <path
                                                            d="M17.88 47.07C14.32 47.07 11.2 46.11 8.52 44.19C5.84 42.27 3.74 39.57 2.22 36.09C0.74 32.61 0 28.57 0 23.97C0 19.33 0.74 15.29 2.22 11.85C3.7 8.40999 5.78 5.72999 8.46 3.80999C11.14 1.88999 14.26 0.929993 17.82 0.929993C21.46 0.929993 24.6 1.88999 27.24 3.80999C29.92 5.72999 32.02 8.42999 33.54 11.91C35.06 15.35 35.82 19.37 35.82 23.97C35.82 28.57 35.06 32.61 33.54 36.09C32.06 39.53 29.98 42.23 27.3 44.19C24.62 46.11 21.48 47.07 17.88 47.07ZM17.94 39.63C19.98 39.63 21.72 39.01 23.16 37.77C24.6 36.49 25.7 34.69 26.46 32.37C27.26 30.01 27.66 27.21 27.66 23.97C27.66 20.73 27.26 17.95 26.46 15.63C25.7 13.27 24.58 11.47 23.1 10.23C21.66 8.98999 19.9 8.36999 17.82 8.36999C15.82 8.36999 14.1 8.98999 12.66 10.23C11.22 11.47 10.1 13.27 9.3 15.63C8.54 17.95 8.16 20.73 8.16 23.97C8.16 27.17 8.54 29.95 9.3 32.31C10.1 34.63 11.22 36.43 12.66 37.71C14.14 38.99 15.9 39.63 17.94 39.63Z"
                                                            fill="#ED2C40"
                                                        />
                                                    </svg>
                                                </div>
                                                <div class="percent-box">
                                                    <div class="embed w-embed">
                                                        <svg width="36" height="48" viewBox="0 0 36 48" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                            <g clip-path="url(#clip0_2450_74)">
                                                                <path
                                                                    d="M15.8814 44.1188C17.0533 45.2906 18.9564 45.2906 20.1283 44.1188L35.1283 29.1188C36.3002 27.9469 36.3002 26.0437 35.1283 24.8719C33.9564 23.7 32.0533 23.7 30.8814 24.8719L21.0002 34.7625V6C21.0002 4.34062 19.6596 3 18.0002 3C16.3408 3 15.0002 4.34062 15.0002 6V34.7531L5.11895 24.8812C3.94707 23.7094 2.04395 23.7094 0.87207 24.8812C-0.299805 26.0531 -0.299805 27.9563 0.87207 29.1281L15.8721 44.1281L15.8814 44.1188Z"
                                                                    fill="#ED2C40"
                                                                />
                                                            </g>
                                                            <defs>
                                                                <clipPath id="clip0_2450_74">
                                                                    <rect width="36" height="48" fill="white" />
                                                                </clipPath>
                                                            </defs>
                                                        </svg>
                                                    </div>
                                                    <div class="embed w-embed">
                                                        <svg width="50" height="43" viewBox="0 0 55 48" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                            <path
                                                                d="M5.10078 46.3497L41.3408 1.64969H49.7408L13.5008 46.3497H5.10078ZM12.0608 24.3297C9.86078 24.3297 7.86078 23.8097 6.06078 22.7697C4.30078 21.6897 2.90078 20.2697 1.86078 18.5097C0.820779 16.7497 0.300781 14.7897 0.300781 12.6297C0.300781 10.4697 0.820779 8.50969 1.86078 6.74969C2.90078 4.94969 4.30078 3.52969 6.06078 2.48969C7.86078 1.44969 9.86078 0.929688 12.0608 0.929688C14.3008 0.929688 16.3008 1.44969 18.0608 2.48969C19.8208 3.52969 21.2208 4.94969 22.2608 6.74969C23.3008 8.50969 23.8208 10.4697 23.8208 12.6297C23.8208 14.7897 23.3008 16.7497 22.2608 18.5097C21.2208 20.2697 19.8208 21.6897 18.0608 22.7697C16.3008 23.8097 14.3008 24.3297 12.0608 24.3297ZM12.0608 18.2697C13.2608 18.2697 14.2608 18.0097 15.0608 17.4897C15.8608 16.9297 16.4608 16.2297 16.8608 15.3897C17.3008 14.5097 17.5208 13.5897 17.5208 12.6297C17.5208 11.6297 17.3008 10.7097 16.8608 9.86969C16.4608 9.02969 15.8608 8.32969 15.0608 7.76969C14.2608 7.20969 13.2608 6.92969 12.0608 6.92969C10.9408 6.92969 9.96078 7.20969 9.12078 7.76969C8.32078 8.32969 7.70078 9.04969 7.26078 9.92969C6.82078 10.7697 6.60078 11.6697 6.60078 12.6297C6.60078 13.5497 6.82078 14.4497 7.26078 15.3297C7.70078 16.2097 8.32078 16.9297 9.12078 17.4897C9.96078 18.0097 10.9408 18.2697 12.0608 18.2697ZM42.5408 47.0697C40.3408 47.0697 38.3408 46.5497 36.5408 45.5097C34.7808 44.4297 33.3808 43.0097 32.3408 41.2497C31.3008 39.4897 30.7808 37.5297 30.7808 35.3697C30.7808 33.2097 31.3008 31.2497 32.3408 29.4897C33.3808 27.6897 34.7808 26.2697 36.5408 25.2297C38.3408 24.1897 40.3408 23.6697 42.5408 23.6697C44.7808 23.6697 46.7808 24.1897 48.5408 25.2297C50.3008 26.2697 51.7008 27.6897 52.7408 29.4897C53.7808 31.2497 54.3008 33.2097 54.3008 35.3697C54.3008 37.5297 53.7808 39.4897 52.7408 41.2497C51.7008 43.0097 50.3008 44.4297 48.5408 45.5097C46.7808 46.5497 44.7808 47.0697 42.5408 47.0697ZM42.5408 41.0097C43.7008 41.0097 44.6808 40.7497 45.4808 40.2297C46.3208 39.6697 46.9408 38.9697 47.3408 38.1297C47.7808 37.2497 48.0008 36.3297 48.0008 35.3697C48.0008 34.3697 47.7808 33.4497 47.3408 32.6097C46.9408 31.7697 46.3208 31.0697 45.4808 30.5097C44.6808 29.9497 43.7008 29.6697 42.5408 29.6697C41.4208 29.6697 40.4408 29.9497 39.6008 30.5097C38.8008 31.0697 38.1808 31.7897 37.7408 32.6697C37.3008 33.5097 37.0808 34.4097 37.0808 35.3697C37.0808 36.2897 37.3008 37.1897 37.7408 38.0697C38.1808 38.9497 38.8008 39.6697 39.6008 40.2297C40.4408 40.7497 41.4208 41.0097 42.5408 41.0097Z"
                                                                fill="#ED2C40"
                                                            />
                                                        </svg>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="margin-bottom-16">
                                                <div class="heading-24 set-text-size-20 text-weight-semibold">
                                                    Low adspend fees
                                                </div>
                                            </div>
                                            <div class="text-color-gray-300">Unlike other agencies, our focus is on helping you scale, not slashing your margins.</div>
                                        </div>
                                    </div>
                                    <div class="hero-meta-slide-box _564 splide__slide">
                                        <div class="position-relative">
                                            <div class="margin-bottom-16">
                                                <div class="heading-24 set-text-size-20 text-weight-semibold">
                                                    Double cashback &amp; points
                                                </div>
                                            </div>
                                            <div class="text-color-gray-300">Gain cashback on spending directly from AdsAsia and top-up your accounts with a cashback credit card for double cashback.</div>
                                        </div>
                                        <div class="slider-left-text-image-box">
                                            <div class="embed w-embed">
                                                <svg width="279" height="195" viewBox="0 0 279 195" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                    <path
                                                        d="M0.429703 195L49.2597 124.839L0.172703 55.192H39.7507L78.0437 111.732H60.3107L98.6037 55.192H137.925L89.0947 124.839L137.668 195H98.3467L60.5677 138.717H77.7867L40.0077 195H0.429703ZM152.475 195V168.529L204.389 114.302C214.669 103.508 222.551 94.9413 228.033 88.602C233.687 82.0913 237.628 76.523 239.855 71.897C242.083 67.271 243.196 62.5593 243.196 57.762C243.196 49.7093 240.626 43.37 235.486 38.744C230.518 34.118 224.093 31.805 216.211 31.805C207.987 31.805 200.877 34.2037 194.88 39.001C188.884 43.627 184.515 50.4803 181.773 59.561L151.19 50.052C153.246 39.9433 157.444 31.2053 163.783 23.838C170.123 16.2993 177.833 10.5597 186.913 6.61899C196.165 2.50699 205.931 0.450993 216.211 0.450993C228.547 0.450993 239.341 2.67833 248.593 7.133C258.017 11.5877 265.298 17.8413 270.438 25.894C275.75 33.9467 278.405 43.37 278.405 54.164C278.405 61.0173 277.12 67.785 274.55 74.467C271.98 81.149 268.125 88.0023 262.985 95.027C257.845 101.88 251.163 109.59 242.939 118.157L197.964 165.445H280.975V195H152.475Z"
                                                        fill="#ED2C40"
                                                        fill-opacity="0.3"
                                                    />
                                                </svg>
                                            </div>
                                        </div>
                                        <div class="position-relative">
                                            <div class="white-notif-box">
                                                <div>
                                                    <div class="margin-bottom-4">
                                                        <div class="text-size-14 text-color-gray-900 text-weight-semibold">
                                                            You&#x27;ve earned cashback!
                                                        </div>
                                                    </div>
                                                    <div class="text-size-14 text-color-gray-600">See your current balance in the app</div>
                                                </div>
                                                <div class="white-close-button">
                                                    <div class="embed w-embed">
                                                        <svg width="36" height="36" viewBox="0 0 36 36" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                            <path d="M23 13L13 23M13 13L23 23" stroke="currentColor" stroke-width="1.66667" stroke-linecap="round" stroke-linejoin="round" />
                                                        </svg>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="hero-meta-slide-box _564 splide__slide">
                                        <div class="position-relative">
                                            <div class="slide-inner-flex-box">
                                                <div class="flex-full">
                                                    <div class="margin-bottom-16">
                                                        <div class="heading-24 set-text-size-20 text-weight-semibold">
                                                            Boost ad approval rates
                                                        </div>
                                                    </div>
                                                    <div class="text-color-gray-300">Rapidly get ads approved that you struggled with on normal advertising accounts. Plus gain a compliance insight from the industry-leaders.</div>
                                                </div>
                                                <div class="inner-line"></div>
                                                <div class="flex-full">
                                                    <div class="margin-bottom-16 set-margin-bottom-8">
                                                        <div class="embed green-check right w-embed">
                                                            <svg width="40" height="40" viewBox="0 0 40 40" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                                <path
                                                                    fill-rule="evenodd"
                                                                    clip-rule="evenodd"
                                                                    d="M36.6654 20.0007C36.6654 29.2054 29.2034 36.6673 19.9987 36.6673C10.794 36.6673 3.33203 29.2054 3.33203 20.0007C3.33203 10.7959 10.794 3.33398 19.9987 3.33398C29.2034 3.33398 36.6654 10.7959 36.6654 20.0007ZM28.325 15.825C28.7806 15.3693 28.7806 14.6307 28.325 14.175C27.8693 13.7194 27.1307 13.7194 26.675 14.175L17.5 23.3501L13.325 19.175C12.8693 18.7194 12.1307 18.7194 11.675 19.175C11.2194 19.6307 11.2194 20.3693 11.675 20.825L16.675 25.825C16.8938 26.0438 17.1906 26.1667 17.5 26.1667C17.8094 26.1667 18.1062 26.0438 18.325 25.825L28.325 15.825Z"
                                                                    fill="#17B26A"
                                                                />
                                                            </svg>
                                                        </div>
                                                    </div>
                                                    <div class="margin-bottom-32 set-margin-bottom-16">
                                                        <div class="text-size-18 text-weight-bold">Your new ad is approved!</div>
                                                    </div>
                                                    <div class="slide-order-block">
                                                        <div class="order-item">
                                                            <div class="embed w-embed">
                                                                <svg width="8" height="8" viewBox="0 0 8 8" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                                    <circle cx="4" cy="4" r="4" fill="#ED2C40" />
                                                                </svg>
                                                            </div>
                                                            <div class="text-size-12 text-weight-bold">
                                                                Approved
                                                            </div>
                                                        </div>
                                                        <div class="order-item">
                                                            <div class="embed w-embed">
                                                                <svg width="8" height="8" viewBox="0 0 8 8" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                                    <circle cx="4" cy="4" r="4" fill="#ED2C40" />
                                                                </svg>
                                                            </div>
                                                            <div class="text-size-12 text-weight-bold text-color-gray-400">
                                                                In review
                                                            </div>
                                                        </div>
                                                        <div class="order-item">
                                                            <div class="embed w-embed">
                                                                <svg width="8" height="8" viewBox="0 0 8 8" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                                    <circle cx="4" cy="4" r="4" fill="#ED2C40" />
                                                                </svg>
                                                            </div>
                                                            <div class="text-size-12 text-weight-bold text-color-gray-400">
                                                                Processing
                                                            </div>
                                                        </div>
                                                        <div class="order-progress-line">
                                                            <div class="progress-line"></div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="slider-left-text-image-box hide-mobile-landscape">
                                            <div class="embed w-embed">
                                                <svg width="175" height="92" viewBox="0 0 175 92" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                    <path
                                                        d="M0.980469 91.9995C43.4004 86.1981 112.89 6.39939 173.469 1.02528C221.079 -3.19827 245.843 13.9399 313.437 29.4497C448.16 60.3621 482.792 12.2001 482.792 12.2001L482.792 92L0.980469 91.9995Z"
                                                        fill="url(#paint0_linear_663_793)"
                                                    />
                                                    <defs>
                                                        <linearGradient id="paint0_linear_663_793" x1="278.372" y1="-30.0855" x2="278.372" y2="97.3312" gradientUnits="userSpaceOnUse">
                                                            <stop stop-color="#E83043" stop-opacity="0.9" />
                                                            <stop offset="1" stop-color="#FF4235" stop-opacity="0" />
                                                        </linearGradient>
                                                    </defs>
                                                </svg>
                                            </div>
                                        </div>
                                        <div class="down-side-red show-mobile-landscape">
                                            <div class="embed w-embed">
                                                <svg width="103" height="133" viewBox="0 0 103 133" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                    <path
                                                        d="M102.999 0C96.4778 47.1029 6.77252 124.264 0.731255 191.531C-4.01663 244.396 15.2492 271.893 32.6844 346.95C67.4344 496.545 13.2934 535 13.2934 535H103L102.999 0Z"
                                                        fill="url(#paint0_linear_4150_23803)"
                                                    />
                                                    <defs>
                                                        <linearGradient id="paint0_linear_4150_23803" x1="-34.2418" y1="308.014" x2="108.993" y2="308.014" gradientUnits="userSpaceOnUse">
                                                            <stop stop-color="#E83043" stop-opacity="0.9" />
                                                            <stop offset="1" stop-color="#FF4235" stop-opacity="0" />
                                                        </linearGradient>
                                                    </defs>
                                                </svg>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="hero-meta-slide-box _282 gap-22 pad-24 splide__slide">
                                        <div class="slide-full-bottom-image-box hide-mobile-landscape">
                                            <div class="embed w-embed">
                                                <svg width="282" height="92" viewBox="0 0 282 92" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                    <path
                                                        d="M-279.168 91.9995C-181.218 43.5137 -61.7527 -27.9205 51.1901 12.2001C236.502 78.0285 282.591 12.2001 282.591 12.2001L282.591 92L-279.168 91.9995Z"
                                                        fill="url(#paint0_linear_663_818)"
                                                    />
                                                    <defs>
                                                        <linearGradient id="paint0_linear_663_818" x1="44.2517" y1="-30.0855" x2="44.2518" y2="97.3312" gradientUnits="userSpaceOnUse">
                                                            <stop stop-color="#E83043" stop-opacity="0.9" />
                                                            <stop offset="1" stop-color="#FF4235" stop-opacity="0" />
                                                        </linearGradient>
                                                    </defs>
                                                </svg>
                                            </div>
                                        </div>
                                        <div class="middle-show-red show-mobile-landscape">
                                            <div class="embed h-100 w-embed">
                                                <svg width="118" height="274" viewBox="0 0 118 274" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                    <path d="M117.999 -199C55.5181 -72.7606 -36.5357 81.2069 15.1657 226.769C99.9957 465.601 15.1658 525 15.1658 525H118L117.999 -199Z" fill="url(#paint0_linear_4150_23828)" />
                                                    <defs>
                                                        <linearGradient id="paint0_linear_4150_23828" x1="-39.3256" y1="217.826" x2="124.87" y2="217.826" gradientUnits="userSpaceOnUse">
                                                            <stop stop-color="#E83043" stop-opacity="0.9" />
                                                            <stop offset="1" stop-color="#FF4235" stop-opacity="0" />
                                                        </linearGradient>
                                                    </defs>
                                                </svg>
                                            </div>
                                        </div>
                                        <div class="position-relative">
                                            <div class="margin-bottom-16">
                                                <div class="heading-24 set-text-size-20 text-weight-semibold">
                                                    Secure affiliate income
                                                </div>
                                            </div>
                                            <div class="text-color-gray-300">Earn passive income from your referrals&#x27; spending and get a bonus for each signup.</div>
                                        </div>
                                        <div class="position-relative">
                                            <div class="slider-price-box">
                                                <div class="slide-discount-box">
                                                    <div class="max-width-48">
                                                        <div class="text-size-12 text-weight-semibold text-color-gray-300">
                                                            You earn
                                                        </div>
                                                    </div>
                                                    <div class="flex-full">
                                                        <div class="heading-36 letter-spacing-minus-2 text-align-center">
                                                            5
                                                        </div>
                                                    </div>
                                                    <div class="max-width-48">
                                                        <div class="text-size-12 text-weight-medium text-color-gray-300">
                                                            per new signup
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="hero-meta-slide-box pad-24 _282 splide__slide">
                                        <div class="slide-full-bottom-image-box hide-mobile-landscape">
                                            <div class="embed w-embed">
                                                <svg width="282" height="158" viewBox="0 0 282 158" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                    <path
                                                        d="M-16.8066 158L-16.8066 75.9987C-16.8066 75.9987 170.357 -97.5256 430.001 81.4109C689.645 260.348 802.988 87.2338 802.988 87.2338L802.988 158L-16.8066 158Z"
                                                        fill="url(#paint0_linear_663_719)"
                                                    />
                                                    <defs>
                                                        <linearGradient id="paint0_linear_663_719" x1="393.091" y1="49.7355" x2="393.091" y2="162.728" gradientUnits="userSpaceOnUse">
                                                            <stop stop-color="#E83043" stop-opacity="0.9" />
                                                            <stop offset="1" stop-color="#FF4235" stop-opacity="0" />
                                                        </linearGradient>
                                                    </defs>
                                                </svg>
                                            </div>
                                        </div>
                                        <div class="position-relative">
                                            <div class="margin-bottom-16">
                                                <div class="heading-24 set-text-size-20 text-weight-semibold">
                                                    Whitelabel &amp; resell
                                                </div>
                                            </div>
                                            <div class="text-color-gray-300">Unlock additional income streams.</div>
                                        </div>
                                        <div class="position-relative">
                                            <div class="slide-inner-flex-box center">
                                                <div class="embed w-embed">
                                                    <svg width="74" height="93" viewBox="0 0 74 93" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                        <g clip-path="url(#clip0_1_55641)">
                                                            <path
                                                                d="M73.9998 20.5488C73.9998 21.0922 73.7832 21.6133 73.3977 21.9975C73.0122 22.3817 72.4894 22.5976 71.9442 22.5976C71.3991 22.5976 70.8762 22.3817 70.4907 21.9975C70.1052 21.6133 69.8887 21.0922 69.8887 20.5488C69.8887 20.0054 70.1052 19.4843 70.4907 19.1001C70.8762 18.7159 71.3991 18.5 71.9442 18.5C72.4894 18.5 73.0122 18.7159 73.3977 19.1001C73.7832 19.4843 73.9998 20.0054 73.9998 20.5488Z"
                                                                fill="white"
                                                            />
                                                            <path
                                                                fill-rule="evenodd"
                                                                clip-rule="evenodd"
                                                                d="M18.8426 74.2185C8.436 74.2185 0 65.8103 0 55.438V19.8657H6.85185V55.438C6.85185 58.6077 8.11516 61.6475 10.3639 63.8888C12.6126 66.1301 15.6625 67.3892 18.8426 67.3892C25.5478 67.3892 30.8333 62.2386 30.8333 55.7194H37.6852V65.9633C37.6852 66.4161 37.8657 66.8504 38.1869 67.1705C38.5081 67.4907 38.9438 67.6706 39.3981 67.6706C39.8525 67.6706 40.2882 67.4907 40.6094 67.1705C40.9306 66.8504 41.1111 66.4161 41.1111 65.9633V53.8413C39.8666 54.0945 38.5811 54.0687 37.3479 53.7656C36.1146 53.4625 34.9644 52.8899 33.9806 52.0891C32.9968 51.2883 32.204 50.2794 31.6597 49.1356C31.1153 47.9917 30.8331 46.7415 30.8333 45.4755V28.4023C30.8333 26.1383 31.7357 23.967 33.3419 22.366C34.9481 20.7651 37.1266 19.8657 39.3981 19.8657C41.6697 19.8657 43.8482 20.7651 45.4544 22.366C47.0606 23.967 47.963 26.1383 47.963 28.4023V65.9633C47.963 66.4161 48.1434 66.8504 48.4647 67.1705C48.7859 67.4907 49.2216 67.6706 49.6759 67.6706C50.1302 67.6706 50.5659 67.4907 50.8872 67.1705C51.2084 66.8504 51.3889 66.4161 51.3889 65.9633V28.4023C51.3889 26.1383 52.2912 23.967 53.8975 22.366C55.5037 20.7651 57.6822 19.8657 59.9537 19.8657C62.2252 19.8657 64.4037 20.7651 66.0099 22.366C67.6162 23.967 68.5185 26.1383 68.5185 28.4023V65.9633C68.5185 67.5486 68.0756 69.1027 67.2394 70.4512C66.4031 71.7998 65.2067 72.8897 63.784 73.5986C62.3613 74.3076 60.7687 74.6077 59.1845 74.4654C57.6004 74.323 56.0873 73.7438 54.8148 72.7926C53.3336 73.9033 51.5295 74.5026 49.6759 74.4999C47.8223 74.5026 46.0183 73.9033 44.537 72.7926C43.5062 73.563 42.3143 74.0918 41.05 74.3395C39.7857 74.5872 38.4817 74.5475 37.2349 74.2232C35.9882 73.899 34.8309 73.2986 33.8492 72.4668C32.8676 71.635 32.0868 70.5931 31.5651 69.4189C28.1995 72.4197 23.7225 74.2185 18.8426 74.2185ZM59.9537 67.6706C59.0081 67.6706 58.2407 66.9057 58.2407 65.9633V28.4023C58.2407 27.9495 58.4212 27.5152 58.7425 27.1951C59.0637 26.8749 59.4994 26.695 59.9537 26.695C60.408 26.695 60.8437 26.8749 61.165 27.1951C61.4862 27.5152 61.6667 27.9495 61.6667 28.4023V65.9633C61.6667 66.9057 60.8993 67.6706 59.9537 67.6706ZM41.1111 45.4755C41.1111 45.9283 40.9306 46.3626 40.6094 46.6827C40.2882 47.0029 39.8525 47.1828 39.3981 47.1828C38.9438 47.1828 38.5081 47.0029 38.1869 46.6827C37.8657 46.3626 37.6852 45.9283 37.6852 45.4755V28.4023C37.6852 27.9495 37.8657 27.5152 38.1869 27.1951C38.5081 26.8749 38.9438 26.695 39.3981 26.695C39.8525 26.695 40.2882 26.8749 40.6094 27.1951C40.9306 27.5152 41.1111 27.9495 41.1111 28.4023V45.4755Z"
                                                                fill="white"
                                                            />
                                                            <path
                                                                fill-rule="evenodd"
                                                                clip-rule="evenodd"
                                                                d="M10.2778 55.7194C10.2778 57.9834 11.1802 60.1547 12.7864 61.7557C14.3926 63.3566 16.5711 64.256 18.8426 64.256C21.1142 64.256 23.2927 63.3566 24.8989 61.7557C26.5051 60.1547 27.4075 57.9834 27.4075 55.7194V28.4023C27.4075 26.1383 26.5051 23.967 24.8989 22.366C23.2927 20.7651 21.1142 19.8657 18.8426 19.8657C16.5711 19.8657 14.3926 20.7651 12.7864 22.366C11.1802 23.967 10.2778 26.1383 10.2778 28.4023V55.7194ZM18.8426 57.4267C17.8971 57.4267 17.1297 56.6618 17.1297 55.7194V28.4023C17.1297 27.9495 17.3102 27.5152 17.6314 27.1951C17.9526 26.8749 18.3883 26.695 18.8426 26.695C19.297 26.695 19.7327 26.8749 20.0539 27.1951C20.3751 27.5152 20.5556 27.9495 20.5556 28.4023V55.7194C20.5556 56.6618 19.7882 57.4267 18.8426 57.4267Z"
                                                                fill="white"
                                                            />
                                                        </g>
                                                        <defs>
                                                            <clipPath id="clip0_1_55641">
                                                                <rect width="74" height="56" fill="white" transform="translate(0 18.5)" />
                                                            </clipPath>
                                                        </defs>
                                                    </svg>
                                                </div>
                                                <div class="text-color-gray-300 set-text-size-14">Resell our agency accounts under your brand.</div>
                                            </div>
                                        </div>
                                        <div class="top-side-red show-mobile-landscape">
                                            <div class="embed w-embed">
                                                <svg width="177" height="259" viewBox="0 0 177 259" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                    <path
                                                        d="M172.109 -507.5L82.5271 -507.5C82.5271 -507.5 -107.04 -301.569 88.4397 -15.8886C283.919 269.791 94.8009 394.5 94.8009 394.5H172.109L172.109 -507.5Z"
                                                        fill="url(#paint0_linear_4150_23724)"
                                                    />
                                                    <defs>
                                                        <linearGradient id="paint0_linear_4150_23724" x1="53.8358" y1="-56.5" x2="177.274" y2="-56.5" gradientUnits="userSpaceOnUse">
                                                            <stop stop-color="#E83043" stop-opacity="0.9" />
                                                            <stop offset="1" stop-color="#FF4235" stop-opacity="0" />
                                                        </linearGradient>
                                                    </defs>
                                                </svg>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="meta-hero-progress-bar hide-this">
                                <div class="slider-dot active"></div>
                                <div class="slider-dot"></div>
                                <div class="slider-dot"></div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<div class="section_platform-about">
    <div class="margin-bottom-48 set-margin-bottom-32">
        <div class="padding-global">
            <div class="container-1600">
                <div class="header-section">
                    <div class="header-tag">
                        <div>About agency accounts</div>
                    </div>
                    <h2>Drive effortless growth with advertising accounts that have an edge</h2>
                    <div class="text-size-20 text-color-gray-300 set-text-size-18">
                        Increase profitability, reduce advertising restrictions and unlock unlimited scaling potential. Supporting international businesses, agencies, brands and more.
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="margin-bottom-48 set-margin-bottom-32">
        <div class="position-relative">
            <div class="white-line-bg">
                <div class="bg-white-line"></div>
            </div>
            <div class="position-relative">
                <div class="padding-global">
                    <div class="container-1600">
                        <div class="platform-about-component">
                            <div class="max-width-788">
                                <div class="image-box"><img src="/assets/img2.png" loading="lazy" sizes="(max-width: 788px) 100vw, 788px" alt="AdsAsia Dashboard" /></div>
                            </div>
                            <div class="flex-full">
                                <div class="margin-bottom-16">
                                    <h3>Rapid scale, without restrictions</h3>
                                </div>
                                <div>
                                    Whitelisted or Agency Advertising Accounts are special ad accounts that are used by enterprise-level companies to allow faster growth, consistent scalability and high profitability - without restrictions.
                                    <br />
                                    <br />
                                    With AdsAsia, you can advertise on the same type of ad account used by the world's leading brands and household names.<br />
                                    <br />
                                    This can mean lower costs, cashback, quicker ad approvals, and compliance support for higher-risk industries and verticals. Plus, no more risk of losing your ad account and turning your revenue to zero.
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="padding-global">
        <div class="container-1600">
            <div class="platform-about-attributes-component">
                <div class="flex-full">
                    <div class="platform-about-attribute-box">
                        <div class="embed w-embed">
                            <svg width="48" height="48" viewBox="0 0 48 48" fill="none" xmlns="http://www.w3.org/2000/svg">
                                <rect width="48" height="48" fill="#101828" />
                                <path
                                    d="M10.0001 21.4287C12.2063 21.4287 14.0001 19.5709 14.0001 17.2858C14.0001 15.0007 12.2063 13.1429 10.0001 13.1429C7.79379 13.1429 6.00002 15.0007 6.00002 17.2858C6.00002 19.5709 7.79379 21.4287 10.0001 21.4287ZM24.0002 23.5001C27.869 23.5001 31.0003 20.257 31.0003 16.2501C31.0003 12.2431 27.869 9 24.0002 9C20.1314 9 17.0001 12.2431 17.0001 16.2501C17.0001 20.257 20.1314 23.5001 24.0002 23.5001ZM28.8002 25.5716H28.2815C26.9815 26.2189 25.5377 26.6073 24.0002 26.6073C22.4627 26.6073 21.0252 26.2189 19.7189 25.5716H19.2002C15.2251 25.5716 12.0001 28.9118 12.0001 33.0288V34.8931C12.0001 36.6085 13.3438 38.0003 15.0001 38.0003H33.0003C34.6566 38.0003 36.0003 36.6085 36.0003 34.8931V33.0288C36.0003 28.9118 32.7753 25.5716 28.8002 25.5716ZM14.8189 24.7042C14.0939 23.9597 13.1001 23.5001 12.0001 23.5001H8.00004C5.79377 23.5001 4 25.358 4 27.643V29.7145C4 30.8603 4.89376 31.7859 6.00002 31.7859H10.1188C10.5126 28.7176 12.3001 26.1348 14.8189 24.7042Z"
                                    fill="#E9394B"
                                />
                                <g style="mix-blend-mode: plus-lighter;" opacity="0.5">
                                    <path
                                        fill-rule="evenodd"
                                        clip-rule="evenodd"
                                        d="M44 35C44 39.9706 39.9706 44 35 44C30.0294 44 26 39.9706 26 35C26 30.0294 30.0294 26 35 26C39.9706 26 44 30.0294 44 35ZM39.6873 32.9373C40.0387 32.5858 40.0387 32.016 39.6873 31.6645C39.3358 31.313 38.7659 31.313 38.4145 31.6645L33.6509 36.4281L31.5873 34.3645C31.2358 34.013 30.6659 34.013 30.3145 34.3645C29.963 34.716 29.963 35.2858 30.3145 35.6373L33.0145 38.3373C33.1832 38.5061 33.4122 38.6009 33.6509 38.6009C33.8896 38.6009 34.1185 38.5061 34.2873 38.3373L39.6873 32.9373Z"
                                        fill="white"
                                    />
                                </g>
                            </svg>
                        </div>
                        <div>
                            <div class="margin-bottom-8">
                                <h4>Campaign and industry approval</h4>
                            </div>
                            <div class="text-color-gray-300">
                                Agency accounts are always pre-approved for the content that you specifically want to advertise. This involves getting an account created specifically for your website and campaigns.
                            </div>
                        </div>
                    </div>
                </div>
                <div class="flex-full">
                    <div class="platform-about-attribute-box">
                        <div class="embed w-embed">
                            <svg width="48" height="48" viewBox="0 0 48 48" fill="none" xmlns="http://www.w3.org/2000/svg">
                                <path
                                    fill-rule="evenodd"
                                    clip-rule="evenodd"
                                    d="M14 24C19.5228 24 24 19.5228 24 14C24 8.47715 19.5228 4 14 4C8.47715 4 4 8.47715 4 14C4 19.5228 8.47715 24 14 24ZM17.1819 10.6665C17.1819 12.5088 15.7586 13.9999 14 13.9999C12.2415 13.9999 10.8182 12.5088 10.8182 10.6665C10.8182 8.82427 12.2415 7.3332 14 7.3332C15.7586 7.3332 17.1819 8.82427 17.1819 10.6665ZM15.9461 14.9522H16.1819C17.9887 14.9522 19.4546 16.488 19.4546 18.3808V19.238C19.4546 20.0266 18.8438 20.6665 18.0909 20.6665H9.90913C9.15629 20.6665 8.54549 20.0266 8.54549 19.238V18.3808C8.54549 16.488 10.0114 14.9522 11.8182 14.9522H12.054C12.6478 15.2499 13.3012 15.4284 14 15.4284C14.6989 15.4284 15.3552 15.2499 15.9461 14.9522Z"
                                    fill="#E9394B"
                                />
                                <path
                                    fill-rule="evenodd"
                                    clip-rule="evenodd"
                                    d="M34 44C39.5228 44 44 39.5228 44 34C44 28.4772 39.5228 24 34 24C28.4772 24 24 28.4772 24 34C24 39.5228 28.4772 44 34 44ZM37.1819 30.6665C37.1819 32.5088 35.7586 33.9999 34 33.9999C32.2415 33.9999 30.8182 32.5088 30.8182 30.6665C30.8182 28.8243 32.2415 27.3332 34 27.3332C35.7586 27.3332 37.1819 28.8243 37.1819 30.6665ZM35.9461 34.9522H36.1819C37.9887 34.9522 39.4546 36.488 39.4546 38.3808V39.238C39.4546 40.0266 38.8438 40.6665 38.0909 40.6665H29.9091C29.1563 40.6665 28.5455 40.0266 28.5455 39.238V38.3808C28.5455 36.488 30.0114 34.9522 31.8182 34.9522H32.054C32.6478 35.2499 33.3012 35.4284 34 35.4284C34.6989 35.4284 35.3552 35.2499 35.9461 34.9522Z"
                                    fill="#E9394B"
                                />
                                <g style="mix-blend-mode: plus-lighter;" opacity="0.5">
                                    <path d="M26 36C17.5 36 14 29.5 14 22.0001M14 22.0001L10 26.0001M14 22.0001L18 26.0001" stroke="white" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" />
                                </g>
                                <g style="mix-blend-mode: plus-lighter;" opacity="0.5">
                                    <path d="M22 12C30.5 12 34 18.5 34 25.9999M34 25.9999L38 21.9999M34 25.9999L30 21.9999" stroke="white" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" />
                                </g>
                            </svg>
                        </div>
                        <div>
                            <div class="margin-bottom-8">
                                <h4>Platform representative direct support</h4>
                            </div>
                            <div class="text-color-gray-300">Clients of agency accounts typically need more hands-on, direct support. The digital platform will assign specialist representatives to handle all advertising queries.</div>
                        </div>
                    </div>
                </div>
                <div class="flex-full">
                    <div class="platform-about-attribute-box">
                        <div class="embed w-embed">
                            <svg width="48" height="48" viewBox="0 0 48 48" fill="none" xmlns="http://www.w3.org/2000/svg">
                                <rect width="48" height="48" fill="#101828" />
                                <path
                                    d="M10 21.4286C12.2063 21.4286 14 19.5708 14 17.2857C14 15.0007 12.2063 13.1429 10 13.1429C7.79375 13.1429 6 15.0007 6 17.2857C6 19.5708 7.79375 21.4286 10 21.4286ZM38 21.4286C40.2062 21.4286 42 19.5708 42 17.2857C42 15.0007 40.2062 13.1429 38 13.1429C35.7938 13.1429 34 15.0007 34 17.2857C34 19.5708 35.7938 21.4286 38 21.4286ZM40 23.5H36C34.9 23.5 33.9062 23.9596 33.1812 24.704C35.7 26.1346 37.4875 28.7174 37.875 31.7857H42C43.1063 31.7857 44 30.86 44 29.7143V27.6429C44 25.3578 42.2062 23.5 40 23.5ZM24 23.5C27.8687 23.5 31 20.2569 31 16.25C31 12.2431 27.8687 9 24 9C20.1313 9 17 12.2431 17 16.25C17 20.2569 20.1313 23.5 24 23.5ZM28.8 25.5714H28.2812C26.9813 26.2188 25.5375 26.6071 24 26.6071C22.4625 26.6071 21.025 26.2188 19.7188 25.5714H19.2C15.225 25.5714 12 28.9116 12 33.0286V34.8929C12 36.6083 13.3438 38 15 38H33C34.6562 38 36 36.6083 36 34.8929V33.0286C36 28.9116 32.775 25.5714 28.8 25.5714ZM14.8188 24.704C14.0938 23.9596 13.1 23.5 12 23.5H8C5.79375 23.5 4 25.3578 4 27.6429V29.7143C4 30.86 4.89375 31.7857 6 31.7857H10.1188C10.5125 28.7174 12.3 26.1346 14.8188 24.704Z"
                                    fill="#E9394B"
                                />
                                <g style="mix-blend-mode: plus-lighter;" opacity="0.5">
                                    <path
                                        d="M43 31.3359C43.0007 30.1004 42.6821 28.8847 42.0736 27.8018C41.465 26.7189 40.5864 25.8039 39.5193 25.1417C38.4523 24.4796 37.2313 24.0918 35.9698 24.0144C34.7084 23.937 33.4474 24.1725 32.304 24.699C31.1606 25.2255 30.1718 26.0259 29.4296 27.026C28.6873 28.026 28.2156 29.1932 28.0583 30.4191C27.901 31.645 28.0632 32.8899 28.5298 34.0382C28.9964 35.1864 29.7523 36.2008 30.7273 36.9871V43.333C30.7272 43.4467 30.7568 43.5585 30.8134 43.6578C30.87 43.7571 30.9516 43.8406 31.0505 43.9004C31.1494 43.9602 31.2623 43.9942 31.3785 43.9993C31.4946 44.0044 31.6102 43.9804 31.7142 43.9295L35.5 42.0833L39.2866 43.9337C39.3816 43.978 39.4857 44.0005 39.5909 43.9995C39.7717 43.9995 39.9452 43.9293 40.073 43.8043C40.2009 43.6793 40.2727 43.5098 40.2727 43.333V36.9871C41.1258 36.3002 41.8127 35.4373 42.2843 34.4603C42.7558 33.4832 43.0002 32.4162 43 31.3359ZM29.3636 31.3359C29.3636 30.1495 29.7235 28.9898 30.3978 28.0033C31.0721 27.0168 32.0304 26.248 33.1517 25.794C34.273 25.34 35.5068 25.2212 36.6971 25.4526C37.8875 25.6841 38.9809 26.2554 39.8391 27.0943C40.6972 27.9332 41.2817 29.0021 41.5185 30.1657C41.7552 31.3293 41.6337 32.5354 41.1693 33.6315C40.7048 34.7276 39.9183 35.6644 38.9092 36.3235C37.9001 36.9827 36.7137 37.3345 35.5 37.3345C33.8731 37.3327 32.3133 36.7001 31.1629 35.5756C30.0125 34.451 29.3654 32.9263 29.3636 31.3359ZM30.7273 31.3359C30.7273 30.4132 31.0072 29.5111 31.5316 28.7439C32.0561 27.9766 32.8015 27.3786 33.6736 27.0255C34.5457 26.6724 35.5053 26.58 36.4311 26.76C37.3569 26.94 38.2073 27.3844 38.8748 28.0369C39.5423 28.6894 39.9969 29.5207 40.181 30.4257C40.3652 31.3307 40.2707 32.2688 39.9094 33.1213C39.5482 33.9739 38.9365 34.7025 38.1516 35.2152C37.3667 35.7278 36.444 36.0015 35.5 36.0015C34.2346 36.0001 33.0214 35.5082 32.1267 34.6335C31.2319 33.7588 30.7286 32.5729 30.7273 31.3359Z"
                                        fill="white"
                                    />
                                </g>
                                <g style="mix-blend-mode: plus-lighter;" opacity="0.5">
                                    <path
                                        d="M23.6904 34.2155C23.7968 33.9282 24.2032 33.9282 24.3096 34.2155L25.1954 36.6096C25.2289 36.6999 25.3001 36.7711 25.3904 36.8046L27.7845 37.6904C28.0718 37.7968 28.0718 38.2032 27.7845 38.3096L25.3904 39.1954C25.3001 39.2289 25.2289 39.3001 25.1954 39.3904L24.3096 41.7845C24.2032 42.0718 23.7968 42.0718 23.6904 41.7845L22.8046 39.3904C22.7711 39.3001 22.6999 39.2289 22.6096 39.1954L20.2155 38.3096C19.9282 38.2032 19.9282 37.7968 20.2155 37.6904L22.6096 36.8046C22.6999 36.7711 22.7711 36.6999 22.8046 36.6096L23.6904 34.2155Z"
                                        fill="white"
                                    />
                                </g>
                            </svg>
                        </div>
                        <div>
                            <div class="margin-bottom-8">
                                <h4>High trust tier accounts with an Edge</h4>
                            </div>
                            <div class="text-color-gray-300">
                                Accounts that are issued from official platform resellers are the highest internal trust tier from day one. This means no warming up, no random restrictions and no spending limits.
                            </div>
                        </div>
                    </div>
                </div>
                <div class="flex-full">
                    <div class="platform-about-attribute-box">
                        <div class="embed w-embed">
                            <svg width="48" height="48" viewBox="0 0 48 48" fill="none" xmlns="http://www.w3.org/2000/svg">
                                <path
                                    fill-rule="evenodd"
                                    clip-rule="evenodd"
                                    d="M8.79805 13.998C6.14708 13.998 3.99805 16.1471 3.99805 18.7981V34.2007C3.99805 36.8517 6.14708 39.0007 8.79805 39.0007H34.2017C36.8527 39.0007 39.0017 36.8517 39.0017 34.2007V18.798C39.0017 16.1471 36.8527 13.998 34.2017 13.998H8.79805ZM10.2487 31.85C9.75165 31.85 9.34871 32.253 9.34871 32.75C9.34871 33.2471 9.75165 33.65 10.2487 33.65H32.7511C33.2481 33.65 33.6511 33.2471 33.6511 32.75C33.6511 32.253 33.2481 31.85 32.7511 31.85H10.2487Z"
                                    fill="#E9394B"
                                />
                                <g style="mix-blend-mode: plus-lighter;" opacity="0.5">
                                    <path
                                        fill-rule="evenodd"
                                        clip-rule="evenodd"
                                        d="M22 9C19.7909 9 18 10.7909 18 13C18 15.2091 19.7909 17 22 17H40C42.2091 17 44 15.2091 44 13C44 10.7909 42.2091 9 40 9H22ZM22 15C23.1046 15 24 14.1046 24 13C24 11.8954 23.1046 11 22 11C20.8954 11 20 11.8954 20 13C20 14.1046 20.8954 15 22 15Z"
                                        fill="white"
                                    />
                                </g>
                                <g style="mix-blend-mode: plus-lighter;" opacity="0.5">
                                    <path
                                        fill-rule="evenodd"
                                        clip-rule="evenodd"
                                        d="M40 19C42.2091 19 44 20.7909 44 23C44 25.2091 42.2091 27 40 27H22C19.7909 27 18 25.2091 18 23C18 20.7909 19.7909 19 22 19H40ZM40 25C38.8954 25 38 24.1046 38 23C38 21.8954 38.8954 21 40 21C41.1046 21 42 21.8954 42 23C42 24.1046 41.1046 25 40 25Z"
                                        fill="white"
                                    />
                                </g>
                            </svg>
                        </div>
                        <div>
                            <div class="margin-bottom-8">
                                <h4>Payment solutions for cashflow advantages</h4>
                            </div>
                            <div class="text-color-gray-300">
                                Increase scalability by utilizing payment solutions that can maximize your cashflow. Use crypto, credit cards, wire transfers and more to effectively manage your advertising spend.
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<div class="section_platform-whitelist">
    <div id="follow-mouse" class="whitelist-mouse-red"></div>
    <div class="platform-whitelist-bg-box"><img src="https://cdn.prod.website-files.com/668b3733f80ed0dcd2c46207/668e55f07943f3ffb113e2af_bg-box.svg" loading="lazy" alt="" class="full-image" /></div>
    <div class="gradient-mobile"></div>
    <div class="position-relative">
        <div class="padding-global">
            <div class="container-1600">
                <div class="margin-bottom-48">
                    <div class="header-section">
                        <div class="header-tag bg-color-gray-700">
                            <div>AdsAsia accounts</div>
                        </div>
                        <h2>Whitelisted advertising without limits</h2>
                        <div class="text-size-20 text-color-gray-300">
                            Our agency advertising accounts provide an effortless advertising experience. Reduce bans and remove restrictions on advertising by using whitelisted accounts approved by <?php echo $platform ?> for enterprise companies. Plus full, dedicated support and auction advantages.
                        </div>
                    </div>
                </div>
                <div class="platform-whitelist-grid hide-mobile-landscape">
                    <div class="platform-whitelist-box">
                        <div class="margin-bottom-16">
                            <h4>Whitelisted accounts</h4>
                        </div>
                        <div class="text-color-gray-300">Highest tier accounts available, designed for enterprise companies. Issued from <?php echo $platform ?> directly.</div>
                    </div>
                    <div class="platform-whitelist-box">
                        <div class="margin-bottom-16">
                            <h4>Dedicated support</h4>
                        </div>
                        <div class="text-color-gray-300">Expert account managers provide hands-on support, 7 days a week, for all your advertising queries.</div>
                    </div>
                    <div class="platform-whitelist-box">
                        <div class="margin-bottom-16">
                            <h4>Cashback on spend</h4>
                        </div>
                        <div class="text-color-gray-300">Increase your margins and receive cashback on your advertising spend as bank deposits or ad credit.</div>
                    </div>
                    <div class="platform-whitelist-box">
                        <div class="margin-bottom-16">
                            <h4>Fast account creation</h4>
                        </div>
                        <div class="text-color-gray-300">Avoid downtime with fast account creation, getting your campaigns live within 24 hours.</div>
                    </div>
                    <div class="platform-whitelist-box">
                        <div class="margin-bottom-16">
                            <h4>No random restrictions</h4>
                        </div>
                        <div class="text-color-gray-300">High-trust accounts for stability and consistency. No more random bans or issues.</div>
                    </div>
                    <div class="platform-whitelist-box">
                        <div class="margin-bottom-16">
                            <h4>Auction advantage</h4>
                        </div>
                        <div class="text-color-gray-300">Scale campaigns quickly and get cheaper results with our trusted accounts, featuring lower CPM and CPA.</div>
                    </div>
                    <div class="platform-whitelist-box">
                        <div class="margin-bottom-16">
                            <h4>Ads in restricted niches</h4>
                        </div>
                        <div class="text-color-gray-300">Support campaigns in restricted niches. Our team provides expert solutions for any advertising goal.</div>
                    </div>
                    <div class="platform-whitelist-box">
                        <div class="margin-bottom-16">
                            <h4>Market leading insights</h4>
                        </div>
                        <div class="text-color-gray-300">Get industry insights from online ad leaders and access AdsAsia's Aducation platform in our app.</div>
                    </div>
                    <div class="platform-whitelist-box">
                        <div class="margin-bottom-16">
                            <h4>Payment solutions</h4>
                        </div>
                        <div class="text-color-gray-300">Support your cashflow with diverse payment options for advertising spend, including cards, crypto, and transfers.</div>
                    </div>
                    <div class="platform-whitelist-box">
                        <div class="margin-bottom-16">
                            <h4>Replacement assets</h4>
                        </div>
                        <div class="text-color-gray-300">Advertise consistently with unlimited replacement assets and sustainable advertising guides.</div>
                    </div>
                    <div class="platform-whitelist-box">
                        <div class="margin-bottom-16">
                            <h4>Easy account recovery</h4>
                        </div>
                        <div class="text-color-gray-300">Restore advertising on banned accounts, or replace them and move your funds.</div>
                    </div>
                    <div class="platform-whitelist-box">
                        <div class="margin-bottom-16">
                            <h4>Unlimited accounts</h4>
                        </div>
                        <div class="text-color-gray-300">Create unlimited accounts for any niche and campaign goal, delivered within one working day.</div>
                    </div>
                </div>
                <div class="show-mobile-landscape">
                    <div
                        data-delay="4000"
                        data-animation="slide"
                        class="auto-slider w-slider"
                        data-autoplay="false"
                        data-mobile-slider="1"
                        data-easing="ease"
                        data-hide-arrows="false"
                        data-disable-swipe="false"
                        data-autoplay-limit="0"
                        data-nav-spacing="3"
                        data-duration="500"
                        data-infinite="true"
                    >
                        <div class="auto-mask w-slider-mask">
                            <div class="w-slide">
                                <div class="mobile-flex-24">
                                    <div class="platform-whitelist-box">
                                        <div class="margin-bottom-16">
                                            <h4>Whitelisted accounts</h4>
                                        </div>
                                        <div class="text-color-gray-300">Highest tier accounts available, designed for enterprise companies. Issued from <?php echo $platform ?> directly.</div>
                                    </div>
                                    <div class="platform-whitelist-box">
                                        <div class="margin-bottom-16">
                                            <h4>Dedicated support</h4>
                                        </div>
                                        <div class="text-color-gray-300">Expert account managers provide hands-on support, 7 days a week, for all your advertising queries.</div>
                                    </div>
                                    <div class="platform-whitelist-box">
                                        <div class="margin-bottom-16">
                                            <h4>Cashback on spend</h4>
                                        </div>
                                        <div class="text-color-gray-300">Increase your margins and receive cashback on your advertising spend as bank deposits or ad credit.</div>
                                    </div>
                                </div>
                            </div>
                            <div class="w-slide">
                                <div class="mobile-flex-24">
                                    <div class="platform-whitelist-box">
                                        <div class="margin-bottom-16">
                                            <h4>Fast account creation</h4>
                                        </div>
                                        <div class="text-color-gray-300">Avoid downtime with fast account creation, getting your campaigns live within 24 hours.</div>
                                    </div>
                                    <div class="platform-whitelist-box">
                                        <div class="margin-bottom-16">
                                            <h4>No random restrictions</h4>
                                        </div>
                                        <div class="text-color-gray-300">High-trust accounts for stability and consistency. No more random bans or issues.</div>
                                    </div>
                                    <div class="platform-whitelist-box">
                                        <div class="margin-bottom-16">
                                            <h4>Auction advantage</h4>
                                        </div>
                                        <div class="text-color-gray-300">Scale campaigns quickly and get cheaper results with our trusted accounts, featuring lower CPM and CPA.</div>
                                    </div>
                                </div>
                            </div>
                            <div class="w-slide">
                                <div class="mobile-flex-24">
                                    <div class="platform-whitelist-box">
                                        <div class="margin-bottom-16">
                                            <h4>Ads in restricted niches</h4>
                                        </div>
                                        <div class="text-color-gray-300">Support campaigns in restricted niches. Our team provides expert solutions for any advertising goal.</div>
                                    </div>
                                    <div class="platform-whitelist-box">
                                        <div class="margin-bottom-16">
                                            <h4>Market leading insights</h4>
                                        </div>
                                        <div class="text-color-gray-300">Get industry insights from online ad leaders and access AdsAsia's Aducation platform in our app.</div>
                                    </div>
                                    <div class="platform-whitelist-box">
                                        <div class="margin-bottom-16">
                                            <h4>Payment solutions</h4>
                                        </div>
                                        <div class="text-color-gray-300">Support your cashflow with diverse payment options for advertising spend, including cards, crypto, and transfers.</div>
                                    </div>
                                </div>
                            </div>
                            <div class="w-slide">
                                <div class="mobile-flex-24">
                                    <div class="platform-whitelist-box">
                                        <div class="margin-bottom-16">
                                            <h4>Replacement assets</h4>
                                        </div>
                                        <div class="text-color-gray-300">Advertise consistently with unlimited replacement assets and sustainable advertising guides.</div>
                                    </div>
                                    <div class="platform-whitelist-box">
                                        <div class="margin-bottom-16">
                                            <h4>Easy account recovery</h4>
                                        </div>
                                        <div class="text-color-gray-300">Restore advertising on banned accounts, or replace them and move your funds.</div>
                                    </div>
                                    <div class="platform-whitelist-box">
                                        <div class="margin-bottom-16">
                                            <h4>Unlimited accounts</h4>
                                        </div>
                                        <div class="text-color-gray-300">Create unlimited accounts for any niche and campaign goal, delivered within one working day.</div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div data-left="1" class="hide auto-left-button w-slider-arrow-left">
                            <div class="w-icon-slider-left"></div>
                        </div>
                        <div data-right="1" class="hide auto-right-button w-slider-arrow-right">
                            <div class="w-icon-slider-right"></div>
                        </div>
                        <div class="hide w-slider-nav w-round w-num"></div>
                        <div class="spacer-24"></div>
                        <div class="platform-slider-arrows">
                            <div data-button-left="1" class="auto-left-arrow this-arrow">
                                <div class="fix-24">
                                    <div data-button-icon="normal" class="embed w-embed">
                                        <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                                            <path d="M15 18L9 12L15 6" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" />
                                        </svg>
                                    </div>
                                    <div data-button-icon="hover" class="embed w-embed">
                                        <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                                            <path d="M19 12H5M5 12L12 19M5 12L12 5" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" />
                                        </svg>
                                    </div>
                                </div>
                            </div>
                            <div data-button-right="1" class="auto-right-arrow this-arrow">
                                <div class="fix-24">
                                    <div data-button-icon="hover" class="embed w-embed">
                                        <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                                            <path d="M5 12H19M19 12L12 5M19 12L12 19" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" />
                                        </svg>
                                    </div>
                                    <div data-button-icon="normal" class="embed w-embed">
                                        <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                                            <path d="M9 18L15 12L9 6" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" />
                                        </svg>
                                    </div>
                                </div>
                            </div>
                            <div class="hide w-embed w-script">
                                <script>
                                    const leftArrow = document.getElementById("ts-left-arrow");
                                    const leftButton = document.getElementById("out-left");
                                    const rightArrow = document.getElementById("ts-right-arrow");
                                    const rightButton = document.getElementById("out-right");

                                    leftButton.addEventListener("click", function (e) {
                                        rightArrow.click();
                                    });

                                    rightButton.addEventListener("click", function (e) {
                                        leftArrow.click();
                                    });
                                </script>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<div class="section_platform-features">
    <div class="padding-global">
        <div class="container-1600">
            <div class="margin-bottom-48">
                <div class="platform-features-header-component">
                    <div class="max-width-1057">
                        <div class="header-section">
                            <div class="header-tag">
                                <div>AdsAsia app features</div>
                            </div>
                            <h2>One dashboard. Unlimited agency accounts.</h2>
                            <div class="text-size-20 text-color-gray-300">
                                Manage all of your advertising in one place. Create agency accounts, view a single account overview, manage finances, appeals and access. Get the speed of self-service management with complete hands-on support.
                            </div>
                        </div>
                    </div>
                    <div>
                        <div class="border-16 border-color-700">
                            <div class="padding-32 set-0">
                                <div class="flex-mobile">
                                    <div class="margin-bottom-24 set-margin-bottom-0">
                                        <div class="heading-60 text-color-red">100,000+</div>
                                    </div>
                                    <div class="text-size-20 text-weight-medium text-color-gray-300 set-text-size-16">
                                        Active ad accounts in Agency AdsAsia
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="platform-features-component">
                <div data-animated="false" data-load="feature" class="platform-feature-box">
                    <div class="flex-full">
                        <div class="platform-feature-image-box">
                            <div><img src="https://cdn.prod.website-files.com/668b3733f80ed0dcd2c46207/668e60b421e6d6d30d59d8f0_p-feature-1.png" loading="lazy" alt="Create agency accounts on demand" /></div>
                        </div>
                    </div>
                    <div class="flex-full">
                        <div class="padding-48">
                            <div class="margin-bottom-32">
                                <div class="margin-bottom-8">
                                    <h3>Create agency accounts on demand</h3>
                                </div>
                                <div class="text-color-gray-300">Take control over your own ad account creation process and receive accounts when you need them. All accounts are created new, just for you.</div>
                            </div>
                            <div class="platform-feature-list">
                                <div class="platform-list-item">
                                    <div class="embed w-embed">
                                        <svg width="28" height="29" viewBox="0 0 28 29" fill="none" xmlns="http://www.w3.org/2000/svg">
                                            <g clip-path="url(#clip0_669_8523)">
                                                <path
                                                    fill-rule="evenodd"
                                                    clip-rule="evenodd"
                                                    d="M25.6654 14.6758C25.6654 21.1191 20.442 26.3425 13.9987 26.3425C7.55538 26.3425 2.33203 21.1191 2.33203 14.6758C2.33203 8.2325 7.55538 3.00916 13.9987 3.00916C20.442 3.00916 25.6654 8.2325 25.6654 14.6758ZM20.075 12.0006C20.5306 11.545 20.5306 10.8063 20.075 10.3507C19.6193 9.89509 18.8807 9.89509 18.425 10.3507L12.25 16.5257L9.57496 13.8507C9.11935 13.3951 8.38065 13.3951 7.92504 13.8507C7.46943 14.3063 7.46943 15.045 7.92504 15.5006L11.425 19.0006C11.8807 19.4562 12.6193 19.4562 13.075 19.0006L20.075 12.0006Z"
                                                    fill="white"
                                                />
                                            </g>
                                            <defs>
                                                <clipPath id="clip0_669_8523">
                                                    <rect y="0.675659" width="28" height="28" rx="14" fill="white" />
                                                </clipPath>
                                            </defs>
                                        </svg>
                                    </div>
                                    <div class="text-color-gray-300">Create and receive accounts within 24 hours</div>
                                </div>
                                <div class="platform-list-item">
                                    <div class="embed w-embed">
                                        <svg width="28" height="29" viewBox="0 0 28 29" fill="none" xmlns="http://www.w3.org/2000/svg">
                                            <g clip-path="url(#clip0_669_8523)">
                                                <path
                                                    fill-rule="evenodd"
                                                    clip-rule="evenodd"
                                                    d="M25.6654 14.6758C25.6654 21.1191 20.442 26.3425 13.9987 26.3425C7.55538 26.3425 2.33203 21.1191 2.33203 14.6758C2.33203 8.2325 7.55538 3.00916 13.9987 3.00916C20.442 3.00916 25.6654 8.2325 25.6654 14.6758ZM20.075 12.0006C20.5306 11.545 20.5306 10.8063 20.075 10.3507C19.6193 9.89509 18.8807 9.89509 18.425 10.3507L12.25 16.5257L9.57496 13.8507C9.11935 13.3951 8.38065 13.3951 7.92504 13.8507C7.46943 14.3063 7.46943 15.045 7.92504 15.5006L11.425 19.0006C11.8807 19.4562 12.6193 19.4562 13.075 19.0006L20.075 12.0006Z"
                                                    fill="white"
                                                />
                                            </g>
                                            <defs>
                                                <clipPath id="clip0_669_8523">
                                                    <rect y="0.675659" width="28" height="28" rx="14" fill="white" />
                                                </clipPath>
                                            </defs>
                                        </svg>
                                    </div>
                                    <div class="text-color-gray-300">Advertise any amount of websites, pages and businesses</div>
                                </div>
                                <div class="platform-list-item">
                                    <div class="embed w-embed">
                                        <svg width="28" height="29" viewBox="0 0 28 29" fill="none" xmlns="http://www.w3.org/2000/svg">
                                            <g clip-path="url(#clip0_669_8523)">
                                                <path
                                                    fill-rule="evenodd"
                                                    clip-rule="evenodd"
                                                    d="M25.6654 14.6758C25.6654 21.1191 20.442 26.3425 13.9987 26.3425C7.55538 26.3425 2.33203 21.1191 2.33203 14.6758C2.33203 8.2325 7.55538 3.00916 13.9987 3.00916C20.442 3.00916 25.6654 8.2325 25.6654 14.6758ZM20.075 12.0006C20.5306 11.545 20.5306 10.8063 20.075 10.3507C19.6193 9.89509 18.8807 9.89509 18.425 10.3507L12.25 16.5257L9.57496 13.8507C9.11935 13.3951 8.38065 13.3951 7.92504 13.8507C7.46943 14.3063 7.46943 15.045 7.92504 15.5006L11.425 19.0006C11.8807 19.4562 12.6193 19.4562 13.075 19.0006L20.075 12.0006Z"
                                                    fill="white"
                                                />
                                            </g>
                                            <defs>
                                                <clipPath id="clip0_669_8523">
                                                    <rect y="0.675659" width="28" height="28" rx="14" fill="white" />
                                                </clipPath>
                                            </defs>
                                        </svg>
                                    </div>
                                    <div class="text-color-gray-300">Support for any industry, even restricted and high-risk verticals</div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div data-animated="false" data-load="feature" class="platform-feature-box reverse">
                    <div class="flex-full">
                        <div class="padding-48">
                            <div class="margin-bottom-32">
                                <div class="margin-bottom-8">
                                    <h3>Track and manage account finances</h3>
                                </div>
                                <div class="text-color-gray-300">Assign funds to your accounts whenever you need, from any device. Ensure your accounts never run out of funds and campaigns continue scaling at all times.</div>
                            </div>
                            <div class="platform-feature-list">
                                <div class="platform-list-item">
                                    <div class="embed w-embed">
                                        <svg width="28" height="29" viewBox="0 0 28 29" fill="none" xmlns="http://www.w3.org/2000/svg">
                                            <g clip-path="url(#clip0_669_8523)">
                                                <path
                                                    fill-rule="evenodd"
                                                    clip-rule="evenodd"
                                                    d="M25.6654 14.6758C25.6654 21.1191 20.442 26.3425 13.9987 26.3425C7.55538 26.3425 2.33203 21.1191 2.33203 14.6758C2.33203 8.2325 7.55538 3.00916 13.9987 3.00916C20.442 3.00916 25.6654 8.2325 25.6654 14.6758ZM20.075 12.0006C20.5306 11.545 20.5306 10.8063 20.075 10.3507C19.6193 9.89509 18.8807 9.89509 18.425 10.3507L12.25 16.5257L9.57496 13.8507C9.11935 13.3951 8.38065 13.3951 7.92504 13.8507C7.46943 14.3063 7.46943 15.045 7.92504 15.5006L11.425 19.0006C11.8807 19.4562 12.6193 19.4562 13.075 19.0006L20.075 12.0006Z"
                                                    fill="white"
                                                />
                                            </g>
                                            <defs>
                                                <clipPath id="clip0_669_8523">
                                                    <rect y="0.675659" width="28" height="28" rx="14" fill="white" />
                                                </clipPath>
                                            </defs>
                                        </svg>
                                    </div>
                                    <div class="text-color-gray-300">Top-up your accounts within seconds</div>
                                </div>
                                <div class="platform-list-item">
                                    <div class="embed w-embed">
                                        <svg width="28" height="29" viewBox="0 0 28 29" fill="none" xmlns="http://www.w3.org/2000/svg">
                                            <g clip-path="url(#clip0_669_8523)">
                                                <path
                                                    fill-rule="evenodd"
                                                    clip-rule="evenodd"
                                                    d="M25.6654 14.6758C25.6654 21.1191 20.442 26.3425 13.9987 26.3425C7.55538 26.3425 2.33203 21.1191 2.33203 14.6758C2.33203 8.2325 7.55538 3.00916 13.9987 3.00916C20.442 3.00916 25.6654 8.2325 25.6654 14.6758ZM20.075 12.0006C20.5306 11.545 20.5306 10.8063 20.075 10.3507C19.6193 9.89509 18.8807 9.89509 18.425 10.3507L12.25 16.5257L9.57496 13.8507C9.11935 13.3951 8.38065 13.3951 7.92504 13.8507C7.46943 14.3063 7.46943 15.045 7.92504 15.5006L11.425 19.0006C11.8807 19.4562 12.6193 19.4562 13.075 19.0006L20.075 12.0006Z"
                                                    fill="white"
                                                />
                                            </g>
                                            <defs>
                                                <clipPath id="clip0_669_8523">
                                                    <rect y="0.675659" width="28" height="28" rx="14" fill="white" />
                                                </clipPath>
                                            </defs>
                                        </svg>
                                    </div>
                                    <div class="text-color-gray-300">Pay with any transfer service, card or crypto</div>
                                </div>
                                <div class="platform-list-item">
                                    <div class="embed w-embed">
                                        <svg width="28" height="29" viewBox="0 0 28 29" fill="none" xmlns="http://www.w3.org/2000/svg">
                                            <g clip-path="url(#clip0_669_8523)">
                                                <path
                                                    fill-rule="evenodd"
                                                    clip-rule="evenodd"
                                                    d="M25.6654 14.6758C25.6654 21.1191 20.442 26.3425 13.9987 26.3425C7.55538 26.3425 2.33203 21.1191 2.33203 14.6758C2.33203 8.2325 7.55538 3.00916 13.9987 3.00916C20.442 3.00916 25.6654 8.2325 25.6654 14.6758ZM20.075 12.0006C20.5306 11.545 20.5306 10.8063 20.075 10.3507C19.6193 9.89509 18.8807 9.89509 18.425 10.3507L12.25 16.5257L9.57496 13.8507C9.11935 13.3951 8.38065 13.3951 7.92504 13.8507C7.46943 14.3063 7.46943 15.045 7.92504 15.5006L11.425 19.0006C11.8807 19.4562 12.6193 19.4562 13.075 19.0006L20.075 12.0006Z"
                                                    fill="white"
                                                />
                                            </g>
                                            <defs>
                                                <clipPath id="clip0_669_8523">
                                                    <rect y="0.675659" width="28" height="28" rx="14" fill="white" />
                                                </clipPath>
                                            </defs>
                                        </svg>
                                    </div>
                                    <div class="text-color-gray-300">Track spending across accounts and export invoices</div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="flex-full">
                        <div class="platform-feature-image-box">
                            <div><img src="https://cdn.prod.website-files.com/668b3733f80ed0dcd2c46207/668e60b33048b21659d0bb8a_p-feature-2.png" loading="lazy" alt="Track and manage account finances" /></div>
                        </div>
                    </div>
                </div>
                <div data-animated="false" data-load="feature" class="platform-feature-box">
                    <div class="flex-full">
                        <div class="platform-feature-image-box">
                            <div><img src="https://cdn.prod.website-files.com/668b3733f80ed0dcd2c46207/668e60b3a41ada3ee79aa960_p-feature-3.png" loading="lazy" alt="Oversee account updates and reports" /></div>
                        </div>
                    </div>
                    <div class="flex-full">
                        <div class="padding-48">
                            <div class="margin-bottom-32">
                                <div class="margin-bottom-8">
                                    <h3>Oversee account updates and reports</h3>
                                </div>
                                <div class="text-color-gray-300">Measure what matters to your team. Read reports on your overall advertising health, status and results. Appeal any restrictions from directly inside the AdsAsia app.</div>
                            </div>
                            <div class="platform-feature-list">
                                <div class="platform-list-item">
                                    <div class="embed w-embed">
                                        <svg width="28" height="29" viewBox="0 0 28 29" fill="none" xmlns="http://www.w3.org/2000/svg">
                                            <g clip-path="url(#clip0_669_8523)">
                                                <path
                                                    fill-rule="evenodd"
                                                    clip-rule="evenodd"
                                                    d="M25.6654 14.6758C25.6654 21.1191 20.442 26.3425 13.9987 26.3425C7.55538 26.3425 2.33203 21.1191 2.33203 14.6758C2.33203 8.2325 7.55538 3.00916 13.9987 3.00916C20.442 3.00916 25.6654 8.2325 25.6654 14.6758ZM20.075 12.0006C20.5306 11.545 20.5306 10.8063 20.075 10.3507C19.6193 9.89509 18.8807 9.89509 18.425 10.3507L12.25 16.5257L9.57496 13.8507C9.11935 13.3951 8.38065 13.3951 7.92504 13.8507C7.46943 14.3063 7.46943 15.045 7.92504 15.5006L11.425 19.0006C11.8807 19.4562 12.6193 19.4562 13.075 19.0006L20.075 12.0006Z"
                                                    fill="white"
                                                />
                                            </g>
                                            <defs>
                                                <clipPath id="clip0_669_8523">
                                                    <rect y="0.675659" width="28" height="28" rx="14" fill="white" />
                                                </clipPath>
                                            </defs>
                                        </svg>
                                    </div>
                                    <div class="text-color-gray-300">Appeal restrictions and share accounts to new businesses</div>
                                </div>
                                <div class="platform-list-item">
                                    <div class="embed w-embed">
                                        <svg width="28" height="29" viewBox="0 0 28 29" fill="none" xmlns="http://www.w3.org/2000/svg">
                                            <g clip-path="url(#clip0_669_8523)">
                                                <path
                                                    fill-rule="evenodd"
                                                    clip-rule="evenodd"
                                                    d="M25.6654 14.6758C25.6654 21.1191 20.442 26.3425 13.9987 26.3425C7.55538 26.3425 2.33203 21.1191 2.33203 14.6758C2.33203 8.2325 7.55538 3.00916 13.9987 3.00916C20.442 3.00916 25.6654 8.2325 25.6654 14.6758ZM20.075 12.0006C20.5306 11.545 20.5306 10.8063 20.075 10.3507C19.6193 9.89509 18.8807 9.89509 18.425 10.3507L12.25 16.5257L9.57496 13.8507C9.11935 13.3951 8.38065 13.3951 7.92504 13.8507C7.46943 14.3063 7.46943 15.045 7.92504 15.5006L11.425 19.0006C11.8807 19.4562 12.6193 19.4562 13.075 19.0006L20.075 12.0006Z"
                                                    fill="white"
                                                />
                                            </g>
                                            <defs>
                                                <clipPath id="clip0_669_8523">
                                                    <rect y="0.675659" width="28" height="28" rx="14" fill="white" />
                                                </clipPath>
                                            </defs>
                                        </svg>
                                    </div>
                                    <div class="text-color-gray-300">Change ad account names</div>
                                </div>
                                <div class="platform-list-item">
                                    <div class="embed w-embed">
                                        <svg width="28" height="29" viewBox="0 0 28 29" fill="none" xmlns="http://www.w3.org/2000/svg">
                                            <g clip-path="url(#clip0_669_8523)">
                                                <path
                                                    fill-rule="evenodd"
                                                    clip-rule="evenodd"
                                                    d="M25.6654 14.6758C25.6654 21.1191 20.442 26.3425 13.9987 26.3425C7.55538 26.3425 2.33203 21.1191 2.33203 14.6758C2.33203 8.2325 7.55538 3.00916 13.9987 3.00916C20.442 3.00916 25.6654 8.2325 25.6654 14.6758ZM20.075 12.0006C20.5306 11.545 20.5306 10.8063 20.075 10.3507C19.6193 9.89509 18.8807 9.89509 18.425 10.3507L12.25 16.5257L9.57496 13.8507C9.11935 13.3951 8.38065 13.3951 7.92504 13.8507C7.46943 14.3063 7.46943 15.045 7.92504 15.5006L11.425 19.0006C11.8807 19.4562 12.6193 19.4562 13.075 19.0006L20.075 12.0006Z"
                                                    fill="white"
                                                />
                                            </g>
                                            <defs>
                                                <clipPath id="clip0_669_8523">
                                                    <rect y="0.675659" width="28" height="28" rx="14" fill="white" />
                                                </clipPath>
                                            </defs>
                                        </svg>
                                    </div>
                                    <div class="text-color-gray-300">Read spending reports and overviews of accounts</div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<div class="section_cta">
    <div class="padding-global">
        <div class="container-1600">
            <div style="text-align: center;" class="">
                <h2 class="heading-36 text-color-gray-100">Ready to start today and boost your ad perfomance?</h2>
            </div>
        </div>
    </div>
</div>
<div class="section_platform-comparison">
    <div class="padding-global">
        <div class="container-1600">
            <div class="margin-bottom-48 set-margin-bottom-24">
                <div class="header-section">
                    <div class="header-tag">
                        <div>Our account difference</div>
                    </div>
                    <h2>How our agency accounts compare</h2>
                    <div class="text-size-20 text-color-gray-300 set-text-size-18">
                        Scale your campaigns effortlessly from day one with whitelisted agency ad accounts from AdsAsia. Enjoy benefits over standard, self-service advertising accounts on <?php echo $platform ?> and skyrocket campaign growth with cheaper results from the highest tier of advertising account.
                    </div>
                </div>
            </div>
            <div class="platform-comparison-component">
                <div class="comparison-row header">
                    <div class="gradient-side"></div>
                    <div id="w-node-a3f67040-0156-9b0a-5e9b-3fa1c9e36827-4e3956e4" class="flex-full">
                        <div class="comparison-header"></div>
                    </div>
                    <div class="flex-full">
                        <div class="comparison-header">
                            <h3 class="set-heading-16">Standard Account</h3>
                        </div>
                    </div>
                    <div class="flex-full">
                        <div class="comparison-header">
                            <h3 class="set-heading-16">Agency AdsAsia Account</h3>
                        </div>
                    </div>
                </div>
                <div class="comparison-row">
                    <div id="w-node-a3f67040-0156-9b0a-5e9b-3fa1c9e36832-4e3956e4" class="flex-full">
                        <div class="padding-side-24">
                            <div class="text-weight-bold">Account credibility</div>
                        </div>
                    </div>
                    <div class="flex-full">
                        <div class="padding-side-24">
                            <div class="text-color-gray-300">Low trust tier, easy to ban</div>
                        </div>
                    </div>
                    <div class="flex-full">
                        <div class="padding-side-24">
                            <div class="platform-list-item">
                                <div class="embed w-embed">
                                    <svg width="29" height="29" viewBox="0 0 29 29" fill="none" xmlns="http://www.w3.org/2000/svg">
                                        <g clip-path="url(#clip0_102_9383)">
                                            <path
                                                fill-rule="evenodd"
                                                clip-rule="evenodd"
                                                d="M26.3321 14.0539C26.3321 20.4972 21.1088 25.7205 14.6654 25.7205C8.22212 25.7205 2.99878 20.4972 2.99878 14.0539C2.99878 7.61055 8.22212 2.38721 14.6654 2.38721C21.1088 2.38721 26.3321 7.61055 26.3321 14.0539ZM20.7417 11.3787C21.1973 10.9231 21.1973 10.1844 20.7417 9.72875C20.2861 9.27314 19.5474 9.27314 19.0918 9.72875L12.9167 15.9038L10.2417 13.2288C9.78609 12.7731 9.0474 12.7731 8.59179 13.2288C8.13618 13.6844 8.13618 14.4231 8.59179 14.8787L12.0918 18.3787C12.5474 18.8343 13.2861 18.8343 13.7417 18.3787L20.7417 11.3787Z"
                                                fill="#17B26A"
                                            />
                                        </g>
                                        <defs>
                                            <clipPath id="clip0_102_9383">
                                                <rect x="0.666748" y="0.0537109" width="28" height="28" rx="14" fill="white" />
                                            </clipPath>
                                        </defs>
                                    </svg>
                                </div>
                                <div class="text-color-gray-300">Highest trust tier, stable accounts</div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="comparison-row shade">
                    <div id="w-node-a3f67040-0156-9b0a-5e9b-3fa1c9e36841-4e3956e4" class="flex-full">
                        <div class="padding-side-24">
                            <div class="text-weight-bold">Cashback on spending</div>
                        </div>
                    </div>
                    <div class="flex-full">
                        <div class="padding-side-24">
                            <div class="embed right w-embed">
                                <svg width="21" height="21" viewBox="0 0 21 21" fill="none" xmlns="http://www.w3.org/2000/svg">
                                    <path d="M4.5 10.0537H16.1667" stroke="#D0D5DD" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" />
                                </svg>
                            </div>
                        </div>
                    </div>
                    <div class="flex-full">
                        <div class="padding-side-24">
                            <div class="platform-list-item">
                                <div class="embed w-embed">
                                    <svg width="29" height="29" viewBox="0 0 29 29" fill="none" xmlns="http://www.w3.org/2000/svg">
                                        <g clip-path="url(#clip0_102_9383)">
                                            <path
                                                fill-rule="evenodd"
                                                clip-rule="evenodd"
                                                d="M26.3321 14.0539C26.3321 20.4972 21.1088 25.7205 14.6654 25.7205C8.22212 25.7205 2.99878 20.4972 2.99878 14.0539C2.99878 7.61055 8.22212 2.38721 14.6654 2.38721C21.1088 2.38721 26.3321 7.61055 26.3321 14.0539ZM20.7417 11.3787C21.1973 10.9231 21.1973 10.1844 20.7417 9.72875C20.2861 9.27314 19.5474 9.27314 19.0918 9.72875L12.9167 15.9038L10.2417 13.2288C9.78609 12.7731 9.0474 12.7731 8.59179 13.2288C8.13618 13.6844 8.13618 14.4231 8.59179 14.8787L12.0918 18.3787C12.5474 18.8343 13.2861 18.8343 13.7417 18.3787L20.7417 11.3787Z"
                                                fill="#17B26A"
                                            />
                                        </g>
                                        <defs>
                                            <clipPath id="clip0_102_9383">
                                                <rect x="0.666748" y="0.0537109" width="28" height="28" rx="14" fill="white" />
                                            </clipPath>
                                        </defs>
                                    </svg>
                                </div>
                                <div class="text-color-gray-300">Cashback available to all clients</div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="comparison-row">
                    <div id="w-node-a3f67040-0156-9b0a-5e9b-3fa1c9e3684f-4e3956e4" class="flex-full">
                        <div class="padding-side-24">
                            <div class="text-weight-bold">No spending limits</div>
                        </div>
                    </div>
                    <div class="flex-full">
                        <div class="padding-side-24">
                            <div class="text-color-gray-300">Daily limit lasting for weeks</div>
                        </div>
                    </div>
                    <div class="flex-full">
                        <div class="padding-side-24">
                            <div class="platform-list-item">
                                <div class="embed w-embed">
                                    <svg width="29" height="29" viewBox="0 0 29 29" fill="none" xmlns="http://www.w3.org/2000/svg">
                                        <g clip-path="url(#clip0_102_9383)">
                                            <path
                                                fill-rule="evenodd"
                                                clip-rule="evenodd"
                                                d="M26.3321 14.0539C26.3321 20.4972 21.1088 25.7205 14.6654 25.7205C8.22212 25.7205 2.99878 20.4972 2.99878 14.0539C2.99878 7.61055 8.22212 2.38721 14.6654 2.38721C21.1088 2.38721 26.3321 7.61055 26.3321 14.0539ZM20.7417 11.3787C21.1973 10.9231 21.1973 10.1844 20.7417 9.72875C20.2861 9.27314 19.5474 9.27314 19.0918 9.72875L12.9167 15.9038L10.2417 13.2288C9.78609 12.7731 9.0474 12.7731 8.59179 13.2288C8.13618 13.6844 8.13618 14.4231 8.59179 14.8787L12.0918 18.3787C12.5474 18.8343 13.2861 18.8343 13.7417 18.3787L20.7417 11.3787Z"
                                                fill="#17B26A"
                                            />
                                        </g>
                                        <defs>
                                            <clipPath id="clip0_102_9383">
                                                <rect x="0.666748" y="0.0537109" width="28" height="28" rx="14" fill="white" />
                                            </clipPath>
                                        </defs>
                                    </svg>
                                </div>
                                <div class="text-color-gray-300">No spending limit</div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="comparison-row shade">
                    <div id="w-node-a3f67040-0156-9b0a-5e9b-3fa1c9e3685e-4e3956e4" class="flex-full">
                        <div class="padding-side-24">
                            <div class="text-weight-bold">Dedicated support</div>
                        </div>
                    </div>
                    <div class="flex-full">
                        <div class="padding-side-24">
                            <div class="embed right w-embed">
                                <svg width="21" height="21" viewBox="0 0 21 21" fill="none" xmlns="http://www.w3.org/2000/svg">
                                    <path d="M4.5 10.0537H16.1667" stroke="#D0D5DD" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" />
                                </svg>
                            </div>
                        </div>
                    </div>
                    <div class="flex-full">
                        <div class="padding-side-24">
                            <div class="platform-list-item">
                                <div class="embed w-embed">
                                    <svg width="29" height="29" viewBox="0 0 29 29" fill="none" xmlns="http://www.w3.org/2000/svg">
                                        <g clip-path="url(#clip0_102_9383)">
                                            <path
                                                fill-rule="evenodd"
                                                clip-rule="evenodd"
                                                d="M26.3321 14.0539C26.3321 20.4972 21.1088 25.7205 14.6654 25.7205C8.22212 25.7205 2.99878 20.4972 2.99878 14.0539C2.99878 7.61055 8.22212 2.38721 14.6654 2.38721C21.1088 2.38721 26.3321 7.61055 26.3321 14.0539ZM20.7417 11.3787C21.1973 10.9231 21.1973 10.1844 20.7417 9.72875C20.2861 9.27314 19.5474 9.27314 19.0918 9.72875L12.9167 15.9038L10.2417 13.2288C9.78609 12.7731 9.0474 12.7731 8.59179 13.2288C8.13618 13.6844 8.13618 14.4231 8.59179 14.8787L12.0918 18.3787C12.5474 18.8343 13.2861 18.8343 13.7417 18.3787L20.7417 11.3787Z"
                                                fill="#17B26A"
                                            />
                                        </g>
                                        <defs>
                                            <clipPath id="clip0_102_9383">
                                                <rect x="0.666748" y="0.0537109" width="28" height="28" rx="14" fill="white" />
                                            </clipPath>
                                        </defs>
                                    </svg>
                                </div>
                                <div class="text-color-gray-300">Dedicated account manager</div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="comparison-row">
                    <div id="w-node-a3f67040-0156-9b0a-5e9b-3fa1c9e3686c-4e3956e4" class="flex-full">
                        <div class="padding-side-24">
                            <div class="text-weight-bold">Payment methods</div>
                        </div>
                    </div>
                    <div class="flex-full">
                        <div class="padding-side-24">
                            <div class="text-color-gray-300">Card payment only</div>
                        </div>
                    </div>
                    <div class="flex-full">
                        <div class="padding-side-24">
                            <div class="platform-list-item">
                                <div class="embed w-embed">
                                    <svg width="29" height="29" viewBox="0 0 29 29" fill="none" xmlns="http://www.w3.org/2000/svg">
                                        <g clip-path="url(#clip0_102_9383)">
                                            <path
                                                fill-rule="evenodd"
                                                clip-rule="evenodd"
                                                d="M26.3321 14.0539C26.3321 20.4972 21.1088 25.7205 14.6654 25.7205C8.22212 25.7205 2.99878 20.4972 2.99878 14.0539C2.99878 7.61055 8.22212 2.38721 14.6654 2.38721C21.1088 2.38721 26.3321 7.61055 26.3321 14.0539ZM20.7417 11.3787C21.1973 10.9231 21.1973 10.1844 20.7417 9.72875C20.2861 9.27314 19.5474 9.27314 19.0918 9.72875L12.9167 15.9038L10.2417 13.2288C9.78609 12.7731 9.0474 12.7731 8.59179 13.2288C8.13618 13.6844 8.13618 14.4231 8.59179 14.8787L12.0918 18.3787C12.5474 18.8343 13.2861 18.8343 13.7417 18.3787L20.7417 11.3787Z"
                                                fill="#17B26A"
                                            />
                                        </g>
                                        <defs>
                                            <clipPath id="clip0_102_9383">
                                                <rect x="0.666748" y="0.0537109" width="28" height="28" rx="14" fill="white" />
                                            </clipPath>
                                        </defs>
                                    </svg>
                                </div>
                                <div class="text-color-gray-300">Card, transfer, crypto & 10 more</div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="comparison-row shade">
                    <div id="w-node-a3f67040-0156-9b0a-5e9b-3fa1c9e3687b-4e3956e4" class="flex-full">
                        <div class="padding-side-24">
                            <div class="text-weight-bold">Scale on first day</div>
                        </div>
                    </div>
                    <div class="flex-full">
                        <div class="padding-side-24">
                            <div class="embed right w-embed">
                                <svg width="21" height="21" viewBox="0 0 21 21" fill="none" xmlns="http://www.w3.org/2000/svg">
                                    <path d="M4.5 10.0537H16.1667" stroke="#D0D5DD" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" />
                                </svg>
                            </div>
                        </div>
                    </div>
                    <div class="flex-full">
                        <div class="padding-side-24">
                            <div class="platform-list-item">
                                <div class="embed w-embed">
                                    <svg width="29" height="29" viewBox="0 0 29 29" fill="none" xmlns="http://www.w3.org/2000/svg">
                                        <g clip-path="url(#clip0_102_9383)">
                                            <path
                                                fill-rule="evenodd"
                                                clip-rule="evenodd"
                                                d="M26.3321 14.0539C26.3321 20.4972 21.1088 25.7205 14.6654 25.7205C8.22212 25.7205 2.99878 20.4972 2.99878 14.0539C2.99878 7.61055 8.22212 2.38721 14.6654 2.38721C21.1088 2.38721 26.3321 7.61055 26.3321 14.0539ZM20.7417 11.3787C21.1973 10.9231 21.1973 10.1844 20.7417 9.72875C20.2861 9.27314 19.5474 9.27314 19.0918 9.72875L12.9167 15.9038L10.2417 13.2288C9.78609 12.7731 9.0474 12.7731 8.59179 13.2288C8.13618 13.6844 8.13618 14.4231 8.59179 14.8787L12.0918 18.3787C12.5474 18.8343 13.2861 18.8343 13.7417 18.3787L20.7417 11.3787Z"
                                                fill="#17B26A"
                                            />
                                        </g>
                                        <defs>
                                            <clipPath id="clip0_102_9383">
                                                <rect x="0.666748" y="0.0537109" width="28" height="28" rx="14" fill="white" />
                                            </clipPath>
                                        </defs>
                                    </svg>
                                </div>
                                <div class="text-color-gray-300">No warmup required, scale quickly</div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="comparison-row">
                    <div id="w-node-a3f67040-0156-9b0a-5e9b-3fa1c9e36889-4e3956e4" class="flex-full">
                        <div class="padding-side-24">
                            <div class="text-weight-bold">Unlimited ad accounts</div>
                        </div>
                    </div>
                    <div class="flex-full">
                        <div class="padding-side-24">
                            <div class="embed right w-embed">
                                <svg width="21" height="21" viewBox="0 0 21 21" fill="none" xmlns="http://www.w3.org/2000/svg">
                                    <path d="M4.5 10.0537H16.1667" stroke="#D0D5DD" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" />
                                </svg>
                            </div>
                        </div>
                    </div>
                    <div class="flex-full">
                        <div class="padding-side-24">
                            <div class="platform-list-item">
                                <div class="embed w-embed">
                                    <svg width="29" height="29" viewBox="0 0 29 29" fill="none" xmlns="http://www.w3.org/2000/svg">
                                        <g clip-path="url(#clip0_102_9383)">
                                            <path
                                                fill-rule="evenodd"
                                                clip-rule="evenodd"
                                                d="M26.3321 14.0539C26.3321 20.4972 21.1088 25.7205 14.6654 25.7205C8.22212 25.7205 2.99878 20.4972 2.99878 14.0539C2.99878 7.61055 8.22212 2.38721 14.6654 2.38721C21.1088 2.38721 26.3321 7.61055 26.3321 14.0539ZM20.7417 11.3787C21.1973 10.9231 21.1973 10.1844 20.7417 9.72875C20.2861 9.27314 19.5474 9.27314 19.0918 9.72875L12.9167 15.9038L10.2417 13.2288C9.78609 12.7731 9.0474 12.7731 8.59179 13.2288C8.13618 13.6844 8.13618 14.4231 8.59179 14.8787L12.0918 18.3787C12.5474 18.8343 13.2861 18.8343 13.7417 18.3787L20.7417 11.3787Z"
                                                fill="#17B26A"
                                            />
                                        </g>
                                        <defs>
                                            <clipPath id="clip0_102_9383">
                                                <rect x="0.666748" y="0.0537109" width="28" height="28" rx="14" fill="white" />
                                            </clipPath>
                                        </defs>
                                    </svg>
                                </div>
                                <div class="text-color-gray-300">Generate new accounts anytime</div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="comparison-row shade">
                    <div id="w-node-a3f67040-0156-9b0a-5e9b-3fa1c9e36897-4e3956e4" class="flex-full">
                        <div class="padding-side-24">
                            <div class="text-weight-bold">Replacement assets</div>
                        </div>
                    </div>
                    <div class="flex-full">
                        <div class="padding-side-24">
                            <div class="embed right w-embed">
                                <svg width="21" height="21" viewBox="0 0 21 21" fill="none" xmlns="http://www.w3.org/2000/svg">
                                    <path d="M4.5 10.0537H16.1667" stroke="#D0D5DD" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" />
                                </svg>
                            </div>
                        </div>
                    </div>
                    <div class="flex-full">
                        <div class="padding-side-24">
                            <div class="platform-list-item">
                                <div class="embed w-embed">
                                    <svg width="29" height="29" viewBox="0 0 29 29" fill="none" xmlns="http://www.w3.org/2000/svg">
                                        <g clip-path="url(#clip0_102_9383)">
                                            <path
                                                fill-rule="evenodd"
                                                clip-rule="evenodd"
                                                d="M26.3321 14.0539C26.3321 20.4972 21.1088 25.7205 14.6654 25.7205C8.22212 25.7205 2.99878 20.4972 2.99878 14.0539C2.99878 7.61055 8.22212 2.38721 14.6654 2.38721C21.1088 2.38721 26.3321 7.61055 26.3321 14.0539ZM20.7417 11.3787C21.1973 10.9231 21.1973 10.1844 20.7417 9.72875C20.2861 9.27314 19.5474 9.27314 19.0918 9.72875L12.9167 15.9038L10.2417 13.2288C9.78609 12.7731 9.0474 12.7731 8.59179 13.2288C8.13618 13.6844 8.13618 14.4231 8.59179 14.8787L12.0918 18.3787C12.5474 18.8343 13.2861 18.8343 13.7417 18.3787L20.7417 11.3787Z"
                                                fill="#17B26A"
                                            />
                                        </g>
                                        <defs>
                                            <clipPath id="clip0_102_9383">
                                                <rect x="0.666748" y="0.0537109" width="28" height="28" rx="14" fill="white" />
                                            </clipPath>
                                        </defs>
                                    </svg>
                                </div>
                                <div class="text-color-gray-300">Pages, profiles, BMs available</div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="comparison-row">
                    <div id="w-node-a3f67040-0156-9b0a-5e9b-3fa1c9e368a5-4e3956e4" class="flex-full">
                        <div class="padding-side-24">
                            <div class="text-weight-bold">Quick ad approvals</div>
                        </div>
                    </div>
                    <div class="flex-full">
                        <div class="padding-side-24">
                            <div class="embed right w-embed">
                                <svg width="21" height="21" viewBox="0 0 21 21" fill="none" xmlns="http://www.w3.org/2000/svg">
                                    <path d="M4.5 10.0537H16.1667" stroke="#D0D5DD" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" />
                                </svg>
                            </div>
                        </div>
                    </div>
                    <div class="flex-full">
                        <div class="padding-side-24">
                            <div class="platform-list-item">
                                <div class="embed w-embed">
                                    <svg width="29" height="29" viewBox="0 0 29 29" fill="none" xmlns="http://www.w3.org/2000/svg">
                                        <g clip-path="url(#clip0_102_9383)">
                                            <path
                                                fill-rule="evenodd"
                                                clip-rule="evenodd"
                                                d="M26.3321 14.0539C26.3321 20.4972 21.1088 25.7205 14.6654 25.7205C8.22212 25.7205 2.99878 20.4972 2.99878 14.0539C2.99878 7.61055 8.22212 2.38721 14.6654 2.38721C21.1088 2.38721 26.3321 7.61055 26.3321 14.0539ZM20.7417 11.3787C21.1973 10.9231 21.1973 10.1844 20.7417 9.72875C20.2861 9.27314 19.5474 9.27314 19.0918 9.72875L12.9167 15.9038L10.2417 13.2288C9.78609 12.7731 9.0474 12.7731 8.59179 13.2288C8.13618 13.6844 8.13618 14.4231 8.59179 14.8787L12.0918 18.3787C12.5474 18.8343 13.2861 18.8343 13.7417 18.3787L20.7417 11.3787Z"
                                                fill="#17B26A"
                                            />
                                        </g>
                                        <defs>
                                            <clipPath id="clip0_102_9383">
                                                <rect x="0.666748" y="0.0537109" width="28" height="28" rx="14" fill="white" />
                                            </clipPath>
                                        </defs>
                                    </svg>
                                </div>
                                <div class="text-color-gray-300">Quicker approval process</div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="comparison-row shade">
                    <div id="w-node-a3f67040-0156-9b0a-5e9b-3fa1c9e368b3-4e3956e4" class="flex-full">
                        <div class="padding-side-24">
                            <div class="text-weight-bold">Cheaper results advantage</div>
                        </div>
                    </div>
                    <div class="flex-full">
                        <div class="padding-side-24">
                            <div class="embed right w-embed">
                                <svg width="21" height="21" viewBox="0 0 21 21" fill="none" xmlns="http://www.w3.org/2000/svg">
                                    <path d="M4.5 10.0537H16.1667" stroke="#D0D5DD" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" />
                                </svg>
                            </div>
                        </div>
                    </div>
                    <div class="flex-full">
                        <div class="padding-side-24">
                            <div class="platform-list-item">
                                <div class="embed w-embed">
                                    <svg width="29" height="29" viewBox="0 0 29 29" fill="none" xmlns="http://www.w3.org/2000/svg">
                                        <g clip-path="url(#clip0_102_9383)">
                                            <path
                                                fill-rule="evenodd"
                                                clip-rule="evenodd"
                                                d="M26.3321 14.0539C26.3321 20.4972 21.1088 25.7205 14.6654 25.7205C8.22212 25.7205 2.99878 20.4972 2.99878 14.0539C2.99878 7.61055 8.22212 2.38721 14.6654 2.38721C21.1088 2.38721 26.3321 7.61055 26.3321 14.0539ZM20.7417 11.3787C21.1973 10.9231 21.1973 10.1844 20.7417 9.72875C20.2861 9.27314 19.5474 9.27314 19.0918 9.72875L12.9167 15.9038L10.2417 13.2288C9.78609 12.7731 9.0474 12.7731 8.59179 13.2288C8.13618 13.6844 8.13618 14.4231 8.59179 14.8787L12.0918 18.3787C12.5474 18.8343 13.2861 18.8343 13.7417 18.3787L20.7417 11.3787Z"
                                                fill="#17B26A"
                                            />
                                        </g>
                                        <defs>
                                            <clipPath id="clip0_102_9383">
                                                <rect x="0.666748" y="0.0537109" width="28" height="28" rx="14" fill="white" />
                                            </clipPath>
                                        </defs>
                                    </svg>
                                </div>
                                <div class="text-color-gray-300">Auction advantage, cheaper results</div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="comparison-row">
                    <div id="w-node-a3f67040-0156-9b0a-5e9b-3fa1c9e368c1-4e3956e4" class="flex-full">
                        <div class="padding-side-24">
                            <div class="text-weight-bold">Advertise if previously banned</div>
                        </div>
                    </div>
                    <div class="flex-full">
                        <div class="padding-side-24">
                            <div class="embed right w-embed">
                                <svg width="21" height="21" viewBox="0 0 21 21" fill="none" xmlns="http://www.w3.org/2000/svg">
                                    <path d="M4.5 10.0537H16.1667" stroke="#D0D5DD" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" />
                                </svg>
                            </div>
                        </div>
                    </div>
                    <div class="flex-full">
                        <div class="padding-side-24">
                            <div class="platform-list-item">
                                <div class="embed w-embed">
                                    <svg width="29" height="29" viewBox="0 0 29 29" fill="none" xmlns="http://www.w3.org/2000/svg">
                                        <g clip-path="url(#clip0_102_9383)">
                                            <path
                                                fill-rule="evenodd"
                                                clip-rule="evenodd"
                                                d="M26.3321 14.0539C26.3321 20.4972 21.1088 25.7205 14.6654 25.7205C8.22212 25.7205 2.99878 20.4972 2.99878 14.0539C2.99878 7.61055 8.22212 2.38721 14.6654 2.38721C21.1088 2.38721 26.3321 7.61055 26.3321 14.0539ZM20.7417 11.3787C21.1973 10.9231 21.1973 10.1844 20.7417 9.72875C20.2861 9.27314 19.5474 9.27314 19.0918 9.72875L12.9167 15.9038L10.2417 13.2288C9.78609 12.7731 9.0474 12.7731 8.59179 13.2288C8.13618 13.6844 8.13618 14.4231 8.59179 14.8787L12.0918 18.3787C12.5474 18.8343 13.2861 18.8343 13.7417 18.3787L20.7417 11.3787Z"
                                                fill="#17B26A"
                                            />
                                        </g>
                                        <defs>
                                            <clipPath id="clip0_102_9383">
                                                <rect x="0.666748" y="0.0537109" width="28" height="28" rx="14" fill="white" />
                                            </clipPath>
                                        </defs>
                                    </svg>
                                </div>
                                <div class="text-color-gray-300">Advertise again without restrictions</div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="gradient-side"></div>
            </div>
        </div>
    </div>
</div>

<div class="section_platform-partnership">
    <div class="padding-global">
        <div class="container-1600">
            <div class="platform-partnership-component">
                <div class="flex-full">
                    <div class="margin-bottom-48">
                        <div class="header-section">
                            <div class="header-tag">
                                <div><?php echo $platform ?> partnership</div>
                            </div>
                            <h2><strong><?php echo $platform ?> official reselling partner</strong></h2>
                            <div class="text-color-gray-300">
                                As a leading reselling partner of <?php echo $platform ?>, AdsAsia's global presence attracts international advertisers to scale their advertising campaigns in one unified platform. AdsAsia also assists businesses in entering new markets with advertising account openings and by working with localized support teams.
                            </div>
                        </div>
                    </div>
                    <div class="margin-bottom-56">
                        <div class="platform-feature-list">
                            <div class="platform-list-item">
                                <div class="embed w-embed">
                                    <svg width="28" height="29" viewBox="0 0 28 29" fill="none" xmlns="http://www.w3.org/2000/svg">
                                        <g clip-path="url(#clip0_669_8523)">
                                            <path
                                                fill-rule="evenodd"
                                                clip-rule="evenodd"
                                                d="M25.6654 14.6758C25.6654 21.1191 20.442 26.3425 13.9987 26.3425C7.55538 26.3425 2.33203 21.1191 2.33203 14.6758C2.33203 8.2325 7.55538 3.00916 13.9987 3.00916C20.442 3.00916 25.6654 8.2325 25.6654 14.6758ZM20.075 12.0006C20.5306 11.545 20.5306 10.8063 20.075 10.3507C19.6193 9.89509 18.8807 9.89509 18.425 10.3507L12.25 16.5257L9.57496 13.8507C9.11935 13.3951 8.38065 13.3951 7.92504 13.8507C7.46943 14.3063 7.46943 15.045 7.92504 15.5006L11.425 19.0006C11.8807 19.4562 12.6193 19.4562 13.075 19.0006L20.075 12.0006Z"
                                                fill="white"
                                            />
                                        </g>
                                        <defs>
                                            <clipPath id="clip0_669_8523">
                                                <rect y="0.675659" width="28" height="28" rx="14" fill="white" />
                                            </clipPath>
                                        </defs>
                                    </svg>
                                </div>
                                <div class="text-color-gray-300">Work with direct <?php echo $platform ?> partners and agents on one platform</div>
                            </div>
                            <div class="platform-list-item">
                                <div class="embed w-embed">
                                    <svg width="28" height="29" viewBox="0 0 28 29" fill="none" xmlns="http://www.w3.org/2000/svg">
                                        <g clip-path="url(#clip0_669_8523)">
                                            <path
                                                fill-rule="evenodd"
                                                clip-rule="evenodd"
                                                d="M25.6654 14.6758C25.6654 21.1191 20.442 26.3425 13.9987 26.3425C7.55538 26.3425 2.33203 21.1191 2.33203 14.6758C2.33203 8.2325 7.55538 3.00916 13.9987 3.00916C20.442 3.00916 25.6654 8.2325 25.6654 14.6758ZM20.075 12.0006C20.5306 11.545 20.5306 10.8063 20.075 10.3507C19.6193 9.89509 18.8807 9.89509 18.425 10.3507L12.25 16.5257L9.57496 13.8507C9.11935 13.3951 8.38065 13.3951 7.92504 13.8507C7.46943 14.3063 7.46943 15.045 7.92504 15.5006L11.425 19.0006C11.8807 19.4562 12.6193 19.4562 13.075 19.0006L20.075 12.0006Z"
                                                fill="white"
                                            />
                                        </g>
                                        <defs>
                                            <clipPath id="clip0_669_8523">
                                                <rect y="0.675659" width="28" height="28" rx="14" fill="white" />
                                            </clipPath>
                                        </defs>
                                    </svg>
                                </div>
                                <div class="text-color-gray-300">Create unlimited, highest-tier agency ad accounts</div>
                            </div>
                            <div class="platform-list-item">
                                <div class="embed w-embed">
                                    <svg width="28" height="29" viewBox="0 0 28 29" fill="none" xmlns="http://www.w3.org/2000/svg">
                                        <g clip-path="url(#clip0_669_8523)">
                                            <path
                                                fill-rule="evenodd"
                                                clip-rule="evenodd"
                                                d="M25.6654 14.6758C25.6654 21.1191 20.442 26.3425 13.9987 26.3425C7.55538 26.3425 2.33203 21.1191 2.33203 14.6758C2.33203 8.2325 7.55538 3.00916 13.9987 3.00916C20.442 3.00916 25.6654 8.2325 25.6654 14.6758ZM20.075 12.0006C20.5306 11.545 20.5306 10.8063 20.075 10.3507C19.6193 9.89509 18.8807 9.89509 18.425 10.3507L12.25 16.5257L9.57496 13.8507C9.11935 13.3951 8.38065 13.3951 7.92504 13.8507C7.46943 14.3063 7.46943 15.045 7.92504 15.5006L11.425 19.0006C11.8807 19.4562 12.6193 19.4562 13.075 19.0006L20.075 12.0006Z"
                                                fill="white"
                                            />
                                        </g>
                                        <defs>
                                            <clipPath id="clip0_669_8523">
                                                <rect y="0.675659" width="28" height="28" rx="14" fill="white" />
                                            </clipPath>
                                        </defs>
                                    </svg>
                                </div>
                                <div class="text-color-gray-300">Access to <?php echo $platform ?> representatives for direct support</div>
                            </div>
                            <div class="platform-list-item">
                                <div class="embed w-embed">
                                    <svg width="28" height="29" viewBox="0 0 28 29" fill="none" xmlns="http://www.w3.org/2000/svg">
                                        <g clip-path="url(#clip0_669_8523)">
                                            <path
                                                fill-rule="evenodd"
                                                clip-rule="evenodd"
                                                d="M25.6654 14.6758C25.6654 21.1191 20.442 26.3425 13.9987 26.3425C7.55538 26.3425 2.33203 21.1191 2.33203 14.6758C2.33203 8.2325 7.55538 3.00916 13.9987 3.00916C20.442 3.00916 25.6654 8.2325 25.6654 14.6758ZM20.075 12.0006C20.5306 11.545 20.5306 10.8063 20.075 10.3507C19.6193 9.89509 18.8807 9.89509 18.425 10.3507L12.25 16.5257L9.57496 13.8507C9.11935 13.3951 8.38065 13.3951 7.92504 13.8507C7.46943 14.3063 7.46943 15.045 7.92504 15.5006L11.425 19.0006C11.8807 19.4562 12.6193 19.4562 13.075 19.0006L20.075 12.0006Z"
                                                fill="white"
                                            />
                                        </g>
                                        <defs>
                                            <clipPath id="clip0_669_8523">
                                                <rect y="0.675659" width="28" height="28" rx="14" fill="white" />
                                            </clipPath>
                                        </defs>
                                    </svg>
                                </div>
                                <div class="text-color-gray-300">Receive priority platform news and updates</div>
                            </div>
                            <div class="platform-list-item">
                                <div class="embed w-embed">
                                    <svg width="28" height="29" viewBox="0 0 28 29" fill="none" xmlns="http://www.w3.org/2000/svg">
                                        <g clip-path="url(#clip0_669_8523)">
                                            <path
                                                fill-rule="evenodd"
                                                clip-rule="evenodd"
                                                d="M25.6654 14.6758C25.6654 21.1191 20.442 26.3425 13.9987 26.3425C7.55538 26.3425 2.33203 21.1191 2.33203 14.6758C2.33203 8.2325 7.55538 3.00916 13.9987 3.00916C20.442 3.00916 25.6654 8.2325 25.6654 14.6758ZM20.075 12.0006C20.5306 11.545 20.5306 10.8063 20.075 10.3507C19.6193 9.89509 18.8807 9.89509 18.425 10.3507L12.25 16.5257L9.57496 13.8507C9.11935 13.3951 8.38065 13.3951 7.92504 13.8507C7.46943 14.3063 7.46943 15.045 7.92504 15.5006L11.425 19.0006C11.8807 19.4562 12.6193 19.4562 13.075 19.0006L20.075 12.0006Z"
                                                fill="white"
                                            />
                                        </g>
                                        <defs>
                                            <clipPath id="clip0_669_8523">
                                                <rect y="0.675659" width="28" height="28" rx="14" fill="white" />
                                            </clipPath>
                                        </defs>
                                    </svg>
                                </div>
                                <div class="text-color-gray-300">Qualify for exclusive platform cashback</div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="flex-full">
                    <div class="position-relative">
                        <div class="image-box hide-mobile-landscape">
                            <div class="gradient-background opacity-60"></div>
                            <div data-w-id="bff04f8c-a050-eeee-8f68-71cb450120ad" class="no-overflow">
                                <img
                                    src="<?php echo $image2 ?>"
                                    loading="lazy"
                                    sizes="(max-width: 817px) 100vw, 817px"
                                    srcset="<?php echo $image2 ?> 500w, <?php echo $image2 ?> 800w, <?php echo $image2 ?> 817w"
                                    alt="AdsAsia as a <?php echo $platform ?> Official Partner"
                                    class="position-relative"
                                />
                            </div>
                            <div class="gradient-side-position none hide-this"></div>
                        </div>
                        <div class="show-mobile-landscape">
                            <img src="https://cdn.prod.website-files.com/668b3733f80ed0dcd2c46207/66cc492486164d9b7c3f3c15_meta-float.png" loading="lazy" alt="AdsAsia as a <?php echo $platform ?> Official Partner" class="hide-this" />
                            <div class="position-relative">
                                <div class="gradient-background"></div>
                                <div class="gradient-side-position none hide-this"></div>
                                <img
                                    src="https://cdn.prod.website-files.com/668b3733f80ed0dcd2c46207/6785eab829bd93a00ad7ad47_meta-box-2.png"
                                    loading="lazy"
                                    sizes="(max-width: 771px) 100vw, 771px"
                                    srcset="
                                        https://cdn.prod.website-files.com/668b3733f80ed0dcd2c46207/6785eab829bd93a00ad7ad47_meta-box-2-p-500.png 500w,
                                        https://cdn.prod.website-files.com/668b3733f80ed0dcd2c46207/6785eab829bd93a00ad7ad47_meta-box-2.png       771w
                                    "
                                    alt="AdsAsia as a <?php echo $platform ?> Official Partner"
                                    class="position-relative"
                                />
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<div class="section_platform-testimonials">
    <div class="padding-global">
        <div class="container-1600">
            <div class="margin-bottom-48">
                <div class="header-section">
                    <div class="header-tag">
                        <div>Testimonials</div>
                    </div>
                    <h2 class="text-color-gray-200">What our clients say</h2>
                    <div class="text-size-20 text-color-gray-300 set-text-size-18">Read real reviews and success stories from our satisfied clients.</div>
                </div>
            </div>
            <div
                data-delay="3000"
                data-animation="slide"
                class="testimonial-slider w-slider"
                data-autoplay="true"
                data-easing="ease"
                data-hide-arrows="false"
                data-disable-swipe="false"
                data-autoplay-limit="0"
                data-nav-spacing="3"
                data-duration="500"
                data-infinite="true"
            >
                <div class="w-slider-mask">
                    <div class="w-slide">
                        <div class="platform-testimonial-slide hide-this">
                            <div class="max-width-312">
                                <div class="testimonial-client-score">
                                    <div>
                                        <div class="margin-bottom-8">
                                            <div class="heading-64 text-weight-bold line-height-1">5</div>
                                        </div>
                                        <div class="margin-bottom-16">
                                            <div class="text-size-14">Client’s score</div>
                                        </div>
                                        <div class="testimonial-rating-box">
                                            <div class="embed w-embed">
                                                <svg width="25" height="25" viewBox="0 0 25 25" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                    <rect width="24.1379" height="24.1379" transform="translate(0 0.484863)" fill="#219653" />
                                                    <path
                                                        d="M12.0689 16.9904L15.7399 16.0074L17.2736 21.002L12.0689 16.9904ZM20.5172 10.5347H14.0552L12.0689 4.10547L10.0825 10.5347H3.62061L8.85049 14.5197L6.86414 20.9489L12.094 16.9638L15.3124 14.5197L20.5172 10.5347Z"
                                                        fill="white"
                                                    />
                                                </svg>
                                            </div>
                                            <div class="embed w-embed">
                                                <svg width="25" height="25" viewBox="0 0 25 25" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                    <rect width="24.1379" height="24.1379" transform="translate(0 0.484863)" fill="#219653" />
                                                    <path
                                                        d="M12.0689 16.9904L15.7399 16.0074L17.2736 21.002L12.0689 16.9904ZM20.5172 10.5347H14.0552L12.0689 4.10547L10.0825 10.5347H3.62061L8.85049 14.5197L6.86414 20.9489L12.094 16.9638L15.3124 14.5197L20.5172 10.5347Z"
                                                        fill="white"
                                                    />
                                                </svg>
                                            </div>
                                            <div class="embed w-embed">
                                                <svg width="25" height="25" viewBox="0 0 25 25" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                    <rect width="24.1379" height="24.1379" transform="translate(0 0.484863)" fill="#219653" />
                                                    <path
                                                        d="M12.0689 16.9904L15.7399 16.0074L17.2736 21.002L12.0689 16.9904ZM20.5172 10.5347H14.0552L12.0689 4.10547L10.0825 10.5347H3.62061L8.85049 14.5197L6.86414 20.9489L12.094 16.9638L15.3124 14.5197L20.5172 10.5347Z"
                                                        fill="white"
                                                    />
                                                </svg>
                                            </div>
                                            <div class="embed w-embed">
                                                <svg width="25" height="25" viewBox="0 0 25 25" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                    <rect width="24.1379" height="24.1379" transform="translate(0 0.484863)" fill="#219653" />
                                                    <path
                                                        d="M12.0689 16.9904L15.7399 16.0074L17.2736 21.002L12.0689 16.9904ZM20.5172 10.5347H14.0552L12.0689 4.10547L10.0825 10.5347H3.62061L8.85049 14.5197L6.86414 20.9489L12.094 16.9638L15.3124 14.5197L20.5172 10.5347Z"
                                                        fill="white"
                                                    />
                                                </svg>
                                            </div>
                                            <div class="embed w-embed">
                                                <svg width="25" height="25" viewBox="0 0 25 25" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                    <rect width="24.1379" height="24.1379" transform="translate(0 0.484863)" fill="#219653" />
                                                    <path
                                                        d="M12.0689 16.9904L15.7399 16.0074L17.2736 21.002L12.0689 16.9904ZM20.5172 10.5347H14.0552L12.0689 4.10547L10.0825 10.5347H3.62061L8.85049 14.5197L6.86414 20.9489L12.094 16.9638L15.3124 14.5197L20.5172 10.5347Z"
                                                        fill="white"
                                                    />
                                                </svg>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="testimonial-logo-bottom">
                                        <div><img loading="lazy" src="https://cdn.prod.website-files.com/668b3733f80ed0dcd2c46207/668f55e450eeb735f8c47eb3_Trustpilot%20logo.png" alt="" /></div>
                                    </div>
                                </div>
                            </div>
                            <div class="inner-line width"></div>
                            <div class="platform-testimonial-content">
                                <div class="embed w-embed">
                                    <svg width="48" height="49" viewBox="0 0 48 49" fill="none" xmlns="http://www.w3.org/2000/svg">
                                        <path d="M0 6.05371V42.0537L18 24.0537V6.05371H0Z" fill="#D5283A" />
                                        <path d="M30 6.05371V42.0537L48 24.0537V6.05371H30Z" fill="#D5283A" />
                                    </svg>
                                </div>
                                <div>
                                    <div class="margin-bottom-8">
                                        <h3>Fast, helpful AdsAsia team</h3>
                                    </div>
                                    <div class="max-width-852">
                                        <div class="text-color-gray-300">As a small business owner, I was always restricted when running ads for my own product line. AdsAsia provided a smooth solution and now I can finally advertise!</div>
                                    </div>
                                </div>
                                <div class="testimonial-link-box">
                                    <div class="testimonial-author-box">
                                        <div class="text-size-18 text-weight-bold">—</div>
                                        <div class="text-color-gray-300">Matthew Colby, France</div>
                                    </div>
                                    <a href="https://uk.trustpilot.com/users/66c0f8a75635e909b6de844a" target="_blank" class="testimonial-link-source w-inline-block">
                                        <div class="text-size-18 text-weight-bold">Source</div>
                                        <div class="embed w-embed">
                                            <svg width="24" height="25" viewBox="0 0 24 25" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                <path d="M7 17.0793L17 7.07935M17 7.07935H7M17 7.07935V17.0793" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" />
                                            </svg>
                                        </div>
                                    </a>
                                </div>
                            </div>
                        </div>
                        <div class="w-dyn-list">
                            <div role="list" class="w-dyn-items">
                                <div role="listitem" class="w-dyn-item">
                                    <div class="platform-testimonial-slide">
                                        <div class="max-width-312 set-max-width-none">
                                            <div class="testimonial-client-score">
                                                <div class="set-text-align-left">
                                                    <div class="margin-bottom-8">
                                                        <div class="heading-64 text-weight-bold line-height-1">
                                                            5
                                                        </div>
                                                    </div>
                                                    <div class="margin-bottom-16 set-margin-bottom-24">
                                                        <div class="text-size-14">Client’s score</div>
                                                    </div>
                                                    <div class="testimonial-rating-box">
                                                        <div class="embed w-embed">
                                                            <svg width="25" height="25" viewBox="0 0 25 25" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                                <rect width="24.1379" height="24.1379" transform="translate(0 0.484863)" fill="#219653" />
                                                                <path
                                                                    d="M12.0689 16.9904L15.7399 16.0074L17.2736 21.002L12.0689 16.9904ZM20.5172 10.5347H14.0552L12.0689 4.10547L10.0825 10.5347H3.62061L8.85049 14.5197L6.86414 20.9489L12.094 16.9638L15.3124 14.5197L20.5172 10.5347Z"
                                                                    fill="white"
                                                                />
                                                            </svg>
                                                        </div>
                                                        <div class="embed w-embed">
                                                            <svg width="25" height="25" viewBox="0 0 25 25" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                                <rect width="24.1379" height="24.1379" transform="translate(0 0.484863)" fill="#219653" />
                                                                <path
                                                                    d="M12.0689 16.9904L15.7399 16.0074L17.2736 21.002L12.0689 16.9904ZM20.5172 10.5347H14.0552L12.0689 4.10547L10.0825 10.5347H3.62061L8.85049 14.5197L6.86414 20.9489L12.094 16.9638L15.3124 14.5197L20.5172 10.5347Z"
                                                                    fill="white"
                                                                />
                                                            </svg>
                                                        </div>
                                                        <div class="embed w-embed">
                                                            <svg width="25" height="25" viewBox="0 0 25 25" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                                <rect width="24.1379" height="24.1379" transform="translate(0 0.484863)" fill="#219653" />
                                                                <path
                                                                    d="M12.0689 16.9904L15.7399 16.0074L17.2736 21.002L12.0689 16.9904ZM20.5172 10.5347H14.0552L12.0689 4.10547L10.0825 10.5347H3.62061L8.85049 14.5197L6.86414 20.9489L12.094 16.9638L15.3124 14.5197L20.5172 10.5347Z"
                                                                    fill="white"
                                                                />
                                                            </svg>
                                                        </div>
                                                        <div class="embed w-embed">
                                                            <svg width="25" height="25" viewBox="0 0 25 25" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                                <rect width="24.1379" height="24.1379" transform="translate(0 0.484863)" fill="#219653" />
                                                                <path
                                                                    d="M12.0689 16.9904L15.7399 16.0074L17.2736 21.002L12.0689 16.9904ZM20.5172 10.5347H14.0552L12.0689 4.10547L10.0825 10.5347H3.62061L8.85049 14.5197L6.86414 20.9489L12.094 16.9638L15.3124 14.5197L20.5172 10.5347Z"
                                                                    fill="white"
                                                                />
                                                            </svg>
                                                        </div>
                                                        <div class="embed w-embed">
                                                            <svg width="25" height="25" viewBox="0 0 25 25" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                                <rect width="24.1379" height="24.1379" transform="translate(0 0.484863)" fill="#219653" />
                                                                <path
                                                                    d="M12.0689 16.9904L15.7399 16.0074L17.2736 21.002L12.0689 16.9904ZM20.5172 10.5347H14.0552L12.0689 4.10547L10.0825 10.5347H3.62061L8.85049 14.5197L6.86414 20.9489L12.094 16.9638L15.3124 14.5197L20.5172 10.5347Z"
                                                                    fill="white"
                                                                />
                                                            </svg>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="testimonial-logo-bottom">
                                                    <a href="https://uk.trustpilot.com/reviews/66f2bf88c73148e80b938e33" target="_blank" class="testimonial-link-source w-inline-block">
                                                        <div class="text-size-18 text-weight-bold set-text-size-14">
                                                            Source
                                                        </div>
                                                        <div class="fix-24">
                                                            <div data-button-icon="hover" class="embed w-embed">
                                                                <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                                    <path d="M5 12H19M19 12L12 5M19 12L12 19" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" />
                                                                </svg>
                                                            </div>
                                                            <div data-button-icon="normal" class="embed w-embed">
                                                                <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                                    <path d="M9 18L15 12L9 6" stroke="white" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" />
                                                                </svg>
                                                            </div>
                                                        </div>
                                                    </a>
                                                    <div><img loading="lazy" src="https://cdn.prod.website-files.com/668b3733f80ed0dcd2c46207/668f55e450eeb735f8c47eb3_Trustpilot%20logo.png" alt="" /></div>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="inner-line width"></div>
                                        <div class="platform-testimonial-content">
                                            <div class="embed w-embed">
                                                <svg width="48" height="49" viewBox="0 0 48 49" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                    <path d="M0 6.05371V42.0537L18 24.0537V6.05371H0Z" fill="#D5283A" />
                                                    <path d="M30 6.05371V42.0537L48 24.0537V6.05371H30Z" fill="#D5283A" />
                                                </svg>
                                            </div>
                                            <div>
                                                <div class="margin-bottom-8">
                                                    <h3>JV and his team are amazing</h3>
                                                </div>
                                                <div class="max-width-852">
                                                    <div class="text-color-gray-300">
                                                        JV and his team are amazing! He is always super quick to respond, and even helps me out on weekends. His dedication and experience in advertising makes a huge difference. I highly
                                                        recommend!
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="testimonial-link-box">
                                                <div class="testimonial-author-box">
                                                    <div class="text-size-18 text-weight-bold">—</div>
                                                    <div class="testimonial-box-author">
                                                        <div class="text-color-gray-300">Paulo M</div>
                                                        <div class="text-color-gray-300">,</div>
                                                        <div class="text-color-gray-300">BR</div>
                                                    </div>
                                                </div>
                                                <div class="hide-mobile-landscape">
                                                    <a href="https://uk.trustpilot.com/reviews/66f2bf88c73148e80b938e33" target="_blank" class="testimonial-link-source w-inline-block">
                                                        <div class="text-size-18 text-weight-bold">Source</div>
                                                        <div class="fix-24">
                                                            <div data-button-icon="hover" class="embed w-embed">
                                                                <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                                    <path d="M5 12H19M19 12L12 5M19 12L12 19" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" />
                                                                </svg>
                                                            </div>
                                                            <div data-button-icon="normal" class="embed w-embed">
                                                                <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                                    <path d="M9 18L15 12L9 6" stroke="white" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" />
                                                                </svg>
                                                            </div>
                                                        </div>
                                                    </a>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="w-slide">
                        <div class="platform-testimonial-slide hide-this">
                            <div class="max-width-312">
                                <div class="testimonial-client-score">
                                    <div>
                                        <div class="margin-bottom-8">
                                            <div class="heading-64 text-weight-bold line-height-1">5</div>
                                        </div>
                                        <div class="margin-bottom-16">
                                            <div class="text-size-14">Client’s score</div>
                                        </div>
                                        <div class="testimonial-rating-box">
                                            <div class="embed w-embed">
                                                <svg width="25" height="25" viewBox="0 0 25 25" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                    <rect width="24.1379" height="24.1379" transform="translate(0 0.484863)" fill="#219653" />
                                                    <path
                                                        d="M12.0689 16.9904L15.7399 16.0074L17.2736 21.002L12.0689 16.9904ZM20.5172 10.5347H14.0552L12.0689 4.10547L10.0825 10.5347H3.62061L8.85049 14.5197L6.86414 20.9489L12.094 16.9638L15.3124 14.5197L20.5172 10.5347Z"
                                                        fill="white"
                                                    />
                                                </svg>
                                            </div>
                                            <div class="embed w-embed">
                                                <svg width="25" height="25" viewBox="0 0 25 25" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                    <rect width="24.1379" height="24.1379" transform="translate(0 0.484863)" fill="#219653" />
                                                    <path
                                                        d="M12.0689 16.9904L15.7399 16.0074L17.2736 21.002L12.0689 16.9904ZM20.5172 10.5347H14.0552L12.0689 4.10547L10.0825 10.5347H3.62061L8.85049 14.5197L6.86414 20.9489L12.094 16.9638L15.3124 14.5197L20.5172 10.5347Z"
                                                        fill="white"
                                                    />
                                                </svg>
                                            </div>
                                            <div class="embed w-embed">
                                                <svg width="25" height="25" viewBox="0 0 25 25" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                    <rect width="24.1379" height="24.1379" transform="translate(0 0.484863)" fill="#219653" />
                                                    <path
                                                        d="M12.0689 16.9904L15.7399 16.0074L17.2736 21.002L12.0689 16.9904ZM20.5172 10.5347H14.0552L12.0689 4.10547L10.0825 10.5347H3.62061L8.85049 14.5197L6.86414 20.9489L12.094 16.9638L15.3124 14.5197L20.5172 10.5347Z"
                                                        fill="white"
                                                    />
                                                </svg>
                                            </div>
                                            <div class="embed w-embed">
                                                <svg width="25" height="25" viewBox="0 0 25 25" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                    <rect width="24.1379" height="24.1379" transform="translate(0 0.484863)" fill="#219653" />
                                                    <path
                                                        d="M12.0689 16.9904L15.7399 16.0074L17.2736 21.002L12.0689 16.9904ZM20.5172 10.5347H14.0552L12.0689 4.10547L10.0825 10.5347H3.62061L8.85049 14.5197L6.86414 20.9489L12.094 16.9638L15.3124 14.5197L20.5172 10.5347Z"
                                                        fill="white"
                                                    />
                                                </svg>
                                            </div>
                                            <div class="embed w-embed">
                                                <svg width="25" height="25" viewBox="0 0 25 25" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                    <rect width="24.1379" height="24.1379" transform="translate(0 0.484863)" fill="#219653" />
                                                    <path
                                                        d="M12.0689 16.9904L15.7399 16.0074L17.2736 21.002L12.0689 16.9904ZM20.5172 10.5347H14.0552L12.0689 4.10547L10.0825 10.5347H3.62061L8.85049 14.5197L6.86414 20.9489L12.094 16.9638L15.3124 14.5197L20.5172 10.5347Z"
                                                        fill="white"
                                                    />
                                                </svg>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="testimonial-logo-bottom">
                                        <div><img loading="lazy" src="https://cdn.prod.website-files.com/668b3733f80ed0dcd2c46207/668f55e450eeb735f8c47eb3_Trustpilot%20logo.png" alt="" /></div>
                                    </div>
                                </div>
                            </div>
                            <div class="inner-line width"></div>
                            <div class="platform-testimonial-content">
                                <div class="embed w-embed">
                                    <svg width="48" height="49" viewBox="0 0 48 49" fill="none" xmlns="http://www.w3.org/2000/svg">
                                        <path d="M0 6.05371V42.0537L18 24.0537V6.05371H0Z" fill="#D5283A" />
                                        <path d="M30 6.05371V42.0537L48 24.0537V6.05371H30Z" fill="#D5283A" />
                                    </svg>
                                </div>
                                <div>
                                    <div class="margin-bottom-8">
                                        <h3>Manager’s advice fixed product issues</h3>
                                    </div>
                                    <div class="max-width-852">
                                        <div class="text-color-gray-300">Whilst trying to run a new product I ran into some issues. The account manager gave me good advice and I can now run, very happy with the results.</div>
                                    </div>
                                </div>
                                <div class="testimonial-link-box">
                                    <div class="testimonial-author-box">
                                        <div class="text-size-18 text-weight-bold">—</div>
                                        <div class="text-color-gray-300">Noah Calloway, Belgium</div>
                                    </div>
                                    <a href="https://uk.trustpilot.com/users/66bbc7bc6ad35b8243cb3e43" target="_blank" class="testimonial-link-source w-inline-block">
                                        <div class="text-size-18 text-weight-bold">Source</div>
                                        <div class="embed w-embed">
                                            <svg width="24" height="25" viewBox="0 0 24 25" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                <path d="M7 17.0793L17 7.07935M17 7.07935H7M17 7.07935V17.0793" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" />
                                            </svg>
                                        </div>
                                    </a>
                                </div>
                            </div>
                        </div>
                        <div class="w-dyn-list">
                            <div role="list" class="w-dyn-items">
                                <div role="listitem" class="w-dyn-item">
                                    <div class="platform-testimonial-slide">
                                        <div class="max-width-312 set-max-width-none">
                                            <div class="testimonial-client-score">
                                                <div class="set-text-align-left">
                                                    <div class="margin-bottom-8">
                                                        <div class="heading-64 text-weight-bold line-height-1">
                                                            5
                                                        </div>
                                                    </div>
                                                    <div class="margin-bottom-16 set-margin-bottom-24">
                                                        <div class="text-size-14">Client’s score</div>
                                                    </div>
                                                    <div class="testimonial-rating-box">
                                                        <div class="embed w-embed">
                                                            <svg width="25" height="25" viewBox="0 0 25 25" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                                <rect width="24.1379" height="24.1379" transform="translate(0 0.484863)" fill="#219653" />
                                                                <path
                                                                    d="M12.0689 16.9904L15.7399 16.0074L17.2736 21.002L12.0689 16.9904ZM20.5172 10.5347H14.0552L12.0689 4.10547L10.0825 10.5347H3.62061L8.85049 14.5197L6.86414 20.9489L12.094 16.9638L15.3124 14.5197L20.5172 10.5347Z"
                                                                    fill="white"
                                                                />
                                                            </svg>
                                                        </div>
                                                        <div class="embed w-embed">
                                                            <svg width="25" height="25" viewBox="0 0 25 25" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                                <rect width="24.1379" height="24.1379" transform="translate(0 0.484863)" fill="#219653" />
                                                                <path
                                                                    d="M12.0689 16.9904L15.7399 16.0074L17.2736 21.002L12.0689 16.9904ZM20.5172 10.5347H14.0552L12.0689 4.10547L10.0825 10.5347H3.62061L8.85049 14.5197L6.86414 20.9489L12.094 16.9638L15.3124 14.5197L20.5172 10.5347Z"
                                                                    fill="white"
                                                                />
                                                            </svg>
                                                        </div>
                                                        <div class="embed w-embed">
                                                            <svg width="25" height="25" viewBox="0 0 25 25" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                                <rect width="24.1379" height="24.1379" transform="translate(0 0.484863)" fill="#219653" />
                                                                <path
                                                                    d="M12.0689 16.9904L15.7399 16.0074L17.2736 21.002L12.0689 16.9904ZM20.5172 10.5347H14.0552L12.0689 4.10547L10.0825 10.5347H3.62061L8.85049 14.5197L6.86414 20.9489L12.094 16.9638L15.3124 14.5197L20.5172 10.5347Z"
                                                                    fill="white"
                                                                />
                                                            </svg>
                                                        </div>
                                                        <div class="embed w-embed">
                                                            <svg width="25" height="25" viewBox="0 0 25 25" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                                <rect width="24.1379" height="24.1379" transform="translate(0 0.484863)" fill="#219653" />
                                                                <path
                                                                    d="M12.0689 16.9904L15.7399 16.0074L17.2736 21.002L12.0689 16.9904ZM20.5172 10.5347H14.0552L12.0689 4.10547L10.0825 10.5347H3.62061L8.85049 14.5197L6.86414 20.9489L12.094 16.9638L15.3124 14.5197L20.5172 10.5347Z"
                                                                    fill="white"
                                                                />
                                                            </svg>
                                                        </div>
                                                        <div class="embed w-embed">
                                                            <svg width="25" height="25" viewBox="0 0 25 25" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                                <rect width="24.1379" height="24.1379" transform="translate(0 0.484863)" fill="#219653" />
                                                                <path
                                                                    d="M12.0689 16.9904L15.7399 16.0074L17.2736 21.002L12.0689 16.9904ZM20.5172 10.5347H14.0552L12.0689 4.10547L10.0825 10.5347H3.62061L8.85049 14.5197L6.86414 20.9489L12.094 16.9638L15.3124 14.5197L20.5172 10.5347Z"
                                                                    fill="white"
                                                                />
                                                            </svg>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="testimonial-logo-bottom">
                                                    <a href="https://uk.trustpilot.com/reviews/66f790372d6aa9a6143f7a31" target="_blank" class="testimonial-link-source w-inline-block">
                                                        <div class="text-size-18 text-weight-bold set-text-size-14">
                                                            Source
                                                        </div>
                                                        <div class="fix-24">
                                                            <div data-button-icon="hover" class="embed w-embed">
                                                                <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                                    <path d="M5 12H19M19 12L12 5M19 12L12 19" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" />
                                                                </svg>
                                                            </div>
                                                            <div data-button-icon="normal" class="embed w-embed">
                                                                <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                                    <path d="M9 18L15 12L9 6" stroke="white" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" />
                                                                </svg>
                                                            </div>
                                                        </div>
                                                    </a>
                                                    <div><img loading="lazy" src="https://cdn.prod.website-files.com/668b3733f80ed0dcd2c46207/668f55e450eeb735f8c47eb3_Trustpilot%20logo.png" alt="" /></div>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="inner-line width"></div>
                                        <div class="platform-testimonial-content">
                                            <div class="embed w-embed">
                                                <svg width="48" height="49" viewBox="0 0 48 49" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                    <path d="M0 6.05371V42.0537L18 24.0537V6.05371H0Z" fill="#D5283A" />
                                                    <path d="M30 6.05371V42.0537L48 24.0537V6.05371H30Z" fill="#D5283A" />
                                                </svg>
                                            </div>
                                            <div>
                                                <div class="margin-bottom-8">
                                                    <h3>Beyond outstanding service - thank you</h3>
                                                </div>
                                                <div class="max-width-852">
                                                    <div class="text-color-gray-300">
                                                        I&#x27;ve been using AdsAsia for just over a month now, and they&#x27;ve been beyond outstanding. Within 30 minutes I had my dashboard account ready and ad accounts requested. Within
                                                        24 hours I received my Facebook agency accounts and could start advertising. My account manager, Dom, has always been very helpful and supportive with all of my questions, and my
                                                        results on their ad accounts have been great. I usually do not write any reviews, but I had to for AdsAsia. Highly recommended!
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="testimonial-link-box">
                                                <div class="testimonial-author-box">
                                                    <div class="text-size-18 text-weight-bold">—</div>
                                                    <div class="testimonial-box-author">
                                                        <div class="text-color-gray-300">Christopher Jones</div>
                                                        <div class="text-color-gray-300">,</div>
                                                        <div class="text-color-gray-300">US</div>
                                                    </div>
                                                </div>
                                                <div class="hide-mobile-landscape">
                                                    <a href="https://uk.trustpilot.com/reviews/66f790372d6aa9a6143f7a31" target="_blank" class="testimonial-link-source w-inline-block">
                                                        <div class="text-size-18 text-weight-bold">Source</div>
                                                        <div class="fix-24">
                                                            <div data-button-icon="hover" class="embed w-embed">
                                                                <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                                    <path d="M5 12H19M19 12L12 5M19 12L12 19" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" />
                                                                </svg>
                                                            </div>
                                                            <div data-button-icon="normal" class="embed w-embed">
                                                                <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                                    <path d="M9 18L15 12L9 6" stroke="white" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" />
                                                                </svg>
                                                            </div>
                                                        </div>
                                                    </a>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="w-slide">
                        <div class="platform-testimonial-slide hide-this">
                            <div class="max-width-312">
                                <div class="testimonial-client-score">
                                    <div>
                                        <div class="margin-bottom-8">
                                            <div class="heading-64 text-weight-bold line-height-1">5</div>
                                        </div>
                                        <div class="margin-bottom-16">
                                            <div class="text-size-14">Client’s score</div>
                                        </div>
                                        <div class="testimonial-rating-box">
                                            <div class="embed w-embed">
                                                <svg width="25" height="25" viewBox="0 0 25 25" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                    <rect width="24.1379" height="24.1379" transform="translate(0 0.484863)" fill="#219653" />
                                                    <path
                                                        d="M12.0689 16.9904L15.7399 16.0074L17.2736 21.002L12.0689 16.9904ZM20.5172 10.5347H14.0552L12.0689 4.10547L10.0825 10.5347H3.62061L8.85049 14.5197L6.86414 20.9489L12.094 16.9638L15.3124 14.5197L20.5172 10.5347Z"
                                                        fill="white"
                                                    />
                                                </svg>
                                            </div>
                                            <div class="embed w-embed">
                                                <svg width="25" height="25" viewBox="0 0 25 25" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                    <rect width="24.1379" height="24.1379" transform="translate(0 0.484863)" fill="#219653" />
                                                    <path
                                                        d="M12.0689 16.9904L15.7399 16.0074L17.2736 21.002L12.0689 16.9904ZM20.5172 10.5347H14.0552L12.0689 4.10547L10.0825 10.5347H3.62061L8.85049 14.5197L6.86414 20.9489L12.094 16.9638L15.3124 14.5197L20.5172 10.5347Z"
                                                        fill="white"
                                                    />
                                                </svg>
                                            </div>
                                            <div class="embed w-embed">
                                                <svg width="25" height="25" viewBox="0 0 25 25" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                    <rect width="24.1379" height="24.1379" transform="translate(0 0.484863)" fill="#219653" />
                                                    <path
                                                        d="M12.0689 16.9904L15.7399 16.0074L17.2736 21.002L12.0689 16.9904ZM20.5172 10.5347H14.0552L12.0689 4.10547L10.0825 10.5347H3.62061L8.85049 14.5197L6.86414 20.9489L12.094 16.9638L15.3124 14.5197L20.5172 10.5347Z"
                                                        fill="white"
                                                    />
                                                </svg>
                                            </div>
                                            <div class="embed w-embed">
                                                <svg width="25" height="25" viewBox="0 0 25 25" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                    <rect width="24.1379" height="24.1379" transform="translate(0 0.484863)" fill="#219653" />
                                                    <path
                                                        d="M12.0689 16.9904L15.7399 16.0074L17.2736 21.002L12.0689 16.9904ZM20.5172 10.5347H14.0552L12.0689 4.10547L10.0825 10.5347H3.62061L8.85049 14.5197L6.86414 20.9489L12.094 16.9638L15.3124 14.5197L20.5172 10.5347Z"
                                                        fill="white"
                                                    />
                                                </svg>
                                            </div>
                                            <div class="embed w-embed">
                                                <svg width="25" height="25" viewBox="0 0 25 25" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                    <rect width="24.1379" height="24.1379" transform="translate(0 0.484863)" fill="#219653" />
                                                    <path
                                                        d="M12.0689 16.9904L15.7399 16.0074L17.2736 21.002L12.0689 16.9904ZM20.5172 10.5347H14.0552L12.0689 4.10547L10.0825 10.5347H3.62061L8.85049 14.5197L6.86414 20.9489L12.094 16.9638L15.3124 14.5197L20.5172 10.5347Z"
                                                        fill="white"
                                                    />
                                                </svg>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="testimonial-logo-bottom">
                                        <div><img loading="lazy" src="https://cdn.prod.website-files.com/668b3733f80ed0dcd2c46207/668f55e450eeb735f8c47eb3_Trustpilot%20logo.png" alt="" /></div>
                                    </div>
                                </div>
                            </div>
                            <div class="inner-line width"></div>
                            <div class="platform-testimonial-content">
                                <div class="embed w-embed">
                                    <svg width="48" height="49" viewBox="0 0 48 49" fill="none" xmlns="http://www.w3.org/2000/svg">
                                        <path d="M0 6.05371V42.0537L18 24.0537V6.05371H0Z" fill="#D5283A" />
                                        <path d="M30 6.05371V42.0537L48 24.0537V6.05371H30Z" fill="#D5283A" />
                                    </svg>
                                </div>
                                <div>
                                    <div class="margin-bottom-8">
                                        <h3>Excellent results with AdsAsia ads</h3>
                                    </div>
                                    <div class="max-width-852">
                                        <div class="text-color-gray-300">Finally found an agency that allows me to run campaigns without problems.</div>
                                    </div>
                                </div>
                                <div class="testimonial-link-box">
                                    <div class="testimonial-author-box">
                                        <div class="text-size-18 text-weight-bold">—</div>
                                        <div class="text-color-gray-300">Alexander Penrose, Norway</div>
                                    </div>
                                    <a href="https://uk.trustpilot.com/users/66c44ba1d02d0533104989e2" target="_blank" class="testimonial-link-source w-inline-block">
                                        <div class="text-size-18 text-weight-bold">Source</div>
                                        <div class="embed w-embed">
                                            <svg width="24" height="25" viewBox="0 0 24 25" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                <path d="M7 17.0793L17 7.07935M17 7.07935H7M17 7.07935V17.0793" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" />
                                            </svg>
                                        </div>
                                    </a>
                                </div>
                            </div>
                        </div>
                        <div class="w-dyn-list">
                            <div role="list" class="w-dyn-items">
                                <div role="listitem" class="w-dyn-item">
                                    <div class="platform-testimonial-slide">
                                        <div class="max-width-312 set-max-width-none">
                                            <div class="testimonial-client-score">
                                                <div class="set-text-align-left">
                                                    <div class="margin-bottom-8">
                                                        <div class="heading-64 text-weight-bold line-height-1">
                                                            5
                                                        </div>
                                                    </div>
                                                    <div class="margin-bottom-16 set-margin-bottom-24">
                                                        <div class="text-size-14">Client’s score</div>
                                                    </div>
                                                    <div class="testimonial-rating-box">
                                                        <div class="embed w-embed">
                                                            <svg width="25" height="25" viewBox="0 0 25 25" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                                <rect width="24.1379" height="24.1379" transform="translate(0 0.484863)" fill="#219653" />
                                                                <path
                                                                    d="M12.0689 16.9904L15.7399 16.0074L17.2736 21.002L12.0689 16.9904ZM20.5172 10.5347H14.0552L12.0689 4.10547L10.0825 10.5347H3.62061L8.85049 14.5197L6.86414 20.9489L12.094 16.9638L15.3124 14.5197L20.5172 10.5347Z"
                                                                    fill="white"
                                                                />
                                                            </svg>
                                                        </div>
                                                        <div class="embed w-embed">
                                                            <svg width="25" height="25" viewBox="0 0 25 25" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                                <rect width="24.1379" height="24.1379" transform="translate(0 0.484863)" fill="#219653" />
                                                                <path
                                                                    d="M12.0689 16.9904L15.7399 16.0074L17.2736 21.002L12.0689 16.9904ZM20.5172 10.5347H14.0552L12.0689 4.10547L10.0825 10.5347H3.62061L8.85049 14.5197L6.86414 20.9489L12.094 16.9638L15.3124 14.5197L20.5172 10.5347Z"
                                                                    fill="white"
                                                                />
                                                            </svg>
                                                        </div>
                                                        <div class="embed w-embed">
                                                            <svg width="25" height="25" viewBox="0 0 25 25" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                                <rect width="24.1379" height="24.1379" transform="translate(0 0.484863)" fill="#219653" />
                                                                <path
                                                                    d="M12.0689 16.9904L15.7399 16.0074L17.2736 21.002L12.0689 16.9904ZM20.5172 10.5347H14.0552L12.0689 4.10547L10.0825 10.5347H3.62061L8.85049 14.5197L6.86414 20.9489L12.094 16.9638L15.3124 14.5197L20.5172 10.5347Z"
                                                                    fill="white"
                                                                />
                                                            </svg>
                                                        </div>
                                                        <div class="embed w-embed">
                                                            <svg width="25" height="25" viewBox="0 0 25 25" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                                <rect width="24.1379" height="24.1379" transform="translate(0 0.484863)" fill="#219653" />
                                                                <path
                                                                    d="M12.0689 16.9904L15.7399 16.0074L17.2736 21.002L12.0689 16.9904ZM20.5172 10.5347H14.0552L12.0689 4.10547L10.0825 10.5347H3.62061L8.85049 14.5197L6.86414 20.9489L12.094 16.9638L15.3124 14.5197L20.5172 10.5347Z"
                                                                    fill="white"
                                                                />
                                                            </svg>
                                                        </div>
                                                        <div class="embed w-embed">
                                                            <svg width="25" height="25" viewBox="0 0 25 25" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                                <rect width="24.1379" height="24.1379" transform="translate(0 0.484863)" fill="#219653" />
                                                                <path
                                                                    d="M12.0689 16.9904L15.7399 16.0074L17.2736 21.002L12.0689 16.9904ZM20.5172 10.5347H14.0552L12.0689 4.10547L10.0825 10.5347H3.62061L8.85049 14.5197L6.86414 20.9489L12.094 16.9638L15.3124 14.5197L20.5172 10.5347Z"
                                                                    fill="white"
                                                                />
                                                            </svg>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="testimonial-logo-bottom">
                                                    <a href="https://uk.trustpilot.com/reviews/66f6bae97b5a12773ae5d668" target="_blank" class="testimonial-link-source w-inline-block">
                                                        <div class="text-size-18 text-weight-bold set-text-size-14">
                                                            Source
                                                        </div>
                                                        <div class="fix-24">
                                                            <div data-button-icon="hover" class="embed w-embed">
                                                                <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                                    <path d="M5 12H19M19 12L12 5M19 12L12 19" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" />
                                                                </svg>
                                                            </div>
                                                            <div data-button-icon="normal" class="embed w-embed">
                                                                <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                                    <path d="M9 18L15 12L9 6" stroke="white" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" />
                                                                </svg>
                                                            </div>
                                                        </div>
                                                    </a>
                                                    <div><img loading="lazy" src="https://cdn.prod.website-files.com/668b3733f80ed0dcd2c46207/668f55e450eeb735f8c47eb3_Trustpilot%20logo.png" alt="" /></div>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="inner-line width"></div>
                                        <div class="platform-testimonial-content">
                                            <div class="embed w-embed">
                                                <svg width="48" height="49" viewBox="0 0 48 49" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                    <path d="M0 6.05371V42.0537L18 24.0537V6.05371H0Z" fill="#D5283A" />
                                                    <path d="M30 6.05371V42.0537L48 24.0537V6.05371H30Z" fill="#D5283A" />
                                                </svg>
                                            </div>
                                            <div>
                                                <div class="margin-bottom-8">
                                                    <h3>One year experience with AdsAsia</h3>
                                                </div>
                                                <div class="max-width-852">
                                                    <div class="text-color-gray-300">
                                                        Hello, I am from Russia. I have worked with AdsAsia for almost one year. I am very happy with the service from this agency and the account managers always respond very quickly and most
                                                        actions I can manage myself from the dashboard. Also they do not charge me any commission on ad spending so I am more happy.
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="testimonial-link-box">
                                                <div class="testimonial-author-box">
                                                    <div class="text-size-18 text-weight-bold">—</div>
                                                    <div class="testimonial-box-author">
                                                        <div class="text-color-gray-300">Aleksey F</div>
                                                        <div class="text-color-gray-300">,</div>
                                                        <div class="text-color-gray-300">RU</div>
                                                    </div>
                                                </div>
                                                <div class="hide-mobile-landscape">
                                                    <a href="https://uk.trustpilot.com/reviews/66f6bae97b5a12773ae5d668" target="_blank" class="testimonial-link-source w-inline-block">
                                                        <div class="text-size-18 text-weight-bold">Source</div>
                                                        <div class="fix-24">
                                                            <div data-button-icon="hover" class="embed w-embed">
                                                                <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                                    <path d="M5 12H19M19 12L12 5M19 12L12 19" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" />
                                                                </svg>
                                                            </div>
                                                            <div data-button-icon="normal" class="embed w-embed">
                                                                <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                                    <path d="M9 18L15 12L9 6" stroke="white" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" />
                                                                </svg>
                                                            </div>
                                                        </div>
                                                    </a>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="w-slide">
                        <div class="platform-testimonial-slide hide-this">
                            <div class="max-width-312">
                                <div class="testimonial-client-score">
                                    <div>
                                        <div class="margin-bottom-8">
                                            <div class="heading-64 text-weight-bold line-height-1">5</div>
                                        </div>
                                        <div class="margin-bottom-16">
                                            <div class="text-size-14">Client’s score</div>
                                        </div>
                                        <div class="testimonial-rating-box">
                                            <div class="embed w-embed">
                                                <svg width="25" height="25" viewBox="0 0 25 25" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                    <rect width="24.1379" height="24.1379" transform="translate(0 0.484863)" fill="#219653" />
                                                    <path
                                                        d="M12.0689 16.9904L15.7399 16.0074L17.2736 21.002L12.0689 16.9904ZM20.5172 10.5347H14.0552L12.0689 4.10547L10.0825 10.5347H3.62061L8.85049 14.5197L6.86414 20.9489L12.094 16.9638L15.3124 14.5197L20.5172 10.5347Z"
                                                        fill="white"
                                                    />
                                                </svg>
                                            </div>
                                            <div class="embed w-embed">
                                                <svg width="25" height="25" viewBox="0 0 25 25" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                    <rect width="24.1379" height="24.1379" transform="translate(0 0.484863)" fill="#219653" />
                                                    <path
                                                        d="M12.0689 16.9904L15.7399 16.0074L17.2736 21.002L12.0689 16.9904ZM20.5172 10.5347H14.0552L12.0689 4.10547L10.0825 10.5347H3.62061L8.85049 14.5197L6.86414 20.9489L12.094 16.9638L15.3124 14.5197L20.5172 10.5347Z"
                                                        fill="white"
                                                    />
                                                </svg>
                                            </div>
                                            <div class="embed w-embed">
                                                <svg width="25" height="25" viewBox="0 0 25 25" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                    <rect width="24.1379" height="24.1379" transform="translate(0 0.484863)" fill="#219653" />
                                                    <path
                                                        d="M12.0689 16.9904L15.7399 16.0074L17.2736 21.002L12.0689 16.9904ZM20.5172 10.5347H14.0552L12.0689 4.10547L10.0825 10.5347H3.62061L8.85049 14.5197L6.86414 20.9489L12.094 16.9638L15.3124 14.5197L20.5172 10.5347Z"
                                                        fill="white"
                                                    />
                                                </svg>
                                            </div>
                                            <div class="embed w-embed">
                                                <svg width="25" height="25" viewBox="0 0 25 25" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                    <rect width="24.1379" height="24.1379" transform="translate(0 0.484863)" fill="#219653" />
                                                    <path
                                                        d="M12.0689 16.9904L15.7399 16.0074L17.2736 21.002L12.0689 16.9904ZM20.5172 10.5347H14.0552L12.0689 4.10547L10.0825 10.5347H3.62061L8.85049 14.5197L6.86414 20.9489L12.094 16.9638L15.3124 14.5197L20.5172 10.5347Z"
                                                        fill="white"
                                                    />
                                                </svg>
                                            </div>
                                            <div class="embed w-embed">
                                                <svg width="25" height="25" viewBox="0 0 25 25" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                    <rect width="24.1379" height="24.1379" transform="translate(0 0.484863)" fill="#219653" />
                                                    <path
                                                        d="M12.0689 16.9904L15.7399 16.0074L17.2736 21.002L12.0689 16.9904ZM20.5172 10.5347H14.0552L12.0689 4.10547L10.0825 10.5347H3.62061L8.85049 14.5197L6.86414 20.9489L12.094 16.9638L15.3124 14.5197L20.5172 10.5347Z"
                                                        fill="white"
                                                    />
                                                </svg>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="testimonial-logo-bottom">
                                        <div><img loading="lazy" src="https://cdn.prod.website-files.com/668b3733f80ed0dcd2c46207/668f55e450eeb735f8c47eb3_Trustpilot%20logo.png" alt="" /></div>
                                    </div>
                                </div>
                            </div>
                            <div class="inner-line width"></div>
                            <div class="platform-testimonial-content">
                                <div class="embed w-embed">
                                    <svg width="48" height="49" viewBox="0 0 48 49" fill="none" xmlns="http://www.w3.org/2000/svg">
                                        <path d="M0 6.05371V42.0537L18 24.0537V6.05371H0Z" fill="#D5283A" />
                                        <path d="M30 6.05371V42.0537L48 24.0537V6.05371H30Z" fill="#D5283A" />
                                    </svg>
                                </div>
                                <div>
                                    <div class="margin-bottom-8">
                                        <h3>Great Job AdsAsia!</h3>
                                    </div>
                                    <div class="max-width-852">
                                        <div class="text-color-gray-300">
                                            AdsAsia Agency has done an excellent job! They recently reduced their crypto fee from 2% to 1.5%, which has been incredibly beneficial for our small business. This reduction helps us save on costs
                                            and manage our finances more effectively. Thank you, AdsAsia, for supporting small businesses like ours!
                                        </div>
                                    </div>
                                </div>
                                <div class="testimonial-link-box">
                                    <div class="testimonial-author-box">
                                        <div class="text-size-18 text-weight-bold">—</div>
                                        <div class="text-color-gray-300">Annabelle Woolf, Canada</div>
                                    </div>
                                    <a href="https://uk.trustpilot.com/users/6653bdd4d11b292c6d2f3c96" target="_blank" class="testimonial-link-source w-inline-block">
                                        <div class="text-size-18 text-weight-bold">Source</div>
                                        <div class="embed w-embed">
                                            <svg width="24" height="25" viewBox="0 0 24 25" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                <path d="M7 17.0793L17 7.07935M17 7.07935H7M17 7.07935V17.0793" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" />
                                            </svg>
                                        </div>
                                    </a>
                                </div>
                            </div>
                        </div>
                        <div class="w-dyn-list">
                            <div role="list" class="w-dyn-items">
                                <div role="listitem" class="w-dyn-item">
                                    <div class="platform-testimonial-slide">
                                        <div class="max-width-312 set-max-width-none">
                                            <div class="testimonial-client-score">
                                                <div class="set-text-align-left">
                                                    <div class="margin-bottom-8">
                                                        <div class="heading-64 text-weight-bold line-height-1">
                                                            5
                                                        </div>
                                                    </div>
                                                    <div class="margin-bottom-16 set-margin-bottom-24">
                                                        <div class="text-size-14">Client’s score</div>
                                                    </div>
                                                    <div class="testimonial-rating-box">
                                                        <div class="embed w-embed">
                                                            <svg width="25" height="25" viewBox="0 0 25 25" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                                <rect width="24.1379" height="24.1379" transform="translate(0 0.484863)" fill="#219653" />
                                                                <path
                                                                    d="M12.0689 16.9904L15.7399 16.0074L17.2736 21.002L12.0689 16.9904ZM20.5172 10.5347H14.0552L12.0689 4.10547L10.0825 10.5347H3.62061L8.85049 14.5197L6.86414 20.9489L12.094 16.9638L15.3124 14.5197L20.5172 10.5347Z"
                                                                    fill="white"
                                                                />
                                                            </svg>
                                                        </div>
                                                        <div class="embed w-embed">
                                                            <svg width="25" height="25" viewBox="0 0 25 25" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                                <rect width="24.1379" height="24.1379" transform="translate(0 0.484863)" fill="#219653" />
                                                                <path
                                                                    d="M12.0689 16.9904L15.7399 16.0074L17.2736 21.002L12.0689 16.9904ZM20.5172 10.5347H14.0552L12.0689 4.10547L10.0825 10.5347H3.62061L8.85049 14.5197L6.86414 20.9489L12.094 16.9638L15.3124 14.5197L20.5172 10.5347Z"
                                                                    fill="white"
                                                                />
                                                            </svg>
                                                        </div>
                                                        <div class="embed w-embed">
                                                            <svg width="25" height="25" viewBox="0 0 25 25" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                                <rect width="24.1379" height="24.1379" transform="translate(0 0.484863)" fill="#219653" />
                                                                <path
                                                                    d="M12.0689 16.9904L15.7399 16.0074L17.2736 21.002L12.0689 16.9904ZM20.5172 10.5347H14.0552L12.0689 4.10547L10.0825 10.5347H3.62061L8.85049 14.5197L6.86414 20.9489L12.094 16.9638L15.3124 14.5197L20.5172 10.5347Z"
                                                                    fill="white"
                                                                />
                                                            </svg>
                                                        </div>
                                                        <div class="embed w-embed">
                                                            <svg width="25" height="25" viewBox="0 0 25 25" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                                <rect width="24.1379" height="24.1379" transform="translate(0 0.484863)" fill="#219653" />
                                                                <path
                                                                    d="M12.0689 16.9904L15.7399 16.0074L17.2736 21.002L12.0689 16.9904ZM20.5172 10.5347H14.0552L12.0689 4.10547L10.0825 10.5347H3.62061L8.85049 14.5197L6.86414 20.9489L12.094 16.9638L15.3124 14.5197L20.5172 10.5347Z"
                                                                    fill="white"
                                                                />
                                                            </svg>
                                                        </div>
                                                        <div class="embed w-embed">
                                                            <svg width="25" height="25" viewBox="0 0 25 25" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                                <rect width="24.1379" height="24.1379" transform="translate(0 0.484863)" fill="#219653" />
                                                                <path
                                                                    d="M12.0689 16.9904L15.7399 16.0074L17.2736 21.002L12.0689 16.9904ZM20.5172 10.5347H14.0552L12.0689 4.10547L10.0825 10.5347H3.62061L8.85049 14.5197L6.86414 20.9489L12.094 16.9638L15.3124 14.5197L20.5172 10.5347Z"
                                                                    fill="white"
                                                                />
                                                            </svg>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="testimonial-logo-bottom">
                                                    <a href="https://www.trustpilot.com/reviews/66f66d3a17eb00679859cc64" target="_blank" class="testimonial-link-source w-inline-block">
                                                        <div class="text-size-18 text-weight-bold set-text-size-14">
                                                            Source
                                                        </div>
                                                        <div class="fix-24">
                                                            <div data-button-icon="hover" class="embed w-embed">
                                                                <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                                    <path d="M5 12H19M19 12L12 5M19 12L12 19" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" />
                                                                </svg>
                                                            </div>
                                                            <div data-button-icon="normal" class="embed w-embed">
                                                                <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                                    <path d="M9 18L15 12L9 6" stroke="white" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" />
                                                                </svg>
                                                            </div>
                                                        </div>
                                                    </a>
                                                    <div><img loading="lazy" src="https://cdn.prod.website-files.com/668b3733f80ed0dcd2c46207/668f55e450eeb735f8c47eb3_Trustpilot%20logo.png" alt="" /></div>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="inner-line width"></div>
                                        <div class="platform-testimonial-content">
                                            <div class="embed w-embed">
                                                <svg width="48" height="49" viewBox="0 0 48 49" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                    <path d="M0 6.05371V42.0537L18 24.0537V6.05371H0Z" fill="#D5283A" />
                                                    <path d="M30 6.05371V42.0537L48 24.0537V6.05371H30Z" fill="#D5283A" />
                                                </svg>
                                            </div>
                                            <div>
                                                <div class="margin-bottom-8">
                                                    <h3>High quality service and ad accounts</h3>
                                                </div>
                                                <div class="max-width-852">
                                                    <div class="text-color-gray-300">
                                                        Grace is super helpful. She helped me with all requests very quick and I really recommend anyone to choose AdsAsia over any other agency. The process is simple and the service, top-ups
                                                        and responses are very quick. And most importantly the ad account quality is great.
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="testimonial-link-box">
                                                <div class="testimonial-author-box">
                                                    <div class="text-size-18 text-weight-bold">—</div>
                                                    <div class="testimonial-box-author">
                                                        <div class="text-color-gray-300">Mohamed Z</div>
                                                        <div class="text-color-gray-300">,</div>
                                                        <div class="text-color-gray-300">DZ</div>
                                                    </div>
                                                </div>
                                                <div class="hide-mobile-landscape">
                                                    <a href="https://www.trustpilot.com/reviews/66f66d3a17eb00679859cc64" target="_blank" class="testimonial-link-source w-inline-block">
                                                        <div class="text-size-18 text-weight-bold">Source</div>
                                                        <div class="fix-24">
                                                            <div data-button-icon="hover" class="embed w-embed">
                                                                <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                                    <path d="M5 12H19M19 12L12 5M19 12L12 19" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" />
                                                                </svg>
                                                            </div>
                                                            <div data-button-icon="normal" class="embed w-embed">
                                                                <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                                    <path d="M9 18L15 12L9 6" stroke="white" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" />
                                                                </svg>
                                                            </div>
                                                        </div>
                                                    </a>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="w-slide">
                        <div class="platform-testimonial-slide hide-this">
                            <div class="max-width-312">
                                <div class="testimonial-client-score">
                                    <div>
                                        <div class="margin-bottom-8">
                                            <div class="heading-64 text-weight-bold line-height-1">5</div>
                                        </div>
                                        <div class="margin-bottom-16">
                                            <div class="text-size-14">Client’s score</div>
                                        </div>
                                        <div class="testimonial-rating-box">
                                            <div class="embed w-embed">
                                                <svg width="25" height="25" viewBox="0 0 25 25" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                    <rect width="24.1379" height="24.1379" transform="translate(0 0.484863)" fill="#219653" />
                                                    <path
                                                        d="M12.0689 16.9904L15.7399 16.0074L17.2736 21.002L12.0689 16.9904ZM20.5172 10.5347H14.0552L12.0689 4.10547L10.0825 10.5347H3.62061L8.85049 14.5197L6.86414 20.9489L12.094 16.9638L15.3124 14.5197L20.5172 10.5347Z"
                                                        fill="white"
                                                    />
                                                </svg>
                                            </div>
                                            <div class="embed w-embed">
                                                <svg width="25" height="25" viewBox="0 0 25 25" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                    <rect width="24.1379" height="24.1379" transform="translate(0 0.484863)" fill="#219653" />
                                                    <path
                                                        d="M12.0689 16.9904L15.7399 16.0074L17.2736 21.002L12.0689 16.9904ZM20.5172 10.5347H14.0552L12.0689 4.10547L10.0825 10.5347H3.62061L8.85049 14.5197L6.86414 20.9489L12.094 16.9638L15.3124 14.5197L20.5172 10.5347Z"
                                                        fill="white"
                                                    />
                                                </svg>
                                            </div>
                                            <div class="embed w-embed">
                                                <svg width="25" height="25" viewBox="0 0 25 25" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                    <rect width="24.1379" height="24.1379" transform="translate(0 0.484863)" fill="#219653" />
                                                    <path
                                                        d="M12.0689 16.9904L15.7399 16.0074L17.2736 21.002L12.0689 16.9904ZM20.5172 10.5347H14.0552L12.0689 4.10547L10.0825 10.5347H3.62061L8.85049 14.5197L6.86414 20.9489L12.094 16.9638L15.3124 14.5197L20.5172 10.5347Z"
                                                        fill="white"
                                                    />
                                                </svg>
                                            </div>
                                            <div class="embed w-embed">
                                                <svg width="25" height="25" viewBox="0 0 25 25" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                    <rect width="24.1379" height="24.1379" transform="translate(0 0.484863)" fill="#219653" />
                                                    <path
                                                        d="M12.0689 16.9904L15.7399 16.0074L17.2736 21.002L12.0689 16.9904ZM20.5172 10.5347H14.0552L12.0689 4.10547L10.0825 10.5347H3.62061L8.85049 14.5197L6.86414 20.9489L12.094 16.9638L15.3124 14.5197L20.5172 10.5347Z"
                                                        fill="white"
                                                    />
                                                </svg>
                                            </div>
                                            <div class="embed w-embed">
                                                <svg width="25" height="25" viewBox="0 0 25 25" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                    <rect width="24.1379" height="24.1379" transform="translate(0 0.484863)" fill="#219653" />
                                                    <path
                                                        d="M12.0689 16.9904L15.7399 16.0074L17.2736 21.002L12.0689 16.9904ZM20.5172 10.5347H14.0552L12.0689 4.10547L10.0825 10.5347H3.62061L8.85049 14.5197L6.86414 20.9489L12.094 16.9638L15.3124 14.5197L20.5172 10.5347Z"
                                                        fill="white"
                                                    />
                                                </svg>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="testimonial-logo-bottom">
                                        <div><img loading="lazy" src="https://cdn.prod.website-files.com/668b3733f80ed0dcd2c46207/668f55e450eeb735f8c47eb3_Trustpilot%20logo.png" alt="" /></div>
                                    </div>
                                </div>
                            </div>
                            <div class="inner-line width"></div>
                            <div class="platform-testimonial-content">
                                <div class="embed w-embed">
                                    <svg width="48" height="49" viewBox="0 0 48 49" fill="none" xmlns="http://www.w3.org/2000/svg">
                                        <path d="M0 6.05371V42.0537L18 24.0537V6.05371H0Z" fill="#D5283A" />
                                        <path d="M30 6.05371V42.0537L48 24.0537V6.05371H30Z" fill="#D5283A" />
                                    </svg>
                                </div>
                                <div>
                                    <div class="margin-bottom-8">
                                        <h3>Fast, helpful AdsAsia team</h3>
                                    </div>
                                    <div class="max-width-852">
                                        <div class="text-color-gray-300">As a small business owner, I was always restricted when running ads for my own product line. AdsAsia provided a smooth solution and now I can finally advertise!</div>
                                    </div>
                                </div>
                                <div class="testimonial-link-box">
                                    <div class="testimonial-author-box">
                                        <div class="text-size-18 text-weight-bold">—</div>
                                        <div class="text-color-gray-300">Benjamin Harcourt, France</div>
                                    </div>
                                    <a href="#" target="_blank" class="testimonial-link-source w-inline-block">
                                        <div class="text-size-18 text-weight-bold">Source</div>
                                        <div class="embed w-embed">
                                            <svg width="24" height="25" viewBox="0 0 24 25" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                <path d="M7 17.0793L17 7.07935M17 7.07935H7M17 7.07935V17.0793" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" />
                                            </svg>
                                        </div>
                                    </a>
                                </div>
                            </div>
                        </div>
                        <div class="w-dyn-list">
                            <div role="list" class="w-dyn-items">
                                <div role="listitem" class="w-dyn-item">
                                    <div class="platform-testimonial-slide">
                                        <div class="max-width-312 set-max-width-none">
                                            <div class="testimonial-client-score">
                                                <div class="set-text-align-left">
                                                    <div class="margin-bottom-8">
                                                        <div class="heading-64 text-weight-bold line-height-1">
                                                            5
                                                        </div>
                                                    </div>
                                                    <div class="margin-bottom-16 set-margin-bottom-24">
                                                        <div class="text-size-14">Client’s score</div>
                                                    </div>
                                                    <div class="testimonial-rating-box">
                                                        <div class="embed w-embed">
                                                            <svg width="25" height="25" viewBox="0 0 25 25" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                                <rect width="24.1379" height="24.1379" transform="translate(0 0.484863)" fill="#219653" />
                                                                <path
                                                                    d="M12.0689 16.9904L15.7399 16.0074L17.2736 21.002L12.0689 16.9904ZM20.5172 10.5347H14.0552L12.0689 4.10547L10.0825 10.5347H3.62061L8.85049 14.5197L6.86414 20.9489L12.094 16.9638L15.3124 14.5197L20.5172 10.5347Z"
                                                                    fill="white"
                                                                />
                                                            </svg>
                                                        </div>
                                                        <div class="embed w-embed">
                                                            <svg width="25" height="25" viewBox="0 0 25 25" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                                <rect width="24.1379" height="24.1379" transform="translate(0 0.484863)" fill="#219653" />
                                                                <path
                                                                    d="M12.0689 16.9904L15.7399 16.0074L17.2736 21.002L12.0689 16.9904ZM20.5172 10.5347H14.0552L12.0689 4.10547L10.0825 10.5347H3.62061L8.85049 14.5197L6.86414 20.9489L12.094 16.9638L15.3124 14.5197L20.5172 10.5347Z"
                                                                    fill="white"
                                                                />
                                                            </svg>
                                                        </div>
                                                        <div class="embed w-embed">
                                                            <svg width="25" height="25" viewBox="0 0 25 25" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                                <rect width="24.1379" height="24.1379" transform="translate(0 0.484863)" fill="#219653" />
                                                                <path
                                                                    d="M12.0689 16.9904L15.7399 16.0074L17.2736 21.002L12.0689 16.9904ZM20.5172 10.5347H14.0552L12.0689 4.10547L10.0825 10.5347H3.62061L8.85049 14.5197L6.86414 20.9489L12.094 16.9638L15.3124 14.5197L20.5172 10.5347Z"
                                                                    fill="white"
                                                                />
                                                            </svg>
                                                        </div>
                                                        <div class="embed w-embed">
                                                            <svg width="25" height="25" viewBox="0 0 25 25" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                                <rect width="24.1379" height="24.1379" transform="translate(0 0.484863)" fill="#219653" />
                                                                <path
                                                                    d="M12.0689 16.9904L15.7399 16.0074L17.2736 21.002L12.0689 16.9904ZM20.5172 10.5347H14.0552L12.0689 4.10547L10.0825 10.5347H3.62061L8.85049 14.5197L6.86414 20.9489L12.094 16.9638L15.3124 14.5197L20.5172 10.5347Z"
                                                                    fill="white"
                                                                />
                                                            </svg>
                                                        </div>
                                                        <div class="embed w-embed">
                                                            <svg width="25" height="25" viewBox="0 0 25 25" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                                <rect width="24.1379" height="24.1379" transform="translate(0 0.484863)" fill="#219653" />
                                                                <path
                                                                    d="M12.0689 16.9904L15.7399 16.0074L17.2736 21.002L12.0689 16.9904ZM20.5172 10.5347H14.0552L12.0689 4.10547L10.0825 10.5347H3.62061L8.85049 14.5197L6.86414 20.9489L12.094 16.9638L15.3124 14.5197L20.5172 10.5347Z"
                                                                    fill="white"
                                                                />
                                                            </svg>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="testimonial-logo-bottom">
                                                    <a href="https://uk.trustpilot.com/reviews/66f1fa3af2b960e237ad5445" target="_blank" class="testimonial-link-source w-inline-block">
                                                        <div class="text-size-18 text-weight-bold set-text-size-14">
                                                            Source
                                                        </div>
                                                        <div class="fix-24">
                                                            <div data-button-icon="hover" class="embed w-embed">
                                                                <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                                    <path d="M5 12H19M19 12L12 5M19 12L12 19" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" />
                                                                </svg>
                                                            </div>
                                                            <div data-button-icon="normal" class="embed w-embed">
                                                                <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                                    <path d="M9 18L15 12L9 6" stroke="white" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" />
                                                                </svg>
                                                            </div>
                                                        </div>
                                                    </a>
                                                    <div><img loading="lazy" src="https://cdn.prod.website-files.com/668b3733f80ed0dcd2c46207/668f55e450eeb735f8c47eb3_Trustpilot%20logo.png" alt="" /></div>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="inner-line width"></div>
                                        <div class="platform-testimonial-content">
                                            <div class="embed w-embed">
                                                <svg width="48" height="49" viewBox="0 0 48 49" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                    <path d="M0 6.05371V42.0537L18 24.0537V6.05371H0Z" fill="#D5283A" />
                                                    <path d="M30 6.05371V42.0537L48 24.0537V6.05371H30Z" fill="#D5283A" />
                                                </svg>
                                            </div>
                                            <div>
                                                <div class="margin-bottom-8">
                                                    <h3>Game changer for Facebook agency accounts</h3>
                                                </div>
                                                <div class="max-width-852">
                                                    <div class="text-color-gray-300">
                                                        AdsAsia is a game changer for Facebook ads. I started using their agency accounts a month ago and I am more than impressed, it&#x27;s been such a great experience. The setup and
                                                        process was very smooth. The dashboard is easy to use and my account manager April is always so helpful and friendly. She responds whenever I need her and helps me answer any
                                                        questions. Thanks AdsAsia.
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="testimonial-link-box">
                                                <div class="testimonial-author-box">
                                                    <div class="text-size-18 text-weight-bold">—</div>
                                                    <div class="testimonial-box-author">
                                                        <div class="text-color-gray-300">Thomas</div>
                                                        <div class="text-color-gray-300">,</div>
                                                        <div class="text-color-gray-300">US</div>
                                                    </div>
                                                </div>
                                                <div class="hide-mobile-landscape">
                                                    <a href="https://uk.trustpilot.com/reviews/66f1fa3af2b960e237ad5445" target="_blank" class="testimonial-link-source w-inline-block">
                                                        <div class="text-size-18 text-weight-bold">Source</div>
                                                        <div class="fix-24">
                                                            <div data-button-icon="hover" class="embed w-embed">
                                                                <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                                    <path d="M5 12H19M19 12L12 5M19 12L12 19" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" />
                                                                </svg>
                                                            </div>
                                                            <div data-button-icon="normal" class="embed w-embed">
                                                                <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                                    <path d="M9 18L15 12L9 6" stroke="white" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" />
                                                                </svg>
                                                            </div>
                                                        </div>
                                                    </a>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div id="ts-left-arrow" class="hide w-slider-arrow-left">
                    <div class="w-icon-slider-left"></div>
                </div>
                <div id="ts-right-arrow" class="hide w-slider-arrow-right">
                    <div class="w-icon-slider-right"></div>
                </div>
                <div class="hide w-slider-nav w-round w-num"></div>
                <div class="spacer-24"></div>
                <div class="platform-slider-arrows">
                    <a id="out-right" href="#" class="platform-testimonial-arrow w-inline-block">
                        <div class="fix-24">
                            <div data-button-icon="normal" class="embed w-embed">
                                <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                                    <path d="M15 18L9 12L15 6" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" />
                                </svg>
                            </div>
                            <div data-button-icon="hover" class="embed w-embed">
                                <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                                    <path d="M19 12H5M5 12L12 19M5 12L12 5" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" />
                                </svg>
                            </div>
                        </div>
                    </a>
                    <a id="out-left" href="#" class="platform-testimonial-arrow w-inline-block">
                        <div class="fix-24">
                            <div data-button-icon="hover" class="embed w-embed">
                                <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                                    <path d="M5 12H19M19 12L12 5M19 12L12 19" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" />
                                </svg>
                            </div>
                            <div data-button-icon="normal" class="embed w-embed">
                                <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                                    <path d="M9 18L15 12L9 6" stroke="white" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" />
                                </svg>
                            </div>
                        </div>
                    </a>
                    <div class="hide w-embed w-script">
                        <script>
                            const leftArrow = document.getElementById("ts-left-arrow");
                            const leftButton = document.getElementById("out-left");
                            const rightArrow = document.getElementById("ts-right-arrow");
                            const rightButton = document.getElementById("out-right");

                            leftButton.addEventListener("click", function (e) {
                                rightArrow.click();
                            });

                            rightButton.addEventListener("click", function (e) {
                                leftArrow.click();
                            });
                        </script>
                    </div>
                </div>
            </div>
            <div class="platform-testimonial-container hide">
                <div class="splide__track">
                    <div class="platform-testimonial-slider splide__list">
                        <div class="splide__slide">
                            <div class="platform-testimonial-slide">
                                <div class="max-width-312">
                                    <div class="testimonial-client-score">
                                        <div>
                                            <div class="margin-bottom-8">
                                                <div class="heading-60 line-height-1">5</div>
                                            </div>
                                            <div class="margin-bottom-16">
                                                <div class="text-size-14">Client’s score</div>
                                            </div>
                                            <div class="testimonial-rating-box">
                                                <div class="embed w-embed">
                                                    <svg width="25" height="25" viewBox="0 0 25 25" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                        <rect width="24.1379" height="24.1379" transform="translate(0 0.484863)" fill="#219653" />
                                                        <path
                                                            d="M12.0689 16.9904L15.7399 16.0074L17.2736 21.002L12.0689 16.9904ZM20.5172 10.5347H14.0552L12.0689 4.10547L10.0825 10.5347H3.62061L8.85049 14.5197L6.86414 20.9489L12.094 16.9638L15.3124 14.5197L20.5172 10.5347Z"
                                                            fill="white"
                                                        />
                                                    </svg>
                                                </div>
                                                <div class="embed w-embed">
                                                    <svg width="25" height="25" viewBox="0 0 25 25" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                        <rect width="24.1379" height="24.1379" transform="translate(0 0.484863)" fill="#219653" />
                                                        <path
                                                            d="M12.0689 16.9904L15.7399 16.0074L17.2736 21.002L12.0689 16.9904ZM20.5172 10.5347H14.0552L12.0689 4.10547L10.0825 10.5347H3.62061L8.85049 14.5197L6.86414 20.9489L12.094 16.9638L15.3124 14.5197L20.5172 10.5347Z"
                                                            fill="white"
                                                        />
                                                    </svg>
                                                </div>
                                                <div class="embed w-embed">
                                                    <svg width="25" height="25" viewBox="0 0 25 25" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                        <rect width="24.1379" height="24.1379" transform="translate(0 0.484863)" fill="#219653" />
                                                        <path
                                                            d="M12.0689 16.9904L15.7399 16.0074L17.2736 21.002L12.0689 16.9904ZM20.5172 10.5347H14.0552L12.0689 4.10547L10.0825 10.5347H3.62061L8.85049 14.5197L6.86414 20.9489L12.094 16.9638L15.3124 14.5197L20.5172 10.5347Z"
                                                            fill="white"
                                                        />
                                                    </svg>
                                                </div>
                                                <div class="embed w-embed">
                                                    <svg width="25" height="25" viewBox="0 0 25 25" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                        <rect width="24.1379" height="24.1379" transform="translate(0 0.484863)" fill="#219653" />
                                                        <path
                                                            d="M12.0689 16.9904L15.7399 16.0074L17.2736 21.002L12.0689 16.9904ZM20.5172 10.5347H14.0552L12.0689 4.10547L10.0825 10.5347H3.62061L8.85049 14.5197L6.86414 20.9489L12.094 16.9638L15.3124 14.5197L20.5172 10.5347Z"
                                                            fill="white"
                                                        />
                                                    </svg>
                                                </div>
                                                <div class="embed w-embed">
                                                    <svg width="25" height="25" viewBox="0 0 25 25" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                        <rect width="24.1379" height="24.1379" transform="translate(0 0.484863)" fill="#219653" />
                                                        <path
                                                            d="M12.0689 16.9904L15.7399 16.0074L17.2736 21.002L12.0689 16.9904ZM20.5172 10.5347H14.0552L12.0689 4.10547L10.0825 10.5347H3.62061L8.85049 14.5197L6.86414 20.9489L12.094 16.9638L15.3124 14.5197L20.5172 10.5347Z"
                                                            fill="white"
                                                        />
                                                    </svg>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="testimonial-logo-bottom">
                                            <div><img src="https://cdn.prod.website-files.com/668b3733f80ed0dcd2c46207/668f55e450eeb735f8c47eb3_Trustpilot%20logo.png" loading="lazy" alt="" /></div>
                                        </div>
                                    </div>
                                </div>
                                <div class="inner-line width"></div>
                                <div class="platform-testimonial-content">
                                    <div class="embed w-embed">
                                        <svg width="48" height="49" viewBox="0 0 48 49" fill="none" xmlns="http://www.w3.org/2000/svg">
                                            <path d="M0 6.05371V42.0537L18 24.0537V6.05371H0Z" fill="#D5283A" />
                                            <path d="M30 6.05371V42.0537L48 24.0537V6.05371H30Z" fill="#D5283A" />
                                        </svg>
                                    </div>
                                    <div>
                                        <div class="margin-bottom-8">
                                            <h3>High-Quality Ad Accounts</h3>
                                        </div>
                                        <div class="text-color-gray-300">
                                            The ad accounts provided by AdsAsia Agency are of high quality. I’ve seen a significant improvement in my campaign performance since switching to their accounts. Highly recommend their services to
                                            anyone in need of reliable ad accounts.
                                        </div>
                                    </div>
                                    <div class="testimonial-link-box">
                                        <div class="testimonial-author-box">
                                            <div class="text-size-18 text-weight-bold">—</div>
                                            <div class="text-color-gray-300">Sophia Christenbury</div>
                                        </div>
                                        <a href="#" class="testimonial-link-source w-inline-block">
                                            <div class="text-size-18 text-weight-bold">Source</div>
                                            <div class="embed w-embed">
                                                <svg width="24" height="25" viewBox="0 0 24 25" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                    <path d="M7 17.0793L17 7.07935M17 7.07935H7M17 7.07935V17.0793" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" />
                                                </svg>
                                            </div>
                                        </a>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="spacer-24"></div>
                <div class="platform-slider-arrows splide__arrows">
                    <a href="#" class="platform-testimonial-arrow w-inline-block">
                        <div class="embed w-embed">
                            <svg width="24" height="25" viewBox="0 0 24 25" fill="none" xmlns="http://www.w3.org/2000/svg">
                                <path d="M19 12.0537H5M5 12.0537L12 19.0537M5 12.0537L12 5.05371" stroke="white" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" />
                            </svg>
                        </div>
                    </a>
                    <a href="#" class="platform-testimonial-arrow w-inline-block">
                        <div class="embed w-embed">
                            <svg width="24" height="25" viewBox="0 0 24 25" fill="none" xmlns="http://www.w3.org/2000/svg">
                                <path d="M5 12.0537H19M19 12.0537L12 5.05371M19 12.0537L12 19.0537" stroke="white" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" />
                            </svg>
                        </div>
                    </a>
                </div>
            </div>
        </div>
    </div>
</div>

<div class="section_platform-insights">
    <div class="padding-global">
        <div class="container-1600">
            <div class="platform-insight-component">
                <div class="max-width-918">
                    <div class="margin-bottom-48">
                        <div class="header-section">
                            <div class="header-tag bg-color-gray-700">
                                <div>Industry leading</div>
                            </div>
                            <h2>Market insights and training from the industry-leading agency</h2>
                            <div class="text-size-20 text-color-gray-300 set-text-size-18">
                                Improve your business performance with a range of guides, training and insights from leading marketing experts, consolidated through a single platform.
                            </div>
                        </div>
                    </div>
                    <div class="margin-bottom-48 show-mobile-landscape">
                        <img src="https://cdn.prod.website-files.com/668b3733f80ed0dcd2c46207/672dd00eac40632d7cfb4b86_aducation-illustration.svg" loading="lazy" alt="Market insights and training from the industry-leading agency" />
                    </div>
                    <div class="platform-insight-list">
                        <div class="flex-full">
                            <div class="platform-insight-box">
                                <div class="embed w-embed">
                                    <svg width="48" height="49" viewBox="0 0 48 49" fill="none" xmlns="http://www.w3.org/2000/svg">
                                        <path
                                            d="M37.5713 12.2841C37.4439 12.1801 37.291 12.1132 37.1291 12.0907C36.9671 12.0682 36.8022 12.0908 36.652 12.1563L22.0222 18.5979C21.3861 18.8797 20.5895 19.0137 19.7717 19.0137C18.6313 19.0183 17.4515 18.7488 16.6292 18.3823C16.3786 18.275 16.14 18.1407 15.9174 17.9819C15.978 17.9511 16.0537 17.9172 16.137 17.8834L29.4431 12.0254L31.4271 12.8878V10.3669C31.4301 10.1871 31.3931 10.009 31.3189 9.8458C31.2447 9.6826 31.1351 9.53857 30.9985 9.42445C30.8716 9.3205 30.7193 9.25367 30.5578 9.23115C30.3964 9.20863 30.232 9.23127 30.0822 9.29664L15.4524 15.7382C15.0011 15.923 14.6134 16.1509 14.2863 16.482C13.9075 16.862 13.6924 17.3793 13.6881 17.9203C13.6881 17.9357 13.6926 17.9619 13.6926 17.9619V40.6453L13.6896 40.6761C13.6896 40.6822 13.6941 40.6853 13.6941 40.6915V40.7161H13.6972C13.7275 41.5092 14.1212 42.0143 14.4968 42.3715C15.6781 43.431 17.6621 44.0239 19.7732 44.0547C20.7728 44.0547 21.7875 43.9007 22.7264 43.4911L37.3608 37.0479C37.747 36.8786 37.9999 36.4581 37.9999 35.9823V13.2266C38.0022 13.0469 37.9649 12.869 37.8908 12.7059C37.8166 12.5428 37.7074 12.3987 37.5713 12.2841ZM28.2921 7.97229C28.2664 7.6335 28.1286 7.31011 27.8832 7.11608C27.7558 7.01201 27.6029 6.94513 27.441 6.92262C27.2791 6.9001 27.1142 6.9228 26.9639 6.98826L12.3341 13.4268C11.6981 13.707 10.8999 13.8425 10.0836 13.8425C8.94324 13.8456 7.76346 13.5761 6.9411 13.2081C6.69025 13.1026 6.45155 12.9693 6.2293 12.8108C6.28988 12.78 6.36561 12.7461 6.4489 12.7122L19.7566 6.85429L21.7405 7.71666V5.19885C21.7432 5.01897 21.7059 4.8408 21.6315 4.67761C21.557 4.51443 21.4473 4.37044 21.3104 4.25641C21.1832 4.15247 21.0306 4.08566 20.869 4.06315C20.7073 4.04063 20.5426 4.06326 20.3926 4.12859L5.76285 10.5717C5.31153 10.7565 4.92534 10.9829 4.5967 11.3155C4.21845 11.6958 4.00387 12.213 4 12.7538C4 12.7723 4.00454 12.7969 4.00454 12.7969V35.5527H4.00757C4.03786 36.3457 4.43162 36.8508 4.80721 37.2081C5.9885 38.2676 7.97246 38.8589 10.0851 38.8897C10.6589 38.8863 11.2308 38.8233 11.792 38.7018V17.9604C11.7768 16.8824 12.2009 15.8476 12.946 15.1022C13.4622 14.5931 14.0756 14.1968 14.7482 13.938L28.2921 7.97229Z"
                                            fill="#E9394B"
                                        />
                                        <g style="mix-blend-mode: plus-lighter;" opacity="0.5">
                                            <path
                                                d="M40.6666 37.3047C39.9775 37.3057 39.3056 37.5224 38.743 37.9252C38.1804 38.3281 37.7546 38.8972 37.524 39.5547H28.8148C28.1272 39.5547 27.4678 39.2781 26.9816 38.7858C26.4954 38.2936 26.2222 37.6259 26.2222 36.9297C26.2222 36.2335 26.4954 35.5658 26.9816 35.0735C27.4678 34.5812 28.1272 34.3047 28.8148 34.3047H37.7036C38.7841 34.3047 39.8204 33.8701 40.5844 33.0965C41.3485 32.3229 41.7777 31.2737 41.7777 30.1797C41.7777 29.0857 41.3485 28.0365 40.5844 27.2629C39.8204 26.4893 38.7841 26.0547 37.7036 26.0547H28.8148C28.5201 26.0547 28.2375 26.1732 28.0291 26.3842C27.8207 26.5952 27.7037 26.8813 27.7037 27.1797C27.7037 27.4781 27.8207 27.7642 28.0291 27.9752C28.2375 28.1862 28.5201 28.3047 28.8148 28.3047H37.7036C38.1948 28.3047 38.6658 28.5022 39.0131 28.8539C39.3604 29.2055 39.5555 29.6824 39.5555 30.1797C39.5555 30.677 39.3604 31.1539 39.0131 31.5055C38.6658 31.8571 38.1948 32.0547 37.7036 32.0547H28.8148C27.5378 32.0547 26.3132 32.5683 25.4102 33.4825C24.5073 34.3968 24 35.6368 24 36.9297C24 38.2226 24.5073 39.4626 25.4102 40.3768C26.3132 41.2911 27.5378 41.8047 28.8148 41.8047H37.524C37.7277 42.3881 38.0859 42.9035 38.5594 43.2947C39.0329 43.6858 39.6034 43.9377 40.2088 44.0227C40.8141 44.1077 41.4308 44.0226 41.9916 43.7766C42.5523 43.5307 43.0355 43.1334 43.3884 42.6282C43.7412 42.123 43.95 41.5293 43.9921 40.912C44.0342 40.2947 43.9078 39.6776 43.6269 39.1281C43.3459 38.5786 42.9212 38.1179 42.3991 37.7963C41.877 37.4747 41.2777 37.3047 40.6666 37.3047ZM40.6666 41.8047C40.4468 41.8047 40.232 41.7387 40.0493 41.6151C39.8666 41.4915 39.7241 41.3158 39.6401 41.1102C39.556 40.9046 39.534 40.6784 39.5768 40.4602C39.6197 40.242 39.7255 40.0415 39.8809 39.8842C40.0363 39.7269 40.2343 39.6197 40.4498 39.5763C40.6653 39.5329 40.8888 39.5552 41.0918 39.6403C41.2948 39.7255 41.4683 39.8697 41.5904 40.0547C41.7125 40.2397 41.7777 40.4572 41.7777 40.6797C41.7777 40.9781 41.6606 41.2642 41.4522 41.4752C41.2439 41.6862 40.9613 41.8047 40.6666 41.8047Z"
                                                fill="white"
                                            />
                                        </g>
                                    </svg>
                                </div>
                                <div>
                                    <div class="margin-bottom-8">
                                        <div class="heading-18">Comprehensive guides and training</div>
                                    </div>
                                    <div>Enhance your spending and performance with new strategies and systems.</div>
                                </div>
                            </div>
                        </div>
                        <div class="flex-full">
                            <div class="platform-insight-box">
                                <div class="embed w-embed">
                                    <svg width="48" height="49" viewBox="0 0 48 49" fill="none" xmlns="http://www.w3.org/2000/svg">
                                        <g clip-path="url(#clip0_60_8053)">
                                            <path d="M37.1035 15.0355L40.9749 11.1641" stroke="#E9394B" stroke-linecap="round" />
                                            <path d="M10.6956 15.0355L6.82422 11.1641" stroke="#E9394B" stroke-linecap="round" />
                                            <path d="M23.8994 9.47498V4" stroke="#E9394B" stroke-linecap="round" />
                                            <path d="M40.3242 26.0176H45.7992" stroke="#E9394B" stroke-linecap="round" />
                                            <path d="M7.47498 26.0176H2" stroke="#E9394B" stroke-linecap="round" />
                                            <path
                                                fill-rule="evenodd"
                                                clip-rule="evenodd"
                                                d="M37.9174 26.0148C37.9174 31.8326 34.3441 36.8158 29.2725 38.8895V40.2246C29.2725 41.3291 28.3771 42.2246 27.2725 42.2246H26.5357V42.5927C26.5357 43.145 26.088 43.5927 25.5357 43.5927H22.0607C21.5084 43.5927 21.0607 43.145 21.0607 42.5927V42.2246H20.3226C19.218 42.2246 18.3226 41.3291 18.3226 40.2246V38.7039C13.4816 36.5293 10.1104 31.6658 10.1104 26.0148C10.1104 18.3361 16.3352 12.1113 24.0139 12.1113C31.6926 12.1113 37.9174 18.3361 37.9174 26.0148Z"
                                                fill="#E9394B"
                                            />
                                            <g style="mix-blend-mode: plus-lighter;" opacity="0.5">
                                                <path
                                                    fill-rule="evenodd"
                                                    clip-rule="evenodd"
                                                    d="M32.2227 34.5182C27.6873 38.8953 20.4621 38.8463 15.987 34.3711C11.4622 29.8464 11.4622 22.5104 15.987 17.9857C20.5117 13.461 27.8477 13.461 32.3724 17.9857C36.4666 22.0799 36.8562 28.4759 33.541 33.0082L38.8786 38.3457C39.2691 38.7362 39.2691 39.3694 38.8786 39.7599C38.488 40.1504 37.8549 40.1504 37.4644 39.7599L32.2227 34.5182Z"
                                                    fill="white"
                                                />
                                            </g>
                                            <path
                                                d="M17.3623 29.3625L20.2489 26.4759C20.6394 26.0854 21.2726 26.0854 21.6631 26.476L23.8425 28.6554C24.233 29.0459 24.8662 29.0459 25.2567 28.6554L30.8222 23.0898"
                                                stroke="#E9394B"
                                                stroke-width="2"
                                                stroke-linecap="round"
                                            />
                                        </g>
                                        <defs>
                                            <clipPath id="clip0_60_8053">
                                                <rect width="48" height="48" fill="white" transform="translate(0 0.0546875)" />
                                            </clipPath>
                                        </defs>
                                    </svg>
                                </div>
                                <div>
                                    <div class="margin-bottom-8">
                                        <div class="heading-18">Advanced market insights</div>
                                    </div>
                                    <div>Unlock exclusive market insights and scale your campaigns with our expert assistance.</div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="spacer-49"></div>
                </div>
                <div class="max-width-510 hide-mobile-landscape">
                    <img
                        src="https://cdn.prod.website-files.com/668b3733f80ed0dcd2c46207/66c3efab9b6e6c28cf7caf38_agency-illustration.png"
                        loading="lazy"
                        sizes="(max-width: 510px) 100vw, 510px"
                        srcset="
                            https://cdn.prod.website-files.com/668b3733f80ed0dcd2c46207/66c3efab9b6e6c28cf7caf38_agency-illustration-p-500.png 500w,
                            https://cdn.prod.website-files.com/668b3733f80ed0dcd2c46207/66c3efab9b6e6c28cf7caf38_agency-illustration.png       510w
                        "
                        alt="Market insights and training from the industry-leading agency"
                    />
                </div>
            </div>
        </div>
    </div>
</div>
<div class="section_faq">
    <div class="padding-global">
        <div class="container-1600">
            <div class="margin-bottom-48">
                <div class="header-section">
                    <h2>Frequently asked questions</h2>
                    <div class="text-size-20 text-color-gray-300 set-text-size-18">
                        Answer all of your questions to our suite of services. If you are unable to find the answers you are looking for, you can contact our sales team with the button below.
                    </div>
                </div>
            </div>
            <div data-current="Tab 1" data-easing="ease" data-duration-in="300" data-duration-out="100" class="faq-component w-tabs">
                <div class="faq-tabs max-width-516 flex-first w-tab-menu">
                    <a data-w-tab="Tab 1" class="faq-tab w-inline-block w-tab-link w--current">
                        <div>Account Information</div>
                    </a>
                    <a data-w-tab="Tab 2" class="faq-tab w-inline-block w-tab-link">
                        <div>Payment Information</div>
                    </a>
                    <a data-w-tab="Tab 3" class="faq-tab w-inline-block w-tab-link">
                        <div>Getting Started</div>
                    </a>
                </div>
                <div class="max-width-919 flex-last w-tab-content">
                    <div data-w-tab="Tab 1" class="w-tab-pane w--tab-active">
                        <div class="faq-answers-block">
                            <div class="text-size-18 text-weight-bold text-color-gray-400">Account Information</div>
                            <div class="faq-answers-list hide-this">
                                <div class="faq-collection-list-item">
                                    <div class="faq-title">
                                        <div class="faq-title-header">How many ad accounts can I have from AdsAsia?</div>
                                        <div class="faq-icon">
                                            <div class="embed w-embed">
                                                <svg width="24" height="27" viewBox="0 0 24 27" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                    <path d="M12 7.05469V21.0547M5 14.0547H19" stroke="white" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" />
                                                </svg>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="faq-description">
                                        <div class="faq-answer-text w-richtext">
                                            <p>
                                                We understand that as a marketer, you should never be limited by the number of ad accounts you have. That's why we offer unlimited agency ad accounts with all of our subscription plans. We just ask that you utilize the accounts we share to you.
                                            </p>
                                        </div>
                                    </div>
                                </div>
                                <div class="faq-collection-list-item">
                                    <div class="faq-title">
                                        <div class="faq-title-header">Are there limitations on what I can run on AdsAsia's ad accounts?</div>
                                        <div class="faq-icon">
                                            <div class="embed w-embed">
                                                <svg width="24" height="27" viewBox="0 0 24 27" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                    <path d="M12 7.05469V21.0547M5 14.0547H19" stroke="white" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" />
                                                </svg>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="faq-description">
                                        <div class="faq-answer-text w-richtext">
                                            <p>
                                                Generally speaking, no. We will try to accommodate all businesses, all verticals and all levels of risk. However, the final decision on what can and can&#x27;t be approved is at the discretion of the advertising platform.
                                            </p>
                                        </div>
                                    </div>
                                </div>
                                <div class="faq-collection-list-item">
                                    <div class="faq-title">
                                        <div class="faq-title-header">Are there minimum spending requirements?</div>
                                        <div class="faq-icon">
                                            <div class="embed w-embed">
                                                <svg width="24" height="27" viewBox="0 0 24 27" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                    <path d="M12 7.05469V21.0547M5 14.0547H19" stroke="white" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" />
                                                </svg>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="faq-description">
                                        <div class="faq-answer-text w-richtext">
                                            <p>No, we are very proud to support all business sizes from startups to multinationals.</p>
                                        </div>
                                    </div>
                                </div>
                                <div class="faq-collection-list-item">
                                    <div class="faq-title">
                                        <div class="faq-title-header">Can I resell or white-label ad accounts from AdsAsia?</div>
                                        <div class="faq-icon">
                                            <div class="embed w-embed">
                                                <svg width="24" height="27" viewBox="0 0 24 27" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                    <path d="M12 7.05469V21.0547M5 14.0547H19" stroke="white" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" />
                                                </svg>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="faq-description">
                                        <div class="faq-answer-text w-richtext">
                                            <p>
                                                Yes, we support the white-labelling of our accounts and services. We can hide references to AdsAsia on most platforms and add your company name on request. Speak to our sales team to learn more.
                                            </p>
                                        </div>
                                    </div>
                                </div>
                                <div class="faq-collection-list-item">
                                    <div class="faq-title">
                                        <div class="faq-title-header">Can whitelisted agency ad accounts be banned or restricted?</div>
                                        <div class="faq-icon">
                                            <div class="embed w-embed">
                                                <svg width="24" height="27" viewBox="0 0 24 27" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                    <path d="M12 7.05469V21.0547M5 14.0547H19" stroke="white" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" />
                                                </svg>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="faq-description">
                                        <div class="faq-answer-text w-richtext">
                                            <p>
                                                Yes, they can. Although all of the ad accounts that we provide are distributed from highly trusted, official resellers of platforms, this doesn't exempt them from being banned if advertising policies are breached. However, we can provide compliance support and guidance to get your ads approved.
                                            </p>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="w-dyn-list">
                                <div role="list" class="faq-answers-list w-dyn-items">
                                    <div role="listitem" class="w-dyn-item">
                                        <div class="faq-collection-list-item">
                                            <div class="faq-title">
                                                <div class="faq-title-header">How many ad accounts can I have from AdsAsia?</div>
                                                <div class="faq-icon">
                                                    <div class="embed w-embed">
                                                        <svg width="24" height="27" viewBox="0 0 24 27" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                            <path d="M12 7.05469V21.0547M5 14.0547H19" stroke="white" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" />
                                                        </svg>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="faq-description">
                                                <div class="faq-answer-text w-richtext">
                                                    <p>
                                                        We understand that as a marketer, you should never be limited by the number of ad accounts you have. That's why we offer unlimited agency ad accounts with all of our subscription plans. We just ask that you utilize the accounts we share to you.
                                                    </p>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div role="listitem" class="w-dyn-item">
                                        <div class="faq-collection-list-item">
                                            <div class="faq-title">
                                                <div class="faq-title-header">Are there limitations on what I can run on AdsAsia's ad accounts?</div>
                                                <div class="faq-icon">
                                                    <div class="embed w-embed">
                                                        <svg width="24" height="27" viewBox="0 0 24 27" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                            <path d="M12 7.05469V21.0547M5 14.0547H19" stroke="white" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" />
                                                        </svg>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="faq-description">
                                                <div class="faq-answer-text w-richtext">
                                                    <p>
                                                        Generally speaking, no. We will try to accommodate all businesses, all verticals and all levels of risk. However, the final decision on what can and can't be approved is at the discretion of the advertising platform.
                                                    </p>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div role="listitem" class="w-dyn-item">
                                        <div class="faq-collection-list-item">
                                            <div class="faq-title">
                                                <div class="faq-title-header">Are there minimum spending requirements?</div>
                                                <div class="faq-icon">
                                                    <div class="embed w-embed">
                                                        <svg width="24" height="27" viewBox="0 0 24 27" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                            <path d="M12 7.05469V21.0547M5 14.0547H19" stroke="white" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" />
                                                        </svg>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="faq-description">
                                                <div class="faq-answer-text w-richtext">
                                                    <p>No, we are very proud to support all business sizes from startups to multinationals.</p>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div role="listitem" class="w-dyn-item">
                                        <div class="faq-collection-list-item">
                                            <div class="faq-title">
                                                <div class="faq-title-header">Can I resell or white-label ad accounts from AdsAsia?</div>
                                                <div class="faq-icon">
                                                    <div class="embed w-embed">
                                                        <svg width="24" height="27" viewBox="0 0 24 27" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                            <path d="M12 7.05469V21.0547M5 14.0547H19" stroke="white" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" />
                                                        </svg>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="faq-description">
                                                <div class="faq-answer-text w-richtext">
                                                    <p>
                                                        Yes, we support the white-labelling of our accounts and services. We can hide references to AdsAsia on most platforms and add your company name on request. Speak to our sales team to learn more.
                                                    </p>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div role="listitem" class="w-dyn-item">
                                        <div class="faq-collection-list-item">
                                            <div class="faq-title">
                                                <div class="faq-title-header">Can whitelisted agency ad accounts be banned or restricted?</div>
                                                <div class="faq-icon">
                                                    <div class="embed w-embed">
                                                        <svg width="24" height="27" viewBox="0 0 24 27" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                            <path d="M12 7.05469V21.0547M5 14.0547H19" stroke="white" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" />
                                                        </svg>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="faq-description">
                                                <div class="faq-answer-text w-richtext">
                                                    <p>
                                                Yes, they can. Although all of the ad accounts that we provide are distributed from highly trusted, official resellers of platforms, this doesn't exempt them from being banned if advertising policies are breached. However, we can provide compliance support and guidance to get your ads approved.
                                            </p>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div role="listitem" class="w-dyn-item">
                                        <div class="faq-collection-list-item">
                                            <div class="faq-title">
                                                <div class="faq-title-header">What happens if an ad account is banned or restricted?</div>
                                                <div class="faq-icon">
                                                    <div class="embed w-embed">
                                                        <svg width="24" height="27" viewBox="0 0 24 27" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                            <path d="M12 7.05469V21.0547M5 14.0547H19" stroke="white" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" />
                                                        </svg>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="faq-description">
                                                <div class="faq-answer-text w-richtext">
                                                    <p>
                                                        If your account faces an issue, we will always appeal the restriction first. In most cases, this is enough to restore the account. However, if the account is not reinstated, we will issue you a replacement account and move your funds there.
                                                    </p>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div role="listitem" class="w-dyn-item">
                                        <div class="faq-collection-list-item">
                                            <div class="faq-title">
                                                <div class="faq-title-header">How much support will I receive?</div>
                                                <div class="faq-icon">
                                                    <div class="embed w-embed">
                                                        <svg width="24" height="27" viewBox="0 0 24 27" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                            <path d="M12 7.05469V21.0547M5 14.0547H19" stroke="white" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" />
                                                        </svg>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="faq-description">
                                                <div class="faq-answer-text w-richtext">
                                                    <p>
                                                        Once you sign up for one of our services, you will be issued with a dedicated account manager. This person will become your point of contact for all of your advertising requirements and will be reachable 7 days a week via the live chat button inside the Vantage dashboard.
                                                    </p>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div data-w-tab="Tab 2" class="w-tab-pane">
                        <div class="faq-answers-block">
                            <div class="text-size-18 text-weight-bold text-color-gray-400">Payment Information</div>
                            <div class="faq-answers-list hide-this">
                                <div class="faq-collection-list-item">
                                    <div class="faq-title">
                                        <div class="faq-title-header">How many ad accounts can I have from AdsAsia?</div>
                                        <div class="faq-icon">
                                            <div class="embed w-embed">
                                                <svg width="24" height="27" viewBox="0 0 24 27" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                    <path d="M12 7.05469V21.0547M5 14.0547H19" stroke="white" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" />
                                                </svg>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="faq-description">
                                        <div class="faq-answer-text w-richtext">
                                            <p>
                                                We understand that as a marketer, you should never be limited by the number of ad accounts you have. That&#x27;s why we offer unlimited agency ad accounts with all of our subscription plans.
                                                We just ask that you utilize the accounts we share to you.
                                            </p>
                                        </div>
                                    </div>
                                </div>
                                <div class="faq-collection-list-item">
                                    <div class="faq-title">
                                        <div class="faq-title-header">Are there limitations on what I can run on AdsAsia&#x27;s ad accounts?</div>
                                        <div class="faq-icon">
                                            <div class="embed w-embed">
                                                <svg width="24" height="27" viewBox="0 0 24 27" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                    <path d="M12 7.05469V21.0547M5 14.0547H19" stroke="white" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" />
                                                </svg>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="faq-description">
                                        <div class="faq-answer-text w-richtext">
                                            <p>
                                                Generally speaking, no. We will try to accommodate all businesses, all verticals and all levels of risk. However, the final decision on what can and can&#x27;t be approved is at the discretion
                                                of the advertising platform.
                                            </p>
                                        </div>
                                    </div>
                                </div>
                                <div class="faq-collection-list-item">
                                    <div class="faq-title">
                                        <div class="faq-title-header">Are there minimum spending requirements?</div>
                                        <div class="faq-icon">
                                            <div class="embed w-embed">
                                                <svg width="24" height="27" viewBox="0 0 24 27" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                    <path d="M12 7.05469V21.0547M5 14.0547H19" stroke="white" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" />
                                                </svg>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="faq-description">
                                        <div class="faq-answer-text w-richtext">
                                            <p>No, we are very proud to support all business sizes from startups to multinationals.</p>
                                        </div>
                                    </div>
                                </div>
                                <div class="faq-collection-list-item">
                                    <div class="faq-title">
                                        <div class="faq-title-header">Can I resell or white-label ad accounts from AdsAsia?</div>
                                        <div class="faq-icon">
                                            <div class="embed w-embed">
                                                <svg width="24" height="27" viewBox="0 0 24 27" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                    <path d="M12 7.05469V21.0547M5 14.0547H19" stroke="white" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" />
                                                </svg>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="faq-description">
                                        <div class="faq-answer-text w-richtext">
                                            <p>
                                                Yes, we support the white-labelling of our accounts and services. We can hide references to AdsAsia on most platforms and add your company name on request. Speak to our sales team to learn
                                                more.
                                            </p>
                                        </div>
                                    </div>
                                </div>
                                <div class="faq-collection-list-item">
                                    <div class="faq-title">
                                        <div class="faq-title-header">Can whitelisted agency ad accounts be banned or restricted?</div>
                                        <div class="faq-icon">
                                            <div class="embed w-embed">
                                                <svg width="24" height="27" viewBox="0 0 24 27" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                    <path d="M12 7.05469V21.0547M5 14.0547H19" stroke="white" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" />
                                                </svg>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="faq-description">
                                        <div class="faq-answer-text w-richtext">
                                            <p>
                                                Yes, they can. Although all of the ad accounts that we provide are distributed from highly trusted, official resellers of platforms, this doesn't exempt them from being banned if advertising policies are breached. However, we can provide compliance support and guidance to get your ads approved.
                                            </p>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="w-dyn-list">
                                <div role="list" class="faq-answers-list w-dyn-items">
                                    <div role="listitem" class="w-dyn-item">
                                        <div class="faq-collection-list-item">
                                            <div class="faq-title">
                                                <div class="faq-title-header">What payment methods do you accept?</div>
                                                <div class="faq-icon">
                                                    <div class="embed w-embed">
                                                        <svg width="24" height="27" viewBox="0 0 24 27" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                            <path d="M12 7.05469V21.0547M5 14.0547H19" stroke="white" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" />
                                                        </svg>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="faq-description">
                                                <div class="faq-answer-text w-richtext">
                                                    <p>We accept all major payment methods, including bank and wire transfers, credit and debit card, cryptocurrencies and Payoneer.</p>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div role="listitem" class="w-dyn-item">
                                        <div class="faq-collection-list-item">
                                            <div class="faq-title">
                                                <div class="faq-title-header">How does cashback work?</div>
                                                <div class="faq-icon">
                                                    <div class="embed w-embed">
                                                        <svg width="24" height="27" viewBox="0 0 24 27" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                            <path d="M12 7.05469V21.0547M5 14.0547H19" stroke="white" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" />
                                                        </svg>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="faq-description">
                                                <div class="faq-answer-text w-richtext">
                                                    <p>
                                                        Some of our supported platforms can provide direct cashback on advertising spend. A certain percentage of your spending will be paid back depending on how much you have spent in a quarter.
                                                    </p>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div role="listitem" class="w-dyn-item">
                                        <div class="faq-collection-list-item">
                                            <div class="faq-title">
                                                <div class="faq-title-header">Are there fees for top-ups or transfers?</div>
                                                <div class="faq-icon">
                                                    <div class="embed w-embed">
                                                        <svg width="24" height="27" viewBox="0 0 24 27" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                            <path d="M12 7.05469V21.0547M5 14.0547H19" stroke="white" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" />
                                                        </svg>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="faq-description">
                                                <div class="faq-answer-text w-richtext">
                                                    <p>Most payment methods do not have a fee associated. However, if there is a cost associated with receiving the payment, for example, card payments, this fee may be passed on to you.</p>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div data-w-tab="Tab 3" class="w-tab-pane">
                        <div class="faq-answers-block">
                            <div class="text-size-18 text-weight-bold text-color-gray-400">Getting Started</div>
                            <div class="faq-answers-list hide-this">
                                <div class="faq-collection-list-item">
                                    <div class="faq-title">
                                        <div class="faq-title-header">How many ad accounts can I have from AdsAsia?</div>
                                        <div class="faq-icon">
                                            <div class="embed w-embed">
                                                <svg width="24" height="27" viewBox="0 0 24 27" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                    <path d="M12 7.05469V21.0547M5 14.0547H19" stroke="white" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" />
                                                </svg>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="faq-description">
                                        <div class="faq-answer-text w-richtext">
                                            <p>
                                                We understand that as a marketer, you should never be limited by the number of ad accounts you have. That&#x27;s why we offer unlimited agency ad accounts with all of our subscription plans.
                                                We just ask that you utilize the accounts we share to you.
                                            </p>
                                        </div>
                                    </div>
                                </div>
                                <div class="faq-collection-list-item">
                                    <div class="faq-title">
                                        <div class="faq-title-header">Are there limitations on what I can run on AdsAsia&#x27;s ad accounts?</div>
                                        <div class="faq-icon">
                                            <div class="embed w-embed">
                                                <svg width="24" height="27" viewBox="0 0 24 27" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                    <path d="M12 7.05469V21.0547M5 14.0547H19" stroke="white" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" />
                                                </svg>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="faq-description">
                                        <div class="faq-answer-text w-richtext">
                                            <p>
                                                Generally speaking, no. We will try to accommodate all businesses, all verticals and all levels of risk. However, the final decision on what can and can&#x27;t be approved is at the discretion of the advertising platform.
                                            </p>
                                        </div>
                                    </div>
                                </div>
                                <div class="faq-collection-list-item">
                                    <div class="faq-title">
                                        <div class="faq-title-header">Are there minimum spending requirements?</div>
                                        <div class="faq-icon">
                                            <div class="embed w-embed">
                                                <svg width="24" height="27" viewBox="0 0 24 27" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                    <path d="M12 7.05469V21.0547M5 14.0547H19" stroke="white" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" />
                                                </svg>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="faq-description">
                                        <div class="faq-answer-text w-richtext">
                                            <p>No, we are very proud to support all business sizes from startups to multinationals.</p>
                                        </div>
                                    </div>
                                </div>
                                <div class="faq-collection-list-item">
                                    <div class="faq-title">
                                        <div class="faq-title-header">Can I resell or white-label ad accounts from AdsAsia?</div>
                                        <div class="faq-icon">
                                            <div class="embed w-embed">
                                                <svg width="24" height="27" viewBox="0 0 24 27" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                    <path d="M12 7.05469V21.0547M5 14.0547H19" stroke="white" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" />
                                                </svg>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="faq-description">
                                        <div class="faq-answer-text w-richtext">
                                            <p>
                                                Yes, we support the white-labelling of our accounts and services. We can hide references to AdsAsia on most platforms and add your company name on request. Speak to our sales team to learn
                                                more.
                                            </p>
                                        </div>
                                    </div>
                                </div>
                                <div class="faq-collection-list-item">
                                    <div class="faq-title">
                                        <div class="faq-title-header">Can whitelisted agency ad accounts be banned or restricted?</div>
                                        <div class="faq-icon">
                                            <div class="embed w-embed">
                                                <svg width="24" height="27" viewBox="0 0 24 27" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                    <path d="M12 7.05469V21.0547M5 14.0547H19" stroke="white" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" />
                                                </svg>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="faq-description">
                                        <div class="faq-answer-text w-richtext">
                                           <p>
                                                Yes, they can. Although all of the ad accounts that we provide are distributed from highly trusted, official resellers of platforms, this doesn't exempt them from being banned if advertising policies are breached. However, we can provide compliance support and guidance to get your ads approved.
                                            </p>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="w-dyn-list">
                                <div role="list" class="faq-answers-list w-dyn-items">
                                    <div role="listitem" class="w-dyn-item">
                                        <div class="faq-collection-list-item">
                                            <div class="faq-title">
                                                <div class="faq-title-header">Why should I work with AdsAsia?</div>
                                                <div class="faq-icon">
                                                    <div class="embed w-embed">
                                                        <svg width="24" height="27" viewBox="0 0 24 27" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                            <path d="M12 7.05469V21.0547M5 14.0547H19" stroke="white" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" />
                                                        </svg>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="faq-description">
                                                <div class="faq-answer-text w-richtext">
                                                    <p>
                                                        We are the industry-leading advertising solutions provider, accepting clients from small businesses to multinational companies. Our experience and range of support options for our clients are completely unmatched. With localized support and integrated advertising solutions, we help our clients scale long-term.
                                                    </p>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div role="listitem" class="w-dyn-item">
                                        <div class="faq-collection-list-item">
                                            <div class="faq-title">
                                                <div class="faq-title-header">How long does it take to get started?</div>
                                                <div class="faq-icon">
                                                    <div class="embed w-embed">
                                                        <svg width="24" height="27" viewBox="0 0 24 27" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                            <path d="M12 7.05469V21.0547M5 14.0547H19" stroke="white" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" />
                                                        </svg>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="faq-description">
                                                <div class="faq-answer-text w-richtext">
                                                    <p>
                                                        You can sign up immediately using Vantage, the self-service dashboard we created. Once you request your initial advertising accounts through there, we aim to get them created and shared with you as soon as possible.
                                                    </p>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div role="listitem" class="w-dyn-item">
                                        <div class="faq-collection-list-item">
                                            <div class="faq-title">
                                                <div class="faq-title-header">What if I have further questions?</div>
                                                <div class="faq-icon">
                                                    <div class="embed w-embed">
                                                        <svg width="24" height="27" viewBox="0 0 24 27" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                            <path d="M12 7.05469V21.0547M5 14.0547H19" stroke="white" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" />
                                                        </svg>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="faq-description">
                                                <div class="faq-answer-text w-richtext">
                                                    <p>
                                                        Ask any questions you have at any time by simply speaking with our team by clicking the live chat button on this page. They are available 24/7 to assist you with any questions you have.
                                                    </p>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<div class="section_before-footer">
    <div class="watermark-image-box"><img src="https://cdn.prod.website-files.com/668b3733f80ed0dcd2c46207/668e1d5b327f4d97705634e9_Watermark.svg" loading="lazy" alt="" class="full-image" /></div>
    <div class="position-relative z-2">
        <div class="padding-global">
            <div class="container-1600">
                <div class="margin-bottom-48 set-margin-bottom-32">
                    <div class="header-section" id="contact">
                        <h2 class="heading-64 text-color-gray-200">Ready to scale your digital advertising?</h2>
                        <div class="text-size-20 text-color-gray-200 text-weight-medium set-text-color-gray-300">
                            Chat with our team to find the solution that you need, or sign up and onboard your company within minutes.
                        </div>
                    </div>
                </div>
                <div class="button-wrapper">
                    <div class="button-flex-block">
                        <a style="background-color: rgb(44 51 66); border: none;" href="<?php echo $config['telegram1'] ?>" target="_blank" class="primary-button w-button">
                            Telegram Channel

                            <img style="width: 30px; padding-left: 6px;" src="https://cdn-icons-png.flaticon.com/512/2111/2111646.png" />
                        </a>

                        <a style="background-color: rgb(44 51 66); border: none;" href="<?php echo $config['telegram2'] ?>" target="_blank" class="primary-button w-button">
                            Telegram Contact

                            <img style="width: 30px; padding-left: 6px;" src="https://cdn-icons-png.flaticon.com/512/2111/2111646.png" />
                        </a>

                        <a style="background-color: rgb(44 51 66); border: none;" href="<?php echo $config['instagram'] ?>" target="_blank" class="primary-button w-button">
                            Instagram

                            <img style="width: 30px; padding-left: 6px;" src="https://cdn-icons-png.flaticon.com/512/174/174855.png" />
                        </a>

                        <a style="background-color: rgb(44 51 66); border: none;" href="<?php echo $config['whatsapp'] ?>" target="_blank" class="primary-button w-button">
                            Whatsapp

                            <img style="width: 30px; padding-left: 6px;" src="https://cdn-icons-png.flaticon.com/512/733/733585.png" />
                        </a>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="gradient-box">
        <div class="w-embed">
            <style>
                .gradient-box {
                    background: linear-gradient(270deg, #c728d5, #42f4f4, #c728d5, #42f4f4);
                    background-size: 800% 800%;

                    -webkit-animation: bottomgradient 11s ease infinite;
                    -moz-animation: bottomgradient 11s ease infinite;
                    -o-animation: bottomgradient 11s ease infinite;
                    animation: bottomgradient 11s ease infinite;
                }

                @-webkit-keyframes bottomgradient {
                    0% {
                        background-position: 0% 50%;
                    }

                    50% {
                        background-position: 100% 50%;
                    }

                    100% {
                        background-position: 0% 50%;
                    }
                }

                @-moz-keyframes bottomgradient {
                    0% {
                        background-position: 0% 50%;
                    }

                    50% {
                        background-position: 100% 50%;
                    }

                    100% {
                        background-position: 0% 50%;
                    }
                }

                @-o-keyframes bottomgradient {
                    0% {
                        background-position: 0% 50%;
                    }

                    50% {
                        background-position: 100% 50%;
                    }

                    100% {
                        background-position: 0% 50%;
                    }
                }

                @keyframes bottomgradient {
                    0% {
                        background-position: 0% 50%;
                    }

                    50% {
                        background-position: 100% 50%;
                    }

                    100% {
                        background-position: 0% 50%;
                    }
                }
            </style>
        </div>
    </div>
</div>




            <div id="footer" class="footer">
    <div class="padding-global">
        <div class="container-1600">
            <div class="margin-bottom-64 set-margin-bottom-48">
                <div class="footer-component">
                    <div class="footer-main-box"><a href="/" aria-current="page" class="w-inline-block w--current">
                            <div class="footer-logo w-embed">
                                <img src="assets/logo.png" width="142" alt="Logo" class="logo-image">

                            </div>
                        </a>


                    </div>
                    <div class="footer-links-block">
                        <div class="footer-links-box hide-this">
                            <div class="margin-bottom-16">
                                <div>Home</div>
                            </div>
                            <div class="footer-links"><a href="#" class="footer-link">Overview</a><a
                                    href="/solutions/features" class="footer-link">Features</a><a
                                    href="/solutions/use-cases" class="footer-link">Solutions</a><a href="#"
                                    class="footer-link">Demo</a><a href="/pricing" class="footer-link">Pricing</a></div>
                        </div>

                        <div class="footer-links-box">
                            <div class="margin-bottom-16">
                                <div>Products</div>
                            </div>
                            <div class="footer-links">
                                <a href="/meta.php" class="footer-link">Meta</a>
                                <a href="/tiktok.php" class="footer-link">TikTok</a>
                                <a href="/google.php" class="footer-link">Google</a>

                            </div>
                        </div>
                        <div class="footer-links-box">
                            <div class="text-start d-inline-block">
                                <p class="text-lg title-follow neutral-0" style="margin-bottom: 10px;">Contact us
                                </p>
                                <div class="box-socials-footer">
                                    <a class="icon-socials icon-instagram" href="<?php echo $config["telegram1"] ?>"
                                        target="_blank">
                                        <img style="width: 32px;     padding-right: 10px;" alt="AdsAsia"
                                            src="https://static.cdnlogo.com/logos/t/39/telegram.svg"></a>
                                    <a class="icon-socials icon-instagram" href="<?php echo $config["telegram2"] ?>"
                                        target="_blank">
                                        <img style="width: 32px;     padding-right: 10px;" alt="AdsAsia"
                                            src="https://static.cdnlogo.com/logos/t/39/telegram.svg"></a>

                                            <a class="icon-socials icon-instagram" href="<?php echo $config["instagram"] ?>"
                                            target="_blank">
                                            <img style="width: 32px;     padding-right: 10px;" alt="AdsAsia"
                                                src="https://cdn-icons-png.flaticon.com/512/174/174855.png"></a>

                                    <a class="icon-socials icon-twitter" href="<?php echo $config["whatsapp"] ?>"
                                        target="_blank">
                                        <img style="width: 32px;     padding-right: 10px;" alt="AdsAsia"
                                            src="https://upload.wikimedia.org/wikipedia/commons/thumb/6/6b/WhatsApp.svg/1024px-WhatsApp.svg.png?20220228223904">
                                    </a>

                                </div>
                                <p></p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="copyright-component">
                <div class="text-color-gray-300">© <span class="year">2025</span> Adsasia. All rights
                    reserved.</div>

            </div>
        </div>
    </div>
    <div class="contact-us-overlay-wrapper">
        <div class="contact-link-wrapper"><a data-tab="contacts" href="#" class="contact-link red w-inline-block">
                <div class="embed w-embed"><svg width="44" height="44" viewBox="0 0 44 44" fill="none"
                        xmlns="http://www.w3.org/2000/svg">
                        <path
                            d="M22.0003 10C29.3337 10 35.3337 14.7733 35.3337 20.6667C35.3337 26.56 29.3337 31.3333 22.0003 31.3333C20.347 31.3333 18.7603 31.0933 17.2937 30.6667C13.4003 34 8.66699 34 8.66699 34C11.7737 30.8933 12.267 28.8 12.3337 28C10.067 26.0933 8.66699 23.5067 8.66699 20.6667C8.66699 14.7733 14.667 10 22.0003 10Z"
                            fill="white" />
                    </svg></div>
                <div class="hide">Message</div>
            </a></div>
        <div class="footer-full-link-wrapper">
            <div class="footer-contact-wrapper">
                <div class="flex-full">
                    <div class="footer-contact-links-wrapper"><a href="<?php echo $config[" whatsapp"] ?>" target="_blank"
                            class="footer-link-box w-inline-block">
                            <div class="fix-box-24">
                                <div class="embed w-embed"><svg width="21" height="22" viewBox="0 0 21 22" fill="none"
                                        xmlns="http://www.w3.org/2000/svg">
                                        <g clip-path="url(#clip0_1_13877)">
                                            <path
                                                d="M10.5026 0.5H10.4974C4.70794 0.5 0 5.20925 0 11C0 13.2969 0.74025 15.4257 1.99894 17.1543L0.690375 21.0551L4.72631 19.7649C6.38663 20.8647 8.36719 21.5 10.5026 21.5C16.2921 21.5 21 16.7894 21 11C21 5.21056 16.2921 0.5 10.5026 0.5Z"
                                                fill="#4CAF50" />
                                            <path
                                                d="M16.6123 15.3273C16.359 16.0426 15.3536 16.6359 14.5517 16.8091C14.0031 16.9259 13.2864 17.0191 10.8741 16.019C7.78838 14.7406 5.80126 11.6051 5.64638 11.4016C5.49807 11.1982 4.39951 9.7413 4.39951 8.23455C4.39951 6.7278 5.16469 5.99412 5.47313 5.67912C5.72644 5.42055 6.14513 5.30243 6.54676 5.30243C6.67669 5.30243 6.79351 5.30899 6.89851 5.31424C7.20694 5.32737 7.36182 5.34574 7.56526 5.83268C7.81857 6.44299 8.43544 7.94974 8.50894 8.10462C8.58376 8.25949 8.65857 8.46949 8.55357 8.67293C8.45513 8.88293 8.36851 8.97612 8.21363 9.15462C8.05876 9.33312 7.91176 9.46962 7.75688 9.66124C7.61513 9.82793 7.45501 10.0064 7.63351 10.3149C7.81201 10.6167 8.42888 11.6234 9.33713 12.4319C10.5092 13.4754 11.4594 13.8087 11.7994 13.9505C12.0527 14.0555 12.3546 14.0306 12.5396 13.8337C12.7746 13.5804 13.0646 13.1604 13.3599 12.7469C13.5699 12.4503 13.8351 12.4136 14.1133 12.5186C14.3968 12.617 15.897 13.3586 16.2054 13.5121C16.5139 13.667 16.7173 13.7405 16.7921 13.8704C16.8656 14.0004 16.8656 14.6107 16.6123 15.3273Z"
                                                fill="#FAFAFA" />
                                        </g>
                                        <defs>
                                            <clipPath id="clip0_1_13877">
                                                <rect width="21" height="21" fill="white"
                                                    transform="translate(0 0.5)" />
                                            </clipPath>
                                        </defs>
                                    </svg></div>
                            </div>
                            <div>WhatsApp</div>
                            <div class="fix-box-16">
                                <div class="embed footer-link w-embed"><svg width="16" height="16" viewBox="0 0 16 16"
                                        fill="none" xmlns="http://www.w3.org/2000/svg">
                                        <path
                                            d="M3.33334 7.99998H12.6667M12.6667 7.99998L8.00001 3.33331M12.6667 7.99998L8.00001 12.6666"
                                            stroke="#101828" stroke-width="1.5" stroke-linecap="round"
                                            stroke-linejoin="round" />
                                    </svg></div>
                            </div>
                        </a>
                        <div class="contact-link-line"></div><a href="<?php echo $config[" telegram"] ?>" target="_blank"
                            class="footer-link-box w-inline-block">
                            <div class="fix-box-24">
                                <div class="embed w-embed"><svg width="24" height="24" viewBox="0 0 24 24" fill="none"
                                        xmlns="http://www.w3.org/2000/svg">
                                        <path
                                            d="M11.5 23C17.299 23 22 18.299 22 12.5C22 6.70101 17.299 2 11.5 2C5.70101 2 1 6.70101 1 12.5C1 18.299 5.70101 23 11.5 23Z"
                                            fill="#039BE5" />
                                        <path
                                            d="M5.80485 12.2727L15.9286 8.36931C16.3985 8.19956 16.8089 8.48393 16.6566 9.19443L16.6575 9.19356L14.9337 17.3144C14.806 17.8902 14.4639 18.0302 13.9852 17.7589L11.3602 15.8243L10.0941 17.0441C9.9541 17.1841 9.83598 17.3022 9.56473 17.3022L9.7511 14.6308L14.6161 10.2357C14.8279 10.0493 14.5689 9.94431 14.2897 10.1298L8.27761 13.9151L5.68585 13.1066C5.12323 12.9281 5.11098 12.5439 5.80485 12.2727Z"
                                            fill="white" />
                                    </svg></div>
                            </div>
                            <div>Telegram</div>
                            <div class="fix-box-16">
                                <div class="embed footer-link w-embed"><svg width="16" height="16" viewBox="0 0 16 16"
                                        fill="none" xmlns="http://www.w3.org/2000/svg">
                                        <path
                                            d="M3.33334 7.99998H12.6667M12.6667 7.99998L8.00001 3.33331M12.6667 7.99998L8.00001 12.6666"
                                            stroke="#101828" stroke-width="1.5" stroke-linecap="round"
                                            stroke-linejoin="round" />
                                    </svg></div>
                            </div>
                        </a>
                        <div class="contact-link-line"></div><a href="mailto:<?php echo $config[" mail"] ?>"
                            class="footer-link-box w-inline-block">
                            <div class="fix-box-24">
                                <div class="embed w-embed"><svg width="24" height="24" viewBox="0 0 24 24" fill="none"
                                        xmlns="http://www.w3.org/2000/svg">
                                        <path
                                            d="M13.9229 14.2445C13.4253 14.5762 12.8472 14.7516 12.2513 14.7516C11.6553 14.7516 11.0773 14.5762 10.5796 14.2445L2.38318 8.78001C2.33771 8.7497 2.2934 8.71809 2.25 8.68559V17.6397C2.25 18.6663 3.08311 19.4811 4.09136 19.4811H20.4111C21.4377 19.4811 22.2525 18.648 22.2525 17.6397V8.68555C22.209 8.71813 22.1646 8.74981 22.119 8.78017L13.9229 14.2445Z"
                                            fill="#667085" />
                                        <path
                                            d="M3.0333 7.80479L11.2298 13.2693C11.54 13.4762 11.8956 13.5796 12.2512 13.5796C12.6068 13.5796 12.9625 13.4761 13.2727 13.2693L21.4692 7.80479C21.9597 7.47799 22.2525 6.93105 22.2525 6.34074C22.2525 5.32573 21.4267 4.5 20.4118 4.5H4.09074C3.07577 4.50004 2.25 5.32577 2.25 6.34171C2.25 6.93105 2.54285 7.47799 3.0333 7.80479Z"
                                            fill="#667085" />
                                    </svg></div>
                            </div>
                            <div>Email us</div>
                            <div class="fix-box-16">
                                <div class="embed footer-link w-embed"><svg width="16" height="16" viewBox="0 0 16 16"
                                        fill="none" xmlns="http://www.w3.org/2000/svg">
                                        <path
                                            d="M3.33334 7.99998H12.6667M12.6667 7.99998L8.00001 3.33331M12.6667 7.99998L8.00001 12.6666"
                                            stroke="#101828" stroke-width="1.5" stroke-linecap="round"
                                            stroke-linejoin="round" />
                                    </svg></div>
                            </div>
                        </a>

                    </div>
                    <div class="hide w-embed">
                        <style>
                            .footer-link-box:hover .fix-box-16 .embed {
                                transform: translateX(0);
                            }
                        </style>
                    </div>
                </div>
                <div data-tab="contact-close" class="footer-close-button">
                    <div class="embed w-embed"><svg width="32" height="32" viewBox="0 0 32 32" fill="none"
                            xmlns="http://www.w3.org/2000/svg">
                            <path d="M24 8L8 24M8 8L24 24" stroke="white" stroke-width="2" stroke-linecap="round"
                                stroke-linejoin="round" />
                        </svg></div>
                </div>
            </div>
        </div>
    </div>
</div>

        </div>
    </div>



    <script src="https://d3e54v103j8qbb.cloudfront.net/js/jquery-3.5.1.min.dc5e7f18c8.js?site=668b3733f80ed0dcd2c46207"
    type="text/javascript" integrity="sha256-9/aliU8dGd2tb6OSsuzixeV4y/faTqgFtohetphbbj0="
    crossorigin="anonymous"></script>
<script src="https://cdn.prod.website-files.com/668b3733f80ed0dcd2c46207/js/agency-aurora.schunk.4a394eb5af8156f2.js"
    type="text/javascript"></script>
<script src="https://cdn.prod.website-files.com/668b3733f80ed0dcd2c46207/js/agency-aurora.schunk.c2aa238619ecee8d.js"
    type="text/javascript"></script>
<script src="https://cdn.prod.website-files.com/668b3733f80ed0dcd2c46207/js/agency-aurora.schunk.1c7a69805f298c42.js"
    type="text/javascript"></script>
<script src="https://cdn.prod.website-files.com/668b3733f80ed0dcd2c46207/js/agency-aurora.b4d15712.822708d2ff0b0f1b.js"
    type="text/javascript"></script><!-- Auto Update Year -->

<script>
    var d = new Date();
    var n = d.getFullYear();
    $('.year').text(n);

    $('.auto-left-arrow').on('click', function (e) {
        e.preventDefault();

        var number = $(this).attr('data-button-left');

        $('.auto-left-button[data-left=' + number + ']').trigger('click');
    });

    $('.auto-right-arrow').on('click', function (e) {
        e.preventDefault();

        var number = $(this).attr('data-button-right');

        $('.auto-right-button[data-right=' + number + ']').trigger('click');
    });

    $('[data-link][data-to="Use Case"]').on('click', function (e) {
        e.preventDefault();
        var pro = window.location.protocol;
        var host = window.location.hostname;
        var url = pro + "//" + host + "/solutions/use-cases";

        var href = window.location.href;

        // detect if href are the same or not
        if (href === url) {
            toSection();
        } else {
            localStorage.setItem("is_dropdown", 'yes');
            window.location.href = url;
        }
    });

    $('[data-link][data-to="Features"]').on('click', function (e) {
        e.preventDefault();
        var pro = window.location.protocol;
        var host = window.location.hostname;
        var url = pro + "//" + host + "/solutions/features";

        var href = window.location.href;

        var link = $(this).attr('data-link');

        // detect if href are the same or not
        if (href === url) {
            localStorage.setItem("feature_to", link);
            toFeature();
        } else {
            localStorage.setItem("is_feature", 'yes');
            localStorage.setItem("feature_to", link);
            window.location.href = url;
        }
    });

    let getDropdown = localStorage.getItem("is_dropdown");

    if (getDropdown == 'yes') {
        toSection();
    }

    let getFeatureDropdown = localStorage.getItem("is_feature");
    if (getFeatureDropdown == 'yes') {
        toFeature();
    }

    function toSection() {
        $('html, body').animate({
            scrollTop: $("#business-section").offset().top
        }, 500);
        localStorage.setItem("is_dropdown", 'no');
    }

    function toFeature() {
        var link = localStorage.getItem("feature_to");
        var to = '';

        if (link == 'Agency') {
            to = 'agency-accounts';
        }

        if (link == 'Cashback') {
            to = 'cashback';
        }

        if (link == 'Dashboard') {
            to = 'dashboard';
        }

        if (link == 'Reselling') {
            to = 'reselling-program';
        }

        if (link == 'Affiliate') {
            to = 'affiliate-program';
        }

        $('html, body').animate({
            scrollTop: $("#" + to).offset().top
        }, 500);
        localStorage.setItem("is_feature", 'no');
    }

    const formSubmitEvent = (function () {
        const init = ({
            onlyWorkOnThisFormName,
            onSuccess,
            onFail
        }) => {
            $(document).ajaxComplete(function (event, xhr, settings) {
                if (settings.url.includes("https://webflow.com/api/v1/form/")) {
                    const isSuccessful = xhr.status === 200
                    const isWorkOnAllForm = onlyWorkOnThisFormName == undefined
                    const isCorrectForm = !isWorkOnAllForm && settings.data.includes(getSanitizedFormName(onlyWorkOnThisFormName));

                    if (isWorkOnAllForm) {
                        if (isSuccessful) {
                            onSuccess()
                        } else {
                            onFail()
                        }
                    } else if (isCorrectForm) {
                        if (isSuccessful) {
                            onSuccess()
                        } else {
                            onFail()
                        }
                    }
                }
            });
        }
        function getSanitizedFormName(name) {
            return name.replaceAll(" ", "+")
        }
        return {
            init
        }
    })()
    $('#subscribe-btn').on('click', function () {

        var email = $('#footer-email').val();
        let pattern = /^\b[A-Z0-9._%-]+@[A-Z0-9.-]+\.[A-Z]{2,4}\b$/i;

        if (email !== '' && pattern.test(email)) {
            $('#footer-email').attr('data-check', 'active');
            $('#subscribe-form').submit();
            return;
        }

        $('#footer-email').addClass('error');
        $('#error-message').text("Please enter a valid email address");
    });

    $('#footer-email').on('input', function () {
        $(this).removeClass('error');
        $(this).removeClass('warning');
    });

    formSubmitEvent.init({
        onlyWorkOnThisFormName: "Subscribe Form",
        onSuccess: () => {
            $('#subscribe-form').css('display', 'flex');
            $('#subscribe-success').css('display', 'none');
            $('#subscribe-error').css('display', 'none');

            if ($('#footer-email').attr('data-check') !== 'active') {
                return;
            }

            $('#footer-email').addClass('success');
            $('#error-message').text("You're in, thanks for subscribing!");
            $('#footer-email').attr('data-check', 'inactive');
        },
        onFail: () => {
            $('#footer-email').attr('data-check', 'inactive');
        }
    })

    function getURLParams(url) {
        return Object.fromEntries(new URL(url).searchParams.entries());
    }

    function setCookie(cname, cvalue, exdays) {
        const d = new Date();
        d.setTime(d.getTime() + (exdays * 24 * 60 * 60 * 1000));
        let expires = "expires=" + d.toUTCString();
        document.cookie = cname + "=" + cvalue + ";" + expires + ";path=/";
    }

    function toOnboarding(referrerName) {
        var current_url = window.location.href;
        var url_object = new URL(current_url);
        var protocol = url_object.protocol;
        var domain = url_object.hostname;
        var last = window.location.href.split("/").pop();
        var getName = referrerName;

        if (last === 'onboarding') {
            last = 'stm';
        }
        if (last === 'dubai' || last === 'awc') {
            last = 'AWDubai'
        }

        if (last === 'events') {
            //last = 'new-york'
            //last = 'europe'
            last = 'malta-2024'
        }

        // var replaceUrl = protocol + '//' + domain + '/onboarding?ref=' + last;
        var replaceUrl = 'https://vantage.agency-aurora.com/?ref=' + referrerName;
        localStorage.setItem("toUrl", replaceUrl);
        localStorage.setItem("refName", referrerName);
        localStorage.setItem("onboardingForm", true);
        if (last === 'AWDubai' || last === 'milan' || last === 'new-york' || last === 'europe' || last === 'malta-2024') {
            window.location.href = replaceUrl;
            return;
        }
        window.location.replace(replaceUrl);
    }

    $(document).ready(function () {
        var currentURL = window.location.href;
        var params = getURLParams(currentURL);
        console.log(currentURL);
        console.log(params);
        if ("ref" in params) {
            //document.cookie = "ref="+ params['ref'] +"; path=/";
            var fromURL = localStorage.getItem("toUrl");
            var refName = localStorage.getItem("refName");
            console.log("From: " + fromURL);
            console.log("Ref: " + refName);

            if (refName == 'velocityprofits') {
                document.title = "Client Onboarding | Velocity Profits";
            }

            if (currentURL === fromURL && refName !== '') {
                setCookie('ref', refName, 7);
                return;
            }

            setCookie('ref', params['ref'], 7);
            localStorage.setItem("toUrl", "");
            localStorage.setItem("refName", "");
            localStorage.setItem("onboardingForm", false);
        }
    });
</script>
<script>
    $(document).on('click', '[data-tab="contacts"]', function (e) {
        e.preventDefault();
        $(this).addClass('close');
        setTimeout(function () {
            $('.contact-link-wrapper').addClass('hide');
            $('.footer-full-link-wrapper').addClass('show');
        }, 205);

        setTimeout(function () {
            $('.footer-contact-wrapper').addClass('show');
        }, 210);
    });

    $(document).on('click', '[data-tab="contact-close"]', function (e) {
        e.preventDefault();
        $('.footer-contact-wrapper').removeClass('show');
        setTimeout(function () {
            $('.contact-link-wrapper').removeClass('hide');
            $('.footer-full-link-wrapper').removeClass('show');
        }, 205);
        setTimeout(function () {
            $('[data-tab="contacts"]').removeClass('close');
        }, 210);
    });
</script>

<script src="https://cdn.jsdelivr.net/npm/@splidejs/splide@4.1.4/dist/js/splide.min.js"></script>
<script>
    var splide = new Splide('.splide', {
        type: 'loop',
        autoWidth: true,
        autoplay: true,
        interval: 8000,
        speed: 1000,
        gap: '1.5rem',
        classes: {
            pagination: 'splide__pagination meta-hero-progress-bar',
            page: 'splide__pagination__page slider-dot',
        },
        //breakpoints: {
        //767: {
        //pagination: false,
        //autoWidth: false,
        //},
        //},
    });

    splide.mount();

    var noToggle = false;
    $(".infrastracture-box").on('mouseover', function () {
        var el = $(this);

        el.children('.ad-bg-box').css('opacity', '1');
        el.find('.infra-button').css('background-color', '#d5283a');
    });

    $(".infrastracture-box").on('mouseout', function () {
        var el = $(this);

        el.children('.ad-bg-box').css('opacity', '0');
        el.find('.infra-button').css('background-color', '#344054');
    });

    function getRandomInt(min, max, except) {
        min = Math.ceil(min);
        max = Math.floor(max);
        var num = Math.floor(Math.random() * (max - min + 1)) + min;
        if (except !== 'not') {
            while (num === except) {
                num = Math.floor(Math.random() * (max - min + 1)) + min;
            }
        }
        return num;
    }

    async function animateUserIcons(el) {
        animateIconChangeColor(el, 'F04438');
        await wait(1500);
        animateSetOpacity(el, '0')
        await wait(1500);
        animateSetOpacity(el, '1')
        animateIconChangeColor(el, '17B26A');
        await wait(1500);
        animateIconChangeColor(el, '667085');
        await wait(2000);
        animateUserIcons(el);
    }

    async function animateNotification(el) {
        el.find('[data-cashback-notification]').attr('data-appear', 'true');
        await wait(5000);
        el.find('[data-cashback-notification]').attr('data-appear', 'false');
        await wait(2500);
        animateNotification(el);
    }

    function createRandomArray(range) {
        let array = [];
        let currentIndex = range;
        for (let i = 0; i < range; i++) {
            array[i] = i;
        }

        while (currentIndex != 0) {
            // Pick a remaining element...
            let randomIndex = Math.floor(Math.random() * currentIndex);
            currentIndex--;

            // And swap it with the current element.
            [array[currentIndex], array[randomIndex]] = [
                array[randomIndex], array[currentIndex]];
        }
        return array;
    }

    function observeUserIconMutation(el) {
        var config = { attributes: true, childList: true, characterData: true };

        el.find('[data-animate-user-icon]').each(function () {
            var target = this;
            var observer = new MutationObserver(function (mutations) {
                mutations.forEach(function (mutation) {
                    console.log(target.style.offsetDistance);
                    if (target) {

                    }
                });
            });

            observer.observe(target, config);
        });
    }

    function animateIconChangeColor(el, color) {
        let icon1 = el.find('[data-animation-user-icon="6"]');
        let icon2 = el.find('[data-animation-user-icon="17"]');
        let icon3 = el.find('[data-animation-user-icon="22"]');
        icon1.find('rect').css('fill', '#' + color);
        icon2.find('rect').css('fill', '#' + color);
        icon3.find('rect').css('fill', '#' + color);
    }

    function animateSetOpacity(el, opaque) {
        let icon1 = el.find('[data-animation-user-icon="6"]');
        let icon2 = el.find('[data-animation-user-icon="17"]');
        let icon3 = el.find('[data-animation-user-icon="22"]');
        icon1.css('opacity', opaque);
        icon2.css('opacity', opaque);
        icon3.css('opacity', opaque);
    }

    function opacityOn(el, display) {
        if (display === undefined) {
            display = 'block';
        }

        el.css('opacity', '0');
        el.css('display', display);

        el.animate({
            opacity: "1",
        }, 200, 'linear');
    }

    function opacityOff(el) {
        el.animate({
            opacity: "0",
        }, 200, 'linear', function () {
            el.css('display', 'none');
        });
    }

    function scaleUp(el) {
        el.css('transform', 'scale(0)');
        el.css('display', 'block');
        el.css('borderSpacing', 1).animate({
            borderSpacing: 1.3
        }, {
            step: function (now, fx) {
                $(this).css('transform', 'scale(1)');
            },
            duration: 'fast'
        });
    }

    var buttonPlays = 0;

    function wait(seconds) {
        return new Promise(resolve => {
            setTimeout(resolve, seconds);
        });
    }

    function scaleDown(el) {
        el.css('borderSpacing', 1).animate({
            borderSpacing: 1
        }, {
            step: function (now, fx) {
                var inside = $(this);
                inside.css('transform', 'scale(0)');
                setTimeout(function () {
                    inside.css('display', 'none');
                }, 300);
            },
            duration: 'fast',
        });
    }

    $.fn.isInViewport = function () {
        let elementTop = $(this).offset().top;
        let elementBottom = elementTop + $(this).outerHeight();

        let viewportTop = $(window).scrollTop();
        let viewportBottom = viewportTop + window.innerHeight;

        return elementBottom > viewportTop && elementTop < viewportBottom;
    };

    let hasBeenAnimated = false;

    function animate() {
        $('.counter-number').each(function () {
            $(this).prop('Counter', 0).animate({
                Counter: $(this).text()
            }, {
                duration: 1500,
                easing: 'swing',
                step: function (now) {
                    $(this).text(Math.ceil(now));
                }
            });
        });
    }

    async function adSectionAnimate() {
        firstAd();
        await wait(150);
        secondAd();
        await wait(150);
        thirdAd();
        await wait(150);
        fourthAd();
    }

    async function firstAd() {
        $('[data-anim-ad-box=1]').attr('data-show', 'true');
        await wait(300);
        $('[data-whitelist-content=1]').attr('data-show', 'true');
        await wait(300);
        // the animations
        $('[data-whitelist-logo="aurora"]').attr('data-show', 'true');
        await wait(200);
        var delay = 100;
        for (let i = 1; i <= 7; i++) {
            $('[data-whitelist-logo="' + i + '"]').attr('data-show', 'true');
            await wait(delay);
        }
    }

    async function secondAd() {
        $('[data-anim-ad-box=2]').attr('data-show', 'true');
        // number counter
        await wait(300);
        $('[data-whitelist-content=2]').attr('data-show', 'true');
        await wait(300);
        $('[data-whitelist-content="second"]').attr('data-show', 'true');
        await wait(150);
        $('[data-whitelist-number="7"]').prop('Counter', 0).animate({
            Counter: 7
        }, {
            duration: 800,
            easing: 'swing',
            step: function (now) {
                $(this).text(Math.ceil(now));
            }
        });
    }

    async function thirdAd() {
        $('[data-anim-ad-box=3]').attr('data-show', 'true');
        // ??
        await wait(300);
        $('[data-whitelist-content=3]').attr('data-show', 'true');
        await wait(150);
        $('[data-whitelist-image-box="image"]').attr('data-show', 'true');
    }

    async function fourthAd() {
        $('[data-anim-ad-box=4]').attr('data-show', 'true');
        // ??
        await wait(300);
        $('[data-whitelist-content=4]').attr('data-show', 'true');
        await wait(120);
        animateSvg();
    }

    function detectOffset(el) {
        let f = $(el).offset().top - $(window).scrollTop();
        return f;
    }

    $(window).scroll(function () {
        if ($('.scale-component').isInViewport() && !hasBeenAnimated) {
            hasBeenAnimated = true;
            animate();
        }

        if ($('[data-anim-container="advertising"]').isInViewport && $('[data-anim-container="advertising"]').attr('data-show') === "false") {
            let getOffset = detectOffset('[data-anim-container="advertising"]');
            if (getOffset <= 120) {
                $('[data-anim-container="advertising"]').attr('data-show', 'true');
                adSectionAnimate();
            }
        }

        $('[data-feature-image-box][data-show="false"]').each(function () {
            var el = $(this);
            var num = el.attr('data-anim-show-up');
            let getOffset = detectOffset('[data-anim-show-up="' + num + '"]');

            if (getOffset <= 300) {
                el.attr('data-show', 'true');
            }
        });

        $('[data-anim-show-up][data-show="false"]').each(function () {
            var el = $(this);
            var num = el.attr('data-anim-show-up');
            let getOffset = detectOffset('[data-anim-show-up="' + num + '"]');
            let height = screen.height;
            let percent = height * 0.80; // 85 percent

            if (getOffset <= percent) {
                console.log("yes");
                el.attr('data-show', 'true');
            }
        });
    });

    $('[svg="animated"]').css({
        opacity: 0,
        transition: "opacity 400ms ease"
    });

    function animateSvg(el) {
        $('[svg="animated"] path').each(function () {
            var pathLength = this.getTotalLength();
            $(this).attr({
                "stroke-dasharray": pathLength,
                "stroke-dashoffset": pathLength
            });
            var svgAnimated = $(this).closest('[svg="animated"]');
            var animationDuration = svgAnimated.attr('svg-animation-time') || 5000;
            $(svgAnimated).css("opacity", 1);
            $(this).css({
                transition: "stroke-dashoffset " + animationDuration + "ms ease-out",
                "stroke-dashoffset": 0
            });

        });
    }


    function scrollToContact() {
        $('html, body').animate({
            scrollTop: $('#contact').offset().top
        }, 600); // 600ms là thời gian scroll
    }

</script>

     


</body>

</html>    
