<?php class_exists('Template') or exit; ?>
<!DOCTYPE html>
<?php
$lang = $_GET['lang'] ?? 'en'; // mặc định 'en' nếu không có ?lang
?>
<html lang="<?= $lang ?>">

<head>
    <meta charset="utf-8" />
    <title>AdsAsia - Home Page</title>
    <meta
        content="Experience seamless digital advertising solutions with AdsAsia. We help businesses scale campaigns, drive growth, and achieve long-term success efficiently."
        name="description" />
    <meta content="Agency Accounts &amp; Advertising Solutions | AdsAsia" property="og:title" />
    <meta
        content="Experience seamless digital advertising solutions with AdsAsia. We help businesses scale campaigns, drive growth, and achieve long-term success efficiently."
        property="og:description" />
    <meta
        content="assets/img1.png"
        property="og:image" />
    <meta content="Agency Accounts &amp; Advertising Solutions | AdsAsia" property="twitter:title" />
    <meta
        content="Experience seamless digital advertising solutions with AdsAsia. We help businesses scale campaigns, drive growth, and achieve long-term success efficiently."
        property="twitter:description" />
    <meta
        content="assets/img1.png"
        property="twitter:image" />
    <meta property="og:type" content="website" />
    <meta content="summary_large_image" name="twitter:card" />
    <meta content="width=device-width, initial-scale=1" name="viewport" />
    <link href="https://cdn.prod.website-files.com/668b3733f80ed0dcd2c46207/css/agency-aurora.shared.dc0bd0013.min.css"
        rel="stylesheet" type="text/css" />
    <link href="https://fonts.googleapis.com" rel="preconnect" />
    <link href="https://fonts.gstatic.com" rel="preconnect" crossorigin="anonymous" />
    <script src="https://ajax.googleapis.com/ajax/libs/webfont/1.6.26/webfont.js" type="text/javascript"></script>
    <script
        type="text/javascript">WebFont.load({ google: { families: ["Plus Jakarta Sans:200,300,regular,500,600,700,800,200italic,300italic,italic,500italic,600italic,700italic,800italic", "Plus Jakarta Sans:regular:cyrillic-ext,latin,latin-ext"] } });</script>
    <script
        type="text/javascript">!function (o, c) { var n = c.documentElement, t = " w-mod-"; n.className += t + "js", ("ontouchstart" in o || o.DocumentTouch && c instanceof DocumentTouch) && (n.className += t + "touch") }(window, document);</script>
    <link rel="shortcut icon" type="image/x-icon" href="assets/fav.png">

    <script>
        window.dataLayer = window.dataLayer || [];
        function gtag() { dataLayer.push(arguments); }
        gtag('js', new Date());
        gtag('config', 'G-P88VC5CC9W');
    </script>
    <script src="https://unpkg.com/three@0.149.0/build/three.js"></script>
    <script src="https://unpkg.com/three-globe@2.25.1/dist/three-globe.min.js"></script>
    <style>
        /**
    .aurora-box {
        transform: rotate3d(0, 2, 1, 45deg);
    }
    .bg-container {
            -webkit-transform: scaleX(-1);
        transform: scaleX(-1);
    }**/

    .i18n-switcher select {
  background: transparent;
  color: #fff;       /* đổi theo nền navbar của bạn */
  border: 1px solid rgba(255,255,255,.25);
  padding: 6px 10px;
  border-radius: 6px;
  font-size: 14px;
  outline: none;
}
.i18n-switcher select:focus {
  border-color: #ff4d4f; /* màu nhấn */
}
@media (max-width: 768px) {
  .i18n-switcher select {
      background: #00000085;   /* màu nền bạn muốn */
      color: #fff;             /* chữ trắng cho dễ đọc */
      border: 1px solid #444;  /* viền nhẹ */
  }
}


        .hero-toggle,
        .hero-logo-icon-box {
            display: none;
            transition: transform 200ms ease-in-out, opacity 200ms ease-in-out, background-color 200ms ease-in-out;
        }

        .moving-icon {
            transition: transform 200ms ease-in-out, opacity 200ms ease-in-out;
        }

        .hero-toggle.no-dice {
            display: block;
            transition: transform 300ms ease-in-out;
        }

        .hero-option {
            transform: scale(0);
            transition: background-color .2s ease-in-out, color .2s ease-in-out, transform 200ms ease-in-out, opacity 200ms ease-in-out;
        }

        .move-top {
            transform: translate(0, -100%);
        }

        #gimmick {
            display: block;
            pointer-events: none;
            position: absolute;
            top: 0;
            left: 0;
        }

        [data-whitelist-logo] {
            transition: opacity 200ms ease-in-out, transform 200ms ease-in-out;
        }

        [data-anim-show-up],
        [data-whitelist-content],
        [data-whitelist-image-box],
        [data-load="box"] {
            transition: opacity 500ms ease-in-out, transform 500ms ease-in-out;
        }

        [data-anim-ad-box][data-show="false"],
        [data-feature-image-box][data-show="false"],
        [data-anim-show-up][data-show="false"],
        [data-whitelist-image-box][data-show="false"],
        [data-load="box"][data-show="false"] {
            opacity: 0;
            transform: translate(0, 50px);
        }

        [data-whitelist-content][data-show="false"] {
            opacity: 0;
        }

        [data-whitelist-logo][data-show="false"] {
            opacity: 0;
            transform: scale(0.2);
        }
    </style>
    <link href="https://cdn.jsdelivr.net/npm/@splidejs/splide@4.1.4/dist/css/splide.min.css" rel="stylesheet">
    <style>
        .splide__track {
            overflow: visible;
        }

        .splide__arrow {
            z-index: -999;
        }

        .splide__arrows {
            opacity: 0;
        }

        .splide__pagination {
            bottom: 0;
            bottom: 0;
            position: relative;
            justify-content: flex-start;
            margin-top: 1.5rem;
        }

        .splide:not(.is-overflow) .splide__pagination {
            max-width: 1600px;
            position: relative;
            display: flex;
            justify-content: flex-start;
            padding: 0;
        }

        .splide__pagination__page {
            background-color: #475467;
            border-radius: 100%;
            width: .75rem;
            height: .75rem;
            opacity: 1;
            margin: 0;
        }

        .splide__pagination__page.is-active {
            background: #e9394b;
            transform: scale(1);
            z-index: 1;
        }

        /**
    .aurora-box {
        transform: rotate3d(0, 2, 1, 45deg);
    }
    .bg-container {
            -webkit-transform: scaleX(-1);
        transform: scaleX(-1);
    }**/
    </style>

    



</head>

<body>



    <div class="page-wrapper">
        <div class="global-styles w-embed">
            <style>
                /*Scroll Bar Style*/
                /*width*/
                ::-webkit-scrollbar {
                    width: 5px;
                }

                /*track*/
                ::-webkit-scrollbar-track {
                    background: white;
                }

                /*thumb*/
                ::-webkit-scrollbar-thumb {
                    background: #E9394B;
                }

                /*Custom Highlight Color on Select*/

                ::-moz-selection {
                    /* Firefox */
                    color: #ffffff;
                    background: #E9394B;
                }

                ::selection {
                    color: #ffffff;
                    background: #E9394B;
                }

                html {
                    font-size: calc(0.5rem + 0.41666666666666663vw);
                }

                @media screen and (max-width:1920px) {
                    html {
                        font-size: calc(0.49999999999999994rem + 0.41666666666666674vw);
                    }
                }

                @media screen and (max-width:1440px) {
                    html {
                        font-size: calc(0.8126951092611863rem + 0.20811654526534862vw);
                    }
                }

                @media screen and (max-width:479px) {
                    html {
                        font-size: calc(0.7494769874476988rem + 0.8368200836820083vw);
                    }
                }

                /* Make text look crisper and more legible in all browsers */
                body {
                    -webkit-font-smoothing: antialiased;
                    -moz-osx-font-smoothing: grayscale;
                    font-smoothing: antialiased;
                    text-rendering: optimizeLegibility;
                }

                /* Get rid of top margin on first element in any rich text element */
                .w-richtext> :not(div):first-child,
                .w-richtext>div:first-child> :first-child {
                    margin-top: 0 !important;
                }

                /* Get rid of bottom margin on last element in any rich text element */
                .w-richtext>:last-child,
                .w-richtext ol li:last-child,
                .w-richtext ul li:last-child {
                    margin-bottom: 0 !important;
                }

                /*Reset buttons, and links styles*/
                a {
                    color: inherit;
                    text-decoration: inherit;
                    font-size: inherit;
                }

                /* Apply "..." after 3 lines of text */
                .text-style-3lines {
                    display: -webkit-box;
                    overflow: hidden;
                    -webkit-line-clamp: 3;
                    -webkit-box-orient: vertical;
                }

                /* Apply "..." after 2 lines of text */
                .text-style-2lines {
                    display: -webkit-box;
                    overflow: hidden;
                    -webkit-line-clamp: 2;
                    -webkit-box-orient: vertical;
                }

                /*  Identify Blank Links 
    [href="#"] {
    color: red;
    outline: 3px solid red;
    }
    */

                /* Hide Section if it has no CMS Items inside (Give section an attribute name of data-cms-section)*/

                [data-cms-section]:not(:has(.w-dyn-item)) {
                    display: none;
                }

                .nav-red-line {
                    display: none;
                }

                /** , .nav-link-box:has(.w--open) > .nav-red-line **/
                .nav-link-box:has(.w--current)>.nav-red-line {
                    display: block;
                }

                .nav-link-box:has(.w--current) .nav-dropdown-toggle,
                .nav-link-box:has(.w--current) .nav-text-link,
                .nav-link-box:has(.w--current) .white-link {
                    font-weight: 600;
                    color: #fff;
                }

                .transparent-bg,
                .hero-account-item {
                    -webkit-backdrop-filter: blur(5px);
                    backdrop-filter: blur(5px);
                }

                .hide-this {
                    display: none;
                }

                .meta-hero-slider {
                    gap: 0;
                }

                .onboarding-button:disabled,
                .onboarding-button[disabled],
                .onboarding-button[data-disabled="true"] {
                    background-color: #f8abb3;
                    cursor: default;
                }

                [data-onboard-arrow="open"] {
                    transform: rotate(180deg);
                }

                .onboarding-block-two[data-fill-page="open"] {
                    flex-grow: 1;
                }

                [data-button-all="hide"] {
                    display: none;
                }

                [data-user-icon] {
                    border-spacing: 0;
                    transition: transform 500ms ease-in-out, color 200ms ease-in-out, opacity 500ms ease-in-out;
                }

                [data-box-scale="small"] {
                    opacity: 0;
                    transform: scale(0);
                }

                [data-user-icon="hover"] {
                    color: #1018281a;
                }

                [data-dropdown] {
                    transform: translateX(-100%);
                    transition: transform 200ms ease-in-out;
                }

                .dropdown-link:hover [data-dropdown] {
                    transform: translate(0);
                }

                .error-message,
                .error-box {
                    display: none;
                }

                .footer-field.error+.error-box,
                .footer-field.error+.error-message {
                    color: #FDA29B;
                }

                .footer-field.warning+.error-box,
                .footer-field.warning+.error-message {
                    color: #FEF0C7;
                }

                .footer-field.success+.error-message {
                    color: #75E0A7;
                }

                .footer-field.error+.error-message,
                .footer-field.warning+.error-message,
                .footer-field.success+.error-message {
                    display: block;
                }

                .footer-field.error+.error-box,
                .footer-field.warning+.error-box {
                    display: flex;
                }

                @media screen and (max-width: 991px) {
                    .navbar:has(.w--open) .nav-menu-block {
                        margin-left: 0;
                    }

                    .nav-menu-block {
                        transition-delay: 500ms;
                    }

                    .nav-red-line {
                        display: none !important;
                    }

                    .nav-double-box .dropdown-link {
                        padding-left: 0;
                        padding-right: 0;
                    }

                    .nav-dropdown-toggle.w--open .embed {
                        transform: rotate(180deg);
                    }

                    .nav-dropdown-toggle.w--open {
                        color: var(--gray-900);
                    }

                    .nav-menu {
                        height: calc(100vh - 145px);
                    }

                    .nav-link-box:has(.w--current) .nav-dropdown-toggle,
                    .nav-link-box:has(.w--current) .nav-text-link,
                    .nav-link-box:has(.w--current) .white-link {
                        font-weight: 600;
                        color: var(--gray-900);
                    }

                    .nav-dropdown-toggle.w--open:hover,
                    .nav-link-box:has(.w--current) .nav-dropdown-toggle:hover,
                    .nav-link-box:has(.w--current) .nav-text-link:hover,
                    .nav-link-box:has(.w--current) .white-link:hover {
                        color: white;
                    }
                }

                @media screen and (max-width: 767px) {
                    .platform-list-item .embed {
                        width: 1.125rem;
                        height: 1.125rem;
                    }

                    .nav-menu {
                        height: calc(100vh - 72px);
                    }

                    .hide-this {
                        display: none !important;
                    }

                    .meta-hero-slider {
                        display: flex !important;
                        gap: 1.5rem;
                    }
                }

                @media screen and (max-width: 479px) {
                    .platform-list-item .embed {
                        padding-top: 0.25rem;
                    }
                }

                @media screen and (max-width: 479px) {
                    .platform-item-box .text-color-gray-300 {
                        display: none;
                    }

                    .platform-item-box.w--current .text-color-gray-300 {
                        display: block;
                    }
                }
            </style>

            <style>
                .button-bottom-line {
                    width: 0%;
                    transition: width ease-in-out 200ms;
                }

                .blank-button:hover .button-bottom-line {
                    width: 100%;
                }

                .embed {
                    transition: opacity ease-in-out 200ms, transform 200ms ease-in-out;
                }

                [data-button-icon],
                [data-read-icon] {
                    transition: opacity ease-in-out 200ms, width ease-in-out 200ms;
                }

                [data-button-icon="hover"],
                [data-read-icon="hover"] {
                    opacity: 0;
                    width: 0;
                }

                [data-button-icon="normal"] {
                    width: 1.5rem;
                    opacity: 1;
                }

                [data-read-icon="normal"] {
                    width: 1rem;
                    opacity: 1;
                }

                .blank-button:hover [data-button-icon="normal"],
                .subheading-link-box:hover [data-read-icon="normal"],
                .blog-box:hover [data-button-icon="normal"],
                .infrastracture-box:hover [data-button-icon="normal"],
                .testimonial-link-source:hover [data-button-icon="normal"],
                .platform-testimonial-arrow:hover [data-button-icon="normal"],
                .this-arrow:hover [data-button-icon="normal"],
                .filter-partner-link:hover [data-button-icon="normal"],
                [data-case-to]:hover [data-button-icon="normal"],
                [data-move-link]:hover [data-read-icon="normal"] {
                    width: 0;
                    opacity: 0;
                }

                .blank-button:hover [data-button-icon="hover"],
                .blog-box:hover [data-button-icon="hover"],
                .infrastracture-box:hover [data-button-icon="hover"],
                .testimonial-link-source:hover [data-button-icon="hover"],
                .platform-testimonial-arrow:hover [data-button-icon="hover"],
                .this-arrow:hover [data-button-icon="hover"],
                .filter-partner-link:hover [data-button-icon="hover"],
                [data-case-to]:hover [data-button-icon="hover"] {
                    width: 1.5rem;
                    opacity: 1;
                }

                .subheading-link-box:hover [data-read-icon="hover"],
                [data-move-link]:hover [data-read-icon="hover"] {
                    width: 1rem;
                    opacity: 1;
                }

                .blank-button:hover .button-bottom-line,
                .subheading-link-box:hover .button-bottom-line {
                    width: 100%;
                }

                .blog-box:hover .image-box>img {
                    transform: scale(1.3);
                }

                [data-case-to]:hover .image-box>img {
                    transform: scale(1.2);
                }

                .blog-box:hover .blog-title-box,
                [data-case-to]:hover .case-studies-title-header {
                    color: white;
                }

                .image-box img {
                    transition: transform 300ms ease-in-out;
                }

                option {
                    background-color: var(--gray-900);
                }

                .partner-header .embed,
                .partner-header h3 {
                    transition: color 200ms ease-in-out;
                }

                .partner-header .embed,
                .partner-header h3 {
                    opacity: 0.6;
                }

                .filter-partner-link:hover .partner-header .embed {
                    color: #A983F9;
                    opacity: 1;
                }

                .filter-partner-link:hover .partner-header h3 {
                    color: white;
                    opacity: 1;
                }

                [data-strike="red"] {
                    text-decoration-color: #E9394B;
                }

                .dbc-link-box .box-20 .embed {
                    transition: transform 200ms ease-in-out;
                    transform: translateX(-100%);
                }

                .dbc-link-box:hover .box-20 .embed {
                    transform: translateX(0%);
                }
            </style>
        </div>
        <div class="main-wrapper">
            <div id="aurora-bg" class="section_home-hero no-bg set-0">

                <?php
$lang = $_GET['lang'] ?? 'en'; // mặc định 'en' nếu không có ?lang
?>

<div data-animation="over-right" data-collapse="medium" data-duration="400" data-easing="ease" data-easing2="ease"
    role="banner" class="navbar w-nav">
    <div class="padding-global">
        <div class="container-1600">
            <div class="nav-menu-wrapper"><a href="/?lang=<?php echo $lang; ?>" aria-current="page" class="nav-logo-link w-nav-brand"
                    aria-label="home">
                    <div class="embed w-embed">
                        <img src="assets/logo.png" width="142" alt="Logo" class="logo-image">
                    </div>
                </a>
                <nav role="navigation" class="nav-menu w-nav-menu"
                    style="transition: all; transform: translateX(0px) translateY(0px);">
                    <div class="nav-menu-block">
                        <div class="nav-right-block">

                            <div class="nav-link-box"><a href="/google.php?lang=<?php echo $lang; ?>"  class="nav-text-link w-nav-link">Google</a>
                                <div class="nav-red-line"></div>
                            </div>

                            <div class="nav-link-box"><a href="/tiktok.php?lang=<?php echo $lang; ?>" class="nav-text-link w-nav-link">Tiktok</a>
                                <div class="nav-red-line"></div>
                            </div>

                            <div class="nav-link-box"><a href="/meta.php?lang=<?php echo $lang; ?>" class="nav-text-link w-nav-link">Meta</a>
                                <div class="nav-red-line"></div>
                            </div>
                            <div class="nav-link-box">
                                <?php echo i18n_select_html(); ?>
                            </div>

                        </div>
                        <div class="nav-left-block">
                            <div class="nav-link-box"><a href="javascript:void(0)" onclick="scrollToContact()"
                                    class="white-link w-nav-link">Contact us</a>
                                <div class="nav-red-line"></div>
                            </div>
                        </div>
                    </div>
                </nav>

                <div class="menu-button w-nav-button" style="-webkit-user-select: text;" aria-label="menu" role="button"
                    tabindex="0" aria-controls="w-nav-overlay-0" aria-haspopup="menu" aria-expanded="false">
                    <div class="hide w-icon-nav-menu"></div>
                    <div class="menu-line top"
                        style="background-color: rgb(255, 255, 255); transform: translate3d(0px, 8px, 0px) scale3d(1, 1, 1) rotateX(0deg) rotateY(0deg) rotateZ(-45deg) skew(0deg, 0deg); transform-style: preserve-3d;">
                    </div>
                    <div class="menu-line middle"
                        style="background-color: rgb(255, 255, 255); transform: translate3d(0px, 0px, 0px) scale3d(0, 0, 1) rotateX(0deg) rotateY(0deg) rotateZ(0deg) skew(0deg, 0deg); transform-style: preserve-3d;">
                    </div>
                    <div class="menu-line bottom"
                        style="background-color: rgb(255, 255, 255); transform: translate3d(0px, -8px, 0px) scale3d(1, 1, 1) rotateX(0deg) rotateY(0deg) rotateZ(45deg) skew(0deg, 0deg); transform-style: preserve-3d;">
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="w-nav-overlay" data-wf-ignore="" id="w-nav-overlay-0" style="display: none;"></div>
</div>

                
<div class="section">
    <div class="padding-global">
        <div class="container-1600">
            <div class="aurora-video-background">
                <div data-poster-url="https://cdn.prod.website-files.com/668b3733f80ed0dcd2c46207%2F673c22a9a9de8264b71103ee_aurora-background-homepage-poster-00001.jpg"
                    data-video-urls="https://cdn.prod.website-files.com/668b3733f80ed0dcd2c46207%2F673c22a9a9de8264b71103ee_aurora-background-homepage-transcode.mp4,https://cdn.prod.website-files.com/668b3733f80ed0dcd2c46207%2F673c22a9a9de8264b71103ee_aurora-background-homepage-transcode.webm"
                    data-autoplay="true" data-loop="true" data-wf-ignore="true"
                    class="aurora-bg-wrapper w-background-video w-background-video-atom"><video
                        id="6d60645e-e8fc-ba53-3338-38505e66be80-video" autoplay="" loop=""
                        style="background-image:url(&quot;https://cdn.prod.website-files.com/668b3733f80ed0dcd2c46207%2F673c22a9a9de8264b71103ee_aurora-background-homepage-poster-00001.jpg&quot;)"
                        muted="" playsinline="" data-wf-ignore="true" data-object-fit="cover">
                        <source
                            src="https://cdn.prod.website-files.com/668b3733f80ed0dcd2c46207%2F673c22a9a9de8264b71103ee_aurora-background-homepage-transcode.mp4"
                            data-wf-ignore="true" />
                        <source
                            src="https://cdn.prod.website-files.com/668b3733f80ed0dcd2c46207%2F673c22a9a9de8264b71103ee_aurora-background-homepage-transcode.webm"
                            data-wf-ignore="true" />
                    </video></div>
            </div>
            <div class="margin-bottom-124 set-margin-bottom-48">
                <div class="flex-apart down gap-32">
                    <div class="max-width-809">
                        <h1 class="heading-64 text-color-gray-200">Grow your business with the leading provider of advertising solutions</h1>
                    </div>
                    <div class="max-width-646">
                        <div class="padding-bottom-11">
                            <div class="margin-bottom-32">
                                <div
                                    class="text-size-20 text-weight-medium text-color-gray-300 set-text-size-18 set-text-weight-regular">
                                    One integrated solution to scale campaigns, increase profitability and reduce restrictions. Meet the advertising solution designed for limitless scale across over 40 digital platforms.</div>
                            </div>
                            <div class="button-wrapper">
                                <div class="button-flex-block">
                                    <a data-button-all="" href="javascript:void(0)" onclick="scrollToContact()" class="blank-button w-inline-block">
                                        <div class="position-relative">
                                            <div>Contact Us</div>
                                            <div class="button-bottom-line"></div>
                                        </div>
                                        <div class="fix-24">
                                            <div data-button-icon="hover" class="embed w-embed"><svg width="24"
                                                    height="24" viewBox="0 0 24 24" fill="none"
                                                    xmlns="http://www.w3.org/2000/svg">
                                                    <path d="M5 12H19M19 12L12 5M19 12L12 19" stroke="currentColor"
                                                        stroke-width="2" stroke-linecap="round"
                                                        stroke-linejoin="round" />
                                                </svg></div>
                                            <div data-button-icon="normal" class="embed w-embed"><svg width="24"
                                                    height="24" viewBox="0 0 24 24" fill="none"
                                                    xmlns="http://www.w3.org/2000/svg">
                                                    <path d="M9 18L15 12L9 6" stroke="white" stroke-width="2"
                                                        stroke-linecap="round" stroke-linejoin="round" />
                                                </svg></div>
                                        </div>
                                    </a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div>
                <div class="splide">
                    <div class="splide__track">
                        <div class="splide__list plus-gap-mobile">
                            <div class="splide__slide max-width-519 set-max-width-none">
                                <div class="border-16">
                                    <div class="hero-background-gif">
                                        <div data-poster-url="https://cdn.prod.website-files.com/668b3733f80ed0dcd2c46207%2F6787912f3a5ee0bc6ffb5f71_N1%20Unlimited%20Whitelisted%20Accounts-poster-00001.jpg"
                                            data-video-urls="https://cdn.prod.website-files.com/668b3733f80ed0dcd2c46207%2F6787912f3a5ee0bc6ffb5f71_N1%20Unlimited%20Whitelisted%20Accounts-transcode.mp4,https://cdn.prod.website-files.com/668b3733f80ed0dcd2c46207%2F6787912f3a5ee0bc6ffb5f71_N1%20Unlimited%20Whitelisted%20Accounts-transcode.webm"
                                            data-autoplay="true" data-loop="true" data-wf-ignore="true"
                                            class="background-hero w-background-video w-background-video-atom">
                                            <video id="d502f5f1-a4db-0c86-2ef0-f99b97b915f8-video" autoplay="" loop=""
                                                style="background-image:url(&quot;https://cdn.prod.website-files.com/668b3733f80ed0dcd2c46207%2F6787912f3a5ee0bc6ffb5f71_N1%20Unlimited%20Whitelisted%20Accounts-poster-00001.jpg&quot;)"
                                                muted="" playsinline="" data-wf-ignore="true" data-object-fit="cover">
                                                <source
                                                    src="https://cdn.prod.website-files.com/668b3733f80ed0dcd2c46207%2F6787912f3a5ee0bc6ffb5f71_N1%20Unlimited%20Whitelisted%20Accounts-transcode.mp4"
                                                    data-wf-ignore="true" />
                                                <source
                                                    src="https://cdn.prod.website-files.com/668b3733f80ed0dcd2c46207%2F6787912f3a5ee0bc6ffb5f71_N1%20Unlimited%20Whitelisted%20Accounts-transcode.webm"
                                                    data-wf-ignore="true" />
                                            </video>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="splide__slide max-width-519 set-max-width-none">
                                <div class="border-16">
                                    <div class="hero-background-gif">
                                        <div data-poster-url="https://cdn.prod.website-files.com/668b3733f80ed0dcd2c46207%2F678791385d95592612745284_N2%20Exclusive%20Partnerships%20With%2040%2B%20Platforms-poster-00001.jpg"
                                            data-video-urls="https://cdn.prod.website-files.com/668b3733f80ed0dcd2c46207%2F678791385d95592612745284_N2%20Exclusive%20Partnerships%20With%2040%2B%20Platforms-transcode.mp4,https://cdn.prod.website-files.com/668b3733f80ed0dcd2c46207%2F678791385d95592612745284_N2%20Exclusive%20Partnerships%20With%2040%2B%20Platforms-transcode.webm"
                                            data-autoplay="true" data-loop="true" data-wf-ignore="true"
                                            class="background-hero w-background-video w-background-video-atom">
                                            <video id="50b8f122-f5d0-00f6-be0e-423d21ebecd9-video" autoplay="" loop=""
                                                style="background-image:url(&quot;https://cdn.prod.website-files.com/668b3733f80ed0dcd2c46207%2F678791385d95592612745284_N2%20Exclusive%20Partnerships%20With%2040%2B%20Platforms-poster-00001.jpg&quot;)"
                                                muted="" playsinline="" data-wf-ignore="true" data-object-fit="cover">
                                                <source
                                                    src="https://cdn.prod.website-files.com/668b3733f80ed0dcd2c46207%2F678791385d95592612745284_N2%20Exclusive%20Partnerships%20With%2040%2B%20Platforms-transcode.mp4"
                                                    data-wf-ignore="true" />
                                                <source
                                                    src="https://cdn.prod.website-files.com/668b3733f80ed0dcd2c46207%2F678791385d95592612745284_N2%20Exclusive%20Partnerships%20With%2040%2B%20Platforms-transcode.webm"
                                                    data-wf-ignore="true" />
                                            </video>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="splide__slide max-width-519 set-max-width-none">
                                <div class="border-16">
                                    <div class="hero-background-gif">
                                        <div class="background-video-wrapper">
                                            <div data-poster-url="https://cdn.prod.website-files.com/668b3733f80ed0dcd2c46207%2F678791439b08c792fba3a3fc_N3%20Variety%20Of%20Payment%20Methods-poster-00001.jpg"
                                                data-video-urls="https://cdn.prod.website-files.com/668b3733f80ed0dcd2c46207%2F678791439b08c792fba3a3fc_N3%20Variety%20Of%20Payment%20Methods-transcode.mp4,https://cdn.prod.website-files.com/668b3733f80ed0dcd2c46207%2F678791439b08c792fba3a3fc_N3%20Variety%20Of%20Payment%20Methods-transcode.webm"
                                                data-autoplay="true" data-loop="true" data-wf-ignore="true"
                                                class="background-hero w-background-video w-background-video-atom">
                                                <video id="5d24c069-54d3-746b-9c6f-ecaa4a64749a-video" autoplay=""
                                                    loop=""
                                                    style="background-image:url(&quot;https://cdn.prod.website-files.com/668b3733f80ed0dcd2c46207%2F678791439b08c792fba3a3fc_N3%20Variety%20Of%20Payment%20Methods-poster-00001.jpg&quot;)"
                                                    muted="" playsinline="" data-wf-ignore="true"
                                                    data-object-fit="cover">
                                                    <source
                                                        src="https://cdn.prod.website-files.com/668b3733f80ed0dcd2c46207%2F678791439b08c792fba3a3fc_N3%20Variety%20Of%20Payment%20Methods-transcode.mp4"
                                                        data-wf-ignore="true" />
                                                    <source
                                                        src="https://cdn.prod.website-files.com/668b3733f80ed0dcd2c46207%2F678791439b08c792fba3a3fc_N3%20Variety%20Of%20Payment%20Methods-transcode.webm"
                                                        data-wf-ignore="true" />
                                                </video>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="splide__slide max-width-519 set-max-width-none">
                                <div class="border-16">
                                    <div class="hero-background-gif">
                                        <div class="background-video-wrapper">
                                            <div data-poster-url="https://cdn.prod.website-files.com/668b3733f80ed0dcd2c46207%2F6787914b2b90e31ccc3b05a4_N4%20All%20In%20One%20Dashboard-poster-00001.jpg"
                                                data-video-urls="https://cdn.prod.website-files.com/668b3733f80ed0dcd2c46207%2F6787914b2b90e31ccc3b05a4_N4%20All%20In%20One%20Dashboard-transcode.mp4,https://cdn.prod.website-files.com/668b3733f80ed0dcd2c46207%2F6787914b2b90e31ccc3b05a4_N4%20All%20In%20One%20Dashboard-transcode.webm"
                                                data-autoplay="true" data-loop="true" data-wf-ignore="true"
                                                class="background-hero w-background-video w-background-video-atom">
                                                <video id="c7c3d76b-3202-2223-f5bb-e811ede4890a-video" autoplay=""
                                                    loop=""
                                                    style="background-image:url(&quot;https://cdn.prod.website-files.com/668b3733f80ed0dcd2c46207%2F6787914b2b90e31ccc3b05a4_N4%20All%20In%20One%20Dashboard-poster-00001.jpg&quot;)"
                                                    muted="" playsinline="" data-wf-ignore="true"
                                                    data-object-fit="cover">
                                                    <source
                                                        src="https://cdn.prod.website-files.com/668b3733f80ed0dcd2c46207%2F6787914b2b90e31ccc3b05a4_N4%20All%20In%20One%20Dashboard-transcode.mp4"
                                                        data-wf-ignore="true" />
                                                    <source
                                                        src="https://cdn.prod.website-files.com/668b3733f80ed0dcd2c46207%2F6787914b2b90e31ccc3b05a4_N4%20All%20In%20One%20Dashboard-transcode.webm"
                                                        data-wf-ignore="true" />
                                                </video>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="splide__slide max-width-519 set-max-width-none">
                                <div class="border-16">
                                    <div class="hero-background-gif">
                                        <div class="background-video-wrapper">
                                            <div data-poster-url="https://cdn.prod.website-files.com/668b3733f80ed0dcd2c46207%2F67879152b691b6e350f34192_N5%20Oustanding%20Support-poster-00001.jpg"
                                                data-video-urls="https://cdn.prod.website-files.com/668b3733f80ed0dcd2c46207%2F67879152b691b6e350f34192_N5%20Oustanding%20Support-transcode.mp4,https://cdn.prod.website-files.com/668b3733f80ed0dcd2c46207%2F67879152b691b6e350f34192_N5%20Oustanding%20Support-transcode.webm"
                                                data-autoplay="true" data-loop="true" data-wf-ignore="true"
                                                class="background-hero w-background-video w-background-video-atom">
                                                <video id="3dcfbf07-9b75-406b-ca07-64e1a2439f97-video" autoplay=""
                                                    loop=""
                                                    style="background-image:url(&quot;https://cdn.prod.website-files.com/668b3733f80ed0dcd2c46207%2F67879152b691b6e350f34192_N5%20Oustanding%20Support-poster-00001.jpg&quot;)"
                                                    muted="" playsinline="" data-wf-ignore="true"
                                                    data-object-fit="cover">
                                                    <source
                                                        src="https://cdn.prod.website-files.com/668b3733f80ed0dcd2c46207%2F67879152b691b6e350f34192_N5%20Oustanding%20Support-transcode.mp4"
                                                        data-wf-ignore="true" />
                                                    <source
                                                        src="https://cdn.prod.website-files.com/668b3733f80ed0dcd2c46207%2F67879152b691b6e350f34192_N5%20Oustanding%20Support-transcode.webm"
                                                        data-wf-ignore="true" />
                                                </video>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="splide__slide max-width-519 set-max-width-none">
                                <div class="border-16">
                                    <div class="hero-background-gif">
                                        <div class="background-video-wrapper">
                                            <div data-poster-url="https://cdn.prod.website-files.com/668b3733f80ed0dcd2c46207%2F678791580e1d70b9424c9692_N6%20White%20Label%20And%20Resell-poster-00001.jpg"
                                                data-video-urls="https://cdn.prod.website-files.com/668b3733f80ed0dcd2c46207%2F678791580e1d70b9424c9692_N6%20White%20Label%20And%20Resell-transcode.mp4,https://cdn.prod.website-files.com/668b3733f80ed0dcd2c46207%2F678791580e1d70b9424c9692_N6%20White%20Label%20And%20Resell-transcode.webm"
                                                data-autoplay="true" data-loop="true" data-wf-ignore="true"
                                                class="background-hero w-background-video w-background-video-atom">
                                                <video id="4d80c92d-2bb3-8789-8c6c-af0b92864d77-video" autoplay=""
                                                    loop=""
                                                    style="background-image:url(&quot;https://cdn.prod.website-files.com/668b3733f80ed0dcd2c46207%2F678791580e1d70b9424c9692_N6%20White%20Label%20And%20Resell-poster-00001.jpg&quot;)"
                                                    muted="" playsinline="" data-wf-ignore="true"
                                                    data-object-fit="cover">
                                                    <source
                                                        src="https://cdn.prod.website-files.com/668b3733f80ed0dcd2c46207%2F678791580e1d70b9424c9692_N6%20White%20Label%20And%20Resell-transcode.mp4"
                                                        data-wf-ignore="true" />
                                                    <source
                                                        src="https://cdn.prod.website-files.com/668b3733f80ed0dcd2c46207%2F678791580e1d70b9424c9692_N6%20White%20Label%20And%20Resell-transcode.webm"
                                                        data-wf-ignore="true" />
                                                </video>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="splide__slide max-width-519 set-max-width-none">
                                <div class="border-16">
                                    <div class="hero-background-gif">
                                        <div class="background-video-wrapper">
                                            <div data-poster-url="https://cdn.prod.website-files.com/668b3733f80ed0dcd2c46207%2F67879160c4d0d3d47aba6cf3_N7%20Up%20To%207%25%20Cashback-poster-00001.jpg"
                                                data-video-urls="https://cdn.prod.website-files.com/668b3733f80ed0dcd2c46207%2F67879160c4d0d3d47aba6cf3_N7%20Up%20To%207%25%20Cashback-transcode.mp4,https://cdn.prod.website-files.com/668b3733f80ed0dcd2c46207%2F67879160c4d0d3d47aba6cf3_N7%20Up%20To%207%25%20Cashback-transcode.webm"
                                                data-autoplay="true" data-loop="true" data-wf-ignore="true"
                                                class="background-hero w-background-video w-background-video-atom">
                                                <video id="5e043ffd-5316-d153-f763-4e8381477269-video" autoplay=""
                                                    loop=""
                                                    style="background-image:url(&quot;https://cdn.prod.website-files.com/668b3733f80ed0dcd2c46207%2F67879160c4d0d3d47aba6cf3_N7%20Up%20To%207%25%20Cashback-poster-00001.jpg&quot;)"
                                                    muted="" playsinline="" data-wf-ignore="true"
                                                    data-object-fit="cover">
                                                    <source
                                                        src="https://cdn.prod.website-files.com/668b3733f80ed0dcd2c46207%2F67879160c4d0d3d47aba6cf3_N7%20Up%20To%207%25%20Cashback-transcode.mp4"
                                                        data-wf-ignore="true" />
                                                    <source
                                                        src="https://cdn.prod.website-files.com/668b3733f80ed0dcd2c46207%2F67879160c4d0d3d47aba6cf3_N7%20Up%20To%207%25%20Cashback-transcode.webm"
                                                        data-wf-ignore="true" />
                                                </video>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="w-embed">
                    <style>
                        .marquee {
                            --gap: 0.5rem;
                            overflow: hidden;
                            user-select: none;
                        }

                        @keyframes scroll {
                            from {
                                transform: translateX(0);
                            }

                            to {
                                transform: translateX(calc(-100% - var(--gap)));
                            }
                        }

                        /* Enable animation */
                        .enable-animation .marquee__content {
                            animation: scroll 20s linear infinite;
                        }

                        /* Reverse animation */
                        .marquee--reverse .marquee__content {
                            animation-direction: reverse;
                        }

                        /* Pause on hover */
                        .marquee--hover-pause:hover .marquee__content {
                            animation-play-state: paused;
                        }

                        /* Attempt to size parent based on content. Keep in mind that the parent width is equal to both content containers that stretch to fill the parent. */
                        .marquee--fit-content {
                            max-width: fit-content;
                        }

                        /* A fit-content sizing fix: Absolute position the duplicate container. This will set the size of the parent wrapper to a single child container. Shout out to Olavi's article that had this solution 👏 @link: https://olavihaapala.fi/2021/02/23/modern-marquee.html  */
                        .marquee--pos-absolute .marquee__content:last-child {
                            position: absolute;
                            top: 0;
                            left: 0;
                        }

                        /* Enable position absolute animation on the duplicate content (last-child) */
                        .enable-animation .marquee--pos-absolute .marquee__content:last-child {
                            animation-name: scroll-abs;
                        }

                        @keyframes scroll-abs {
                            from {
                                transform: translateX(calc(100% + var(--gap)));
                            }

                            to {
                                transform: translateX(0);
                            }
                        }

                        .hero-payment-box.active .hero-dot-active {
                            opacity: 1;
                        }

                        [data-typing-item][data-appear="false"] {
                            transform: translateX(-20%);
                            opacity: 0;
                        }

                        .hero-mini-dashboard[data-appear="false"] {
                            transform: scale(0);
                        }

                        .hero-mini-dashboard[data-dashboard-image="1"][data-moving="true"] {
                            transform: translateX(-10%);
                        }

                        .hero-mini-dashboard[data-dashboard-image="2"][data-moving="true"] {
                            transform: translateY(10%);
                        }

                        .hero-mini-dashboard[data-dashboard-image="3"][data-moving="true"] {
                            transform: translateX(10%);
                        }

                        [data-transparent="here"] {
                            background-color: transparent;
                        }

                        [data-filter-color="here"] {
                            filter: brightness(0) saturate(100%) invert(100%) sepia(0%) saturate(0%) hue-rotate(277deg) brightness(102%) contrast(103%) opacity(10%);
                        }

                        [data-blink="here"] {
                            animation: blink 2.5s infinite;
                        }

                        [data-animation-rotate="here"] [data-animate-user-icon],
                        [data-animation-rotate="top"] [data-animate-user-icon] {
                            offset-path: inset(1rem);
                            animation: move 45s infinite linear;
                            animation-composition: accumulate;
                            offset-rotate: 0deg;
                            opacity: 1;
                            transition: all 200ms ease-in-out;
                        }

                        [data-animation-rotate="top"] [data-animate-user-icon] {
                            offset-path: inset(1.32rem);
                            animation: revMove 20s infinite linear;
                        }

                        rect {
                            transition: all 200ms ease-in-out;
                        }

                        @keyframes move {
                            0% {
                                offset-distance: 0%;
                            }

                            100% {
                                offset-distance: 100%;
                            }
                        }

                        @keyframes revMove {
                            0% {
                                offset-distance: 100%;
                            }

                            100% {
                                offset-distance: 0%;
                            }
                        }

                        @keyframes blink {
                            0% {
                                opacity: 1;
                            }

                            50% {
                                opacity: 0;
                            }

                            100% {
                                opacity: 1;
                            }
                        }

                        [data-hero-dots] {
                            -webkit-mask-image: url("https://cdn.prod.website-files.com/668b3733f80ed0dcd2c46207/671094277575f1b4b7eddfe5_dots.png");
                            mask-image: url("https://cdn.prod.website-files.com/668b3733f80ed0dcd2c46207/671094277575f1b4b7eddfe5_dots.png");
                            mask-repeat: no-repeat;
                            mask-position: center bottom;
                            background: rgb(149 152 159, 0.6);
                            position: relative;
                        }

                        [data-hero-dots]:after {
                            content: '';
                            top: 0;
                            transform: translateX(100%);
                            width: 100%;
                            height: 100%;
                            position: absolute;
                            z-index: 1;
                            animation: gradientDown 5s infinite;
                            /* 
CSS Gradient - complete browser support from http://www.colorzilla.com/gradient-editor/ 
*/
                            background: rgba(255, 255, 255, 0.13);
                            background: linear-gradient(to bottom,
                                    rgba(255, 255, 255, 0.13) 0%,
                                    rgba(255, 255, 255, 0.25) 50%,
                                    rgba(255, 255, 255, 0.5) 77%,
                                    rgba(255, 255, 255, 1) 80%,
                                    rgba(255, 255, 255, 0.0) 100%);
                            /* W3C */
                            filter: progid:DXImageTransform.Microsoft.gradient(startColorstr='#00ffffff', endColorstr='#007db9e8', GradientType=1);
                            /* IE6-9 */
                        }

                        @keyframes gradientDown {
                            0% {
                                transform: translateY(-100%);
                            }

                            100% {
                                transform: translateY(20%);
                            }
                        }

                        [data-adjust-box="32"] {
                            height: calc(100% + 2.5rem);
                        }

                        .position-absolute.full:has([data-adjust-box="32"]) {
                            align-items: flex-end;
                        }

                        .hero-item-frame {
                            animation: updown 5s infinite linear;
                        }

                        [data-cashback-notification] {
                            transition: all 200ms ease-in-out;
                        }

                        [data-cashback-notification][data-appear="false"] {
                            transform: scale(0);
                        }

                        .hero-item-frame.reverse {
                            animation: downup 5s infinite linear;
                        }

                        @keyframes updown {

                            0%,
                            100% {
                                transform: translateY(25px);
                            }

                            50% {
                                transform: translateY(0px);
                            }
                        }

                        @keyframes downup {

                            0%,
                            100% {
                                transform: translateY(0px);
                            }

                            50% {
                                transform: translateY(25px);
                            }
                        }
                    </style>
                </div>
            </div>
        </div>
    </div>
</div>


            </div>


            

<div class="section-group_home-globe">
    <div class="section_home-infrastracture">
        <div class="padding-global">
            <div class="container-1600">
                <div class="infrastracture-component">
                    <div class="infrastracture-block">
                        <div class="margin-bottom-88 set-margin-bottom-64">
                            <div class="header-section">
                                <div class="header-tag">
                                    <div>Advertising solutions</div>
                                </div>
                                <h2 class="text-color-gray-200">Advertising infrastructure for unlimited growth</h2>
                                <div
                                    class="text-size-20 text-color-gray-300 text-weight-medium set-text-size-18 set-text-weight-regular">
                                    Grow revenue, reduce restrictions and scale your business effortlessly with an entire suite of advertising solutions.</div>
                                <div class="button-wrapper"><a href="/solutions/features"
                                        class="blank-button w-inline-block">
                                        <div class="position-relative">
                                            <div>Learn more</div>
                                            <div class="button-bottom-line"></div>
                                        </div>
                                        <div class="embed w-embed"><svg width="24" height="24" viewBox="0 0 24 24"
                                                fill="none" xmlns="http://www.w3.org/2000/svg">
                                                <path d="M5 12H19M19 12L12 5M19 12L12 19" stroke="currentColor"
                                                    stroke-width="2" stroke-linecap="round" stroke-linejoin="round" />
                                            </svg></div>
                                    </a></div>
                            </div>
                        </div><a href="#" class="infrastracture-box w-inline-block">
                            <div class="ad-bg-box"></div>
                            <div class="infra-box rev">
                                <div class="max-width-455">
                                    <div class="margin-bottom-8">
                                        <h3>Whitelisted ad accounts</h3>
                                    </div>
                                    <div class="text-color-gray-300">Experience the scaling potential of unrestricted spending, compliant advertising and direct, hands-on support from dedicated account managers.</div>
                                </div>
                                <div class="max-width-232 max-width-none"><img
                                        src="https://cdn.prod.website-files.com/668b3733f80ed0dcd2c46207/668b8fa119fb58090e6d17cd_logos.svg"
                                        loading="lazy" alt="" class="hide" />
                                    <div class="whitelist-box">
                                        <div class="whitelist-aurora-box">
                                            <div class="embed w-embed">
                                                <img src="assets/logo.png" width="142" alt="Logo" class="logo-image">
                                            </div>
                                        </div>
                                        <div class="whitelist-logo-box _1">
                                            <div class="embed w-embed"><svg width="50" height="50" viewBox="0 0 50 50"
                                                    fill="none" xmlns="http://www.w3.org/2000/svg">
                                                    <g filter="url(#filter0_b_3928_143956)">
                                                        <path
                                                            d="M9 0.5C4.30558 0.5 0.5 4.30558 0.5 9V41C0.5 45.6944 4.30558 49.5 9 49.5H41C45.6944 49.5 49.5 45.6944 49.5 41V9C49.5 4.30558 45.6944 0.5 41 0.5H9Z"
                                                            stroke="#344054" />
                                                        <path
                                                            d="M16.6065 13L21.4007 14.6866V31.562L28.1535 27.6638L24.8427 26.1104L22.754 20.9117L33.3939 24.6497V30.0841L21.4034 37L16.6064 34.3317L16.6065 13Z"
                                                            fill="white" />
                                                    </g>
                                                    <defs>
                                                        <filter id="filter0_b_3928_143956" x="-8" y="-8" width="66"
                                                            height="66" filterUnits="userSpaceOnUse"
                                                            color-interpolation-filters="sRGB">
                                                            <feFlood flood-opacity="0" result="BackgroundImageFix" />
                                                            <feGaussianBlur in="BackgroundImageFix" stdDeviation="4" />
                                                            <feComposite in2="SourceAlpha" operator="in"
                                                                result="effect1_backgroundBlur_3928_143956" />
                                                            <feBlend mode="normal" in="SourceGraphic"
                                                                in2="effect1_backgroundBlur_3928_143956"
                                                                result="shape" />
                                                        </filter>
                                                    </defs>
                                                </svg></div>
                                        </div>
                                        <div class="whitelist-logo-box _2">
                                            <div class="embed w-embed"><svg width="50" height="50" viewBox="0 0 50 50"
                                                    fill="none" xmlns="http://www.w3.org/2000/svg">
                                                    <g filter="url(#filter0_b_3928_143942)">
                                                        <path
                                                            d="M9 0.5C4.30558 0.5 0.5 4.30558 0.5 9V41C0.5 45.6944 4.30558 49.5 9 49.5H41C45.6944 49.5 49.5 45.6944 49.5 41V9C49.5 4.30558 45.6944 0.5 41 0.5H9Z"
                                                            stroke="#344054" />
                                                        <path
                                                            d="M36.0837 30.9874C32.0835 29.0509 31.4459 26.0611 31.4175 25.8394C31.3832 25.5707 31.3443 25.3595 31.6406 25.0863C31.9264 24.8223 33.1943 24.0376 33.546 23.792C34.1275 23.3855 34.3836 22.9796 34.1948 22.4806C34.0628 22.1354 33.7414 22.0054 33.4028 22.0054C33.296 22.0058 33.1896 22.0177 33.0854 22.0411C32.4465 22.1797 31.8261 22.4998 31.467 22.5862C31.4239 22.5973 31.3796 22.6033 31.335 22.604C31.1436 22.604 31.071 22.5189 31.0895 22.2886C31.1344 21.5903 31.2294 20.2274 31.1192 18.9542C30.9681 17.2026 30.4031 16.3347 29.7332 15.5671C29.4092 15.1949 27.9044 13.5957 25.0003 13.5957C22.0963 13.5957 20.5935 15.1949 20.2715 15.5625C19.5996 16.3301 19.0353 17.198 18.8855 18.9496C18.7752 20.2228 18.8742 21.585 18.9152 22.2839C18.9284 22.5031 18.861 22.5994 18.6696 22.5994C18.6251 22.5987 18.5808 22.5927 18.5376 22.5816C18.1793 22.4951 17.5589 22.175 16.92 22.0364C16.8158 22.0131 16.7093 22.0011 16.6025 22.0008C16.2626 22.0008 15.9425 22.1328 15.8105 22.476C15.6218 22.975 15.8765 23.3809 16.4599 23.7874C16.8117 24.0329 18.0796 24.817 18.3654 25.0817C18.6611 25.3549 18.6228 25.5661 18.5885 25.8347C18.5601 26.0598 17.9219 29.0496 13.9222 30.9827C13.6879 31.0963 13.2893 31.3365 13.9922 31.7246C15.0957 32.3344 15.8303 32.2691 16.4012 32.6367C16.8857 32.9489 16.5992 33.6221 16.9517 33.865C17.3846 34.1639 18.6644 33.8438 20.3177 34.3897C21.7037 34.8464 22.5458 36.1367 25.0037 36.1367C27.4615 36.1367 28.3281 34.8404 29.6896 34.3897C31.3397 33.8438 32.622 34.1639 33.0557 33.865C33.4074 33.6221 33.1217 32.9489 33.6061 32.6367C34.177 32.2691 34.9109 32.3344 36.0151 31.7246C36.7167 31.3411 36.318 31.1009 36.0837 30.9874Z"
                                                            fill="white" />
                                                    </g>
                                                    <defs>
                                                        <filter id="filter0_b_3928_143942" x="-8" y="-8" width="66"
                                                            height="66" filterUnits="userSpaceOnUse"
                                                            color-interpolation-filters="sRGB">
                                                            <feFlood flood-opacity="0" result="BackgroundImageFix" />
                                                            <feGaussianBlur in="BackgroundImageFix" stdDeviation="4" />
                                                            <feComposite in2="SourceAlpha" operator="in"
                                                                result="effect1_backgroundBlur_3928_143942" />
                                                            <feBlend mode="normal" in="SourceGraphic"
                                                                in2="effect1_backgroundBlur_3928_143942"
                                                                result="shape" />
                                                        </filter>
                                                    </defs>
                                                </svg></div>
                                        </div>
                                        <div class="whitelist-logo-box _3">
                                            <div class="embed w-embed"><svg width="50" height="50" viewBox="0 0 50 50"
                                                    fill="none" xmlns="http://www.w3.org/2000/svg">
                                                    <g filter="url(#filter0_b_3928_143950)">
                                                        <path
                                                            d="M9 0.5C4.30558 0.5 0.5 4.30558 0.5 9V41C0.5 45.6944 4.30558 49.5 9 49.5H41C45.6944 49.5 49.5 45.6944 49.5 41V9C49.5 4.30558 45.6944 0.5 41 0.5H9Z"
                                                            stroke="#344054" />
                                                        <path
                                                            d="M19.4405 18.8881C17.7379 18.8774 17.5008 20.5339 17.4933 21.7817C17.4869 23.0294 17.7036 24.7116 19.4051 24.7213C21.1067 24.731 21.3449 23.053 21.3524 21.8031C21.3599 20.5554 21.1421 18.8978 19.4405 18.8881ZM19.3869 27.9892C14.9603 27.9635 12.9798 25.0238 13.0002 21.7559C13.0195 18.4869 15.0322 15.5945 19.4588 15.6213C23.8854 15.646 25.8659 18.562 25.8466 21.831C25.8262 25.0979 23.8135 28.015 19.3869 27.9892Z"
                                                            fill="white" />
                                                        <path
                                                            d="M30.5938 18.8873C28.8922 18.8765 28.6551 20.533 28.6487 21.7818C28.6401 23.0296 28.8579 24.7107 30.5605 24.7204C32.261 24.7311 32.4992 23.0521 32.5067 21.8033C32.5131 20.5556 32.2953 18.8969 30.5938 18.8873ZM30.5401 27.9894C26.1146 27.9626 24.1341 25.023 24.1545 21.755C24.1727 18.4871 26.1865 15.5936 30.612 15.6193C35.0376 15.6451 37.0181 18.5611 36.9998 21.829C36.9805 25.0991 34.9668 28.0141 30.5401 27.9894Z"
                                                            fill="white" />
                                                        <path
                                                            d="M14.6857 27.9902C17.8764 29.4161 21.1873 30.0491 24.7953 30.0694C28.5857 30.092 31.4599 29.3764 35.098 27.9902L35.0765 31.9169C31.8204 33.5316 28.2885 34.4027 24.7695 34.3823C20.9341 34.3598 18.1704 33.5723 14.6621 31.9169L14.6857 27.9902Z"
                                                            fill="white" />
                                                    </g>
                                                    <defs>
                                                        <filter id="filter0_b_3928_143950" x="-8" y="-8" width="66"
                                                            height="66" filterUnits="userSpaceOnUse"
                                                            color-interpolation-filters="sRGB">
                                                            <feFlood flood-opacity="0" result="BackgroundImageFix" />
                                                            <feGaussianBlur in="BackgroundImageFix" stdDeviation="4" />
                                                            <feComposite in2="SourceAlpha" operator="in"
                                                                result="effect1_backgroundBlur_3928_143950" />
                                                            <feBlend mode="normal" in="SourceGraphic"
                                                                in2="effect1_backgroundBlur_3928_143950"
                                                                result="shape" />
                                                        </filter>
                                                    </defs>
                                                </svg></div>
                                        </div>
                                        <div class="whitelist-logo-box _4">
                                            <div class="embed w-embed"><svg width="50" height="50" viewBox="0 0 50 50"
                                                    fill="none" xmlns="http://www.w3.org/2000/svg">
                                                    <g filter="url(#filter0_b_3928_143925)">
                                                        <path
                                                            d="M9 0.5C4.30558 0.5 0.5 4.30558 0.5 9V41C0.5 45.6944 4.30558 49.5 9 49.5H41C45.6944 49.5 49.5 45.6944 49.5 41V9C49.5 4.30558 45.6944 0.5 41 0.5H9Z"
                                                            stroke="#344054" />
                                                        <g clip-path="url(#clip0_3928_143925)">
                                                            <path
                                                                d="M25.3321 20.3776C23.378 17.8895 21.7439 16.9414 19.7882 16.9414C15.801 16.9414 12.7461 22.1303 12.7461 27.6224C12.7461 31.0593 14.4088 33.2269 17.1937 33.2269C19.1982 33.2269 20.6397 32.282 23.2024 27.8022C23.2024 27.8022 24.2708 25.9157 25.0057 24.6161C25.2632 25.0319 25.5339 25.4792 25.8193 25.9601L27.0212 27.9818C29.3621 31.8993 30.6665 33.2269 33.0299 33.2269C35.7431 33.2269 37.2529 31.0296 37.2529 27.5214C37.2529 21.7709 34.1292 16.9414 30.3343 16.9414C28.3249 16.9414 26.7541 18.455 25.3321 20.3776ZM29.0901 26.1792L27.6532 23.7828C27.2645 23.1504 26.8919 22.5692 26.5323 22.0365C27.8272 20.0376 28.8955 19.0417 30.1659 19.0417C32.8053 19.0417 34.9169 22.9278 34.9169 27.7011C34.9169 29.5205 34.3208 30.5763 33.0861 30.5763C31.9026 30.5763 31.3372 29.7947 29.0901 26.1792ZM15.3966 27.6673C15.3966 23.6802 17.3846 19.6033 19.7545 19.6033C21.0378 19.6033 22.1102 20.3444 23.7529 22.696C22.1931 25.0885 21.2482 26.5891 21.2482 26.5891C19.1705 29.8462 18.4516 30.5763 17.2949 30.5763C16.1042 30.5763 15.3966 29.5311 15.3966 27.6673Z"
                                                                fill="white" />
                                                        </g>
                                                    </g>
                                                    <defs>
                                                        <filter id="filter0_b_3928_143925" x="-8" y="-8" width="66"
                                                            height="66" filterUnits="userSpaceOnUse"
                                                            color-interpolation-filters="sRGB">
                                                            <feFlood flood-opacity="0" result="BackgroundImageFix" />
                                                            <feGaussianBlur in="BackgroundImageFix" stdDeviation="4" />
                                                            <feComposite in2="SourceAlpha" operator="in"
                                                                result="effect1_backgroundBlur_3928_143925" />
                                                            <feBlend mode="normal" in="SourceGraphic"
                                                                in2="effect1_backgroundBlur_3928_143925"
                                                                result="shape" />
                                                        </filter>
                                                        <clipPath id="clip0_3928_143925">
                                                            <rect width="25" height="17" fill="white"
                                                                transform="translate(12.5 16.5)" />
                                                        </clipPath>
                                                    </defs>
                                                </svg></div>
                                        </div>
                                        <div class="whitelist-logo-box _5">
                                            <div class="embed w-embed"><svg width="50" height="50" viewBox="0 0 50 50"
                                                    fill="none" xmlns="http://www.w3.org/2000/svg">
                                                    <g filter="url(#filter0_b_3928_143921)">
                                                        <path
                                                            d="M9 0.5C4.30558 0.5 0.5 4.30558 0.5 9V41C0.5 45.6944 4.30558 49.5 9 49.5H41C45.6944 49.5 49.5 45.6944 49.5 41V9C49.5 4.30558 45.6944 0.5 41 0.5H9Z"
                                                            stroke="#344054" />
                                                        <path
                                                            d="M32.3214 18.5622C32.1695 18.4837 32.0217 18.3977 31.8784 18.3044C31.4618 18.029 31.0799 17.7044 30.7408 17.3378C29.8923 16.367 29.5754 15.3822 29.4587 14.6927H29.4634C29.3659 14.1203 29.4062 13.75 29.4123 13.75H25.5479V28.6928C25.5479 28.8934 25.5479 29.0917 25.5395 29.2877C25.5395 29.312 25.5372 29.3345 25.5358 29.3608C25.5358 29.3716 25.5358 29.3828 25.5334 29.3941C25.5334 29.3969 25.5334 29.3997 25.5334 29.4025C25.4927 29.9386 25.3208 30.4566 25.0329 30.9107C24.7451 31.3648 24.35 31.7413 23.8825 32.0069C23.3952 32.2841 22.8441 32.4295 22.2836 32.4288C20.4831 32.4288 19.0239 30.9606 19.0239 29.1475C19.0239 27.3344 20.4831 25.8663 22.2836 25.8663C22.6244 25.8659 22.9631 25.9196 23.2872 26.0252L23.2918 22.0905C22.3081 21.9634 21.3087 22.0416 20.3567 22.3201C19.4047 22.5986 18.5207 23.0714 17.7606 23.7086C17.0945 24.2873 16.5346 24.9778 16.1059 25.7491C15.9428 26.0303 15.3273 27.1605 15.2528 28.9947C15.2059 30.0358 15.5186 31.1144 15.6676 31.5602V31.5695C15.7614 31.832 16.1247 32.7278 16.7167 33.483C17.1941 34.0887 17.7581 34.6208 18.3906 35.0622V35.0528L18.4 35.0622C20.2708 36.3334 22.345 36.25 22.345 36.25C22.704 36.2355 23.9068 36.25 25.2728 35.6027C26.7878 34.885 27.6503 33.8158 27.6503 33.8158C28.2013 33.1769 28.6394 32.4488 28.9459 31.6628C29.2956 30.7436 29.4123 29.6411 29.4123 29.2005V21.273C29.4592 21.3011 30.0836 21.7141 30.0836 21.7141C30.0836 21.7141 30.9831 22.2906 32.3865 22.6661C33.3934 22.9333 34.75 22.9895 34.75 22.9895V19.1533C34.2747 19.2048 33.3095 19.0548 32.3214 18.5622Z"
                                                            fill="white" />
                                                    </g>
                                                    <defs>
                                                        <filter id="filter0_b_3928_143921" x="-8" y="-8" width="66"
                                                            height="66" filterUnits="userSpaceOnUse"
                                                            color-interpolation-filters="sRGB">
                                                            <feFlood flood-opacity="0" result="BackgroundImageFix" />
                                                            <feGaussianBlur in="BackgroundImageFix" stdDeviation="4" />
                                                            <feComposite in2="SourceAlpha" operator="in"
                                                                result="effect1_backgroundBlur_3928_143921" />
                                                            <feBlend mode="normal" in="SourceGraphic"
                                                                in2="effect1_backgroundBlur_3928_143921"
                                                                result="shape" />
                                                        </filter>
                                                    </defs>
                                                </svg></div>
                                        </div>
                                        <div class="whitelist-logo-box _7">
                                            <div class="embed w-embed"><svg width="50" height="50" viewBox="0 0 50 50"
                                                    fill="none" xmlns="http://www.w3.org/2000/svg">
                                                    <g filter="url(#filter0_b_3928_143947)">
                                                        <path
                                                            d="M9 0.5C4.30558 0.5 0.5 4.30558 0.5 9V41C0.5 45.6944 4.30558 49.5 9 49.5H41C45.6944 49.5 49.5 45.6944 49.5 41V9C49.5 4.30558 45.6944 0.5 41 0.5H9Z"
                                                            stroke="#344054" />
                                                        <path fill-rule="evenodd" clip-rule="evenodd"
                                                            d="M30.5962 33.0521C29.8876 33.7572 29.0576 34.3082 28.1051 34.7095C27.1526 35.1075 26.1171 35.3071 25.0005 35.3071C23.8829 35.3071 22.8485 35.1075 21.8971 34.7095C20.9435 34.3082 20.1124 33.7572 19.4038 33.0521C18.6952 32.3492 18.1397 31.5177 17.7394 30.5588C17.3523 29.633 17.1533 28.6319 17.1391 27.5576H19.0232C19.0429 27.888 19.1129 28.1973 19.2343 28.4878C19.3797 28.837 19.582 29.1386 19.8379 29.3936C20.0949 29.6497 20.3978 29.8503 20.7434 29.9933C21.0889 30.1397 21.4651 30.2129 21.8708 30.2129C22.2765 30.2129 22.6505 30.1397 22.9972 29.9933C23.3427 29.8503 23.6456 29.6497 23.9026 29.3936C24.1596 29.1386 24.3619 28.837 24.5063 28.4878C24.6036 28.2583 24.667 28.0144 24.6987 27.7594H25.3024C25.3341 28.0144 25.3975 28.2583 25.4948 28.4878C25.6414 28.837 25.8415 29.1386 26.0996 29.3936C26.3554 29.6497 26.6584 29.8503 27.0039 29.9933C27.3495 30.1397 27.7257 30.2129 28.1303 30.2129C28.5371 30.2129 28.9122 30.1397 29.2577 29.9933C29.6033 29.8503 29.9062 29.6497 30.1632 29.3936C30.4201 29.1386 30.6225 28.837 30.7679 28.4878C30.8893 28.1973 30.9593 27.888 30.98 27.5576H32.8598C32.8489 28.6319 32.6488 29.633 32.2617 30.5588C31.8603 31.5177 31.3048 32.3492 30.5962 33.0521ZM23.5658 27.357C23.5658 27.5987 23.5221 27.8226 23.4368 28.0299C23.3504 28.235 23.2312 28.4135 23.077 28.5665C22.9228 28.7195 22.7446 28.8381 22.5401 28.9235C22.3334 29.01 22.1114 29.0532 21.8708 29.0532C21.6292 29.0532 21.4061 29.01 21.2005 28.9235C20.996 28.8381 20.8166 28.7195 20.6636 28.5665C20.5094 28.4135 20.3902 28.235 20.3049 28.0299C20.2185 27.8226 20.1747 27.5987 20.1747 27.357C20.1747 27.1175 20.2185 26.8925 20.3049 26.6851C20.3902 26.4789 20.5094 26.3004 20.6636 26.1474C20.8166 25.9967 20.996 25.8769 21.2005 25.7916C21.4061 25.7051 21.6292 25.6619 21.8708 25.6619C22.1114 25.6619 22.3334 25.7051 22.5401 25.7916C22.7446 25.8769 22.9228 25.9967 23.077 26.1474C23.2312 26.3004 23.3504 26.4789 23.4368 26.6851C23.5221 26.8925 23.5658 27.1175 23.5658 27.357ZM29.8264 27.357C29.8264 27.5987 29.7837 27.8226 29.6962 28.0299C29.6109 28.235 29.4906 28.4135 29.3386 28.5665C29.1855 28.7195 29.0051 28.8381 28.7995 28.9235C28.595 29.01 28.3719 29.0532 28.1303 29.0532C27.8897 29.0532 27.6666 29.01 27.4621 28.9235C27.2554 28.8381 27.0761 28.7195 26.9241 28.5665C26.771 28.4135 26.6518 28.235 26.5643 28.0299C26.4779 27.8226 26.4353 27.5987 26.4353 27.357C26.4353 27.1175 26.4779 26.8925 26.5643 26.6851C26.6518 26.4789 26.771 26.3004 26.9241 26.1474C27.0761 25.9967 27.2554 25.8769 27.4621 25.7916C27.6666 25.7051 27.8897 25.6619 28.1303 25.6619C28.3719 25.6619 28.595 25.7051 28.7995 25.7916C29.0051 25.8769 29.1855 25.9967 29.3386 26.1474C29.4906 26.3004 29.6109 26.4789 29.6962 26.6851C29.7837 26.8925 29.8264 27.1175 29.8264 27.357ZM17.8389 24.1208C19.1763 23.6741 20.9501 23.1042 20.9501 23.1042C24.8518 21.8459 25.3745 20.3581 25.3745 20.3581C25.3745 20.3581 26.1958 21.8459 29.0281 22.827C29.0281 22.827 30.5929 23.3492 32.0484 23.8825C32.1217 24.0288 32.1972 24.1752 32.2617 24.3304C32.5176 24.9424 32.6914 25.5876 32.7833 26.2627H30.781L30.7679 26.2273C30.6225 25.878 30.4201 25.5776 30.1632 25.3215C29.9062 25.0654 29.6033 24.8647 29.2577 24.7195C28.9122 24.5754 28.5371 24.5033 28.1303 24.5033C27.7257 24.5033 27.3495 24.5754 27.0039 24.7195C26.6584 24.8647 26.3554 25.0654 26.0996 25.3215C25.8415 25.5776 25.6414 25.878 25.4948 26.2273C25.4489 26.337 25.4106 26.449 25.3789 26.5632H24.6222C24.5916 26.449 24.5533 26.337 24.5063 26.2273C24.3619 25.878 24.1596 25.5776 23.9026 25.3215C23.6456 25.0654 23.3427 24.8647 22.9972 24.7195C22.6505 24.5754 22.2765 24.5033 21.8708 24.5033C21.4651 24.5033 21.0889 24.5754 20.7434 24.7195C20.3978 24.8647 20.0949 25.0654 19.8379 25.3215C19.582 25.5776 19.3797 25.878 19.2343 26.2273C19.2288 26.2384 19.2255 26.2506 19.2201 26.2627H17.2189C17.3107 25.5876 17.4835 24.9424 17.7394 24.3304C17.77 24.2583 17.8072 24.1918 17.8389 24.1208ZM36.0836 20.2461C35.4701 18.7838 34.6248 17.5155 33.5411 16.4412C32.4596 15.3647 31.1922 14.5233 29.7389 13.9146C28.2845 13.3049 26.7054 13 25.0005 13C23.2957 13 21.7166 13.3049 20.2622 13.9146C18.8089 14.5233 17.5404 15.3647 16.4589 16.4412C15.3774 17.5155 14.5299 18.7838 13.9186 20.2461C13.3051 21.7095 13 23.2949 13 25C13 26.7073 13.3051 28.2905 13.9186 29.7539C14.5299 31.2173 15.3774 32.4845 16.4589 33.5599C17.5404 34.6353 18.8089 35.4767 20.2622 36.0865C21.7166 36.6951 23.2957 37 25.0005 37C26.7054 37 28.2845 36.6951 29.7389 36.0865C31.1922 35.4767 32.4596 34.6353 33.5411 33.5599C34.6248 32.4845 35.4701 31.2173 36.0836 29.7539C36.6938 28.2905 37 26.7073 37 25C37 23.2949 36.6938 21.7095 36.0836 20.2461Z"
                                                            fill="white" />
                                                    </g>
                                                    <defs>
                                                        <filter id="filter0_b_3928_143947" x="-8" y="-8" width="66"
                                                            height="66" filterUnits="userSpaceOnUse"
                                                            color-interpolation-filters="sRGB">
                                                            <feFlood flood-opacity="0" result="BackgroundImageFix" />
                                                            <feGaussianBlur in="BackgroundImageFix" stdDeviation="4" />
                                                            <feComposite in2="SourceAlpha" operator="in"
                                                                result="effect1_backgroundBlur_3928_143947" />
                                                            <feBlend mode="normal" in="SourceGraphic"
                                                                in2="effect1_backgroundBlur_3928_143947"
                                                                result="shape" />
                                                        </filter>
                                                    </defs>
                                                </svg></div>
                                        </div>
                                        <div class="whitelist-logo-box _6">
                                            <div class="embed w-embed"><svg width="50" height="50" viewBox="0 0 50 50"
                                                    fill="none" xmlns="http://www.w3.org/2000/svg">
                                                    <g filter="url(#filter0_b_3928_143933)">
                                                        <path
                                                            d="M9 0.5C4.30558 0.5 0.5 4.30558 0.5 9V41C0.5 45.6944 4.30558 49.5 9 49.5H41C45.6944 49.5 49.5 45.6944 49.5 41V9C49.5 4.30558 45.6944 0.5 41 0.5H9Z"
                                                            stroke="#344054" />
                                                        <path fill-rule="evenodd" clip-rule="evenodd"
                                                            d="M35.8805 25.2576C35.8805 24.454 35.8084 23.6813 35.6744 22.9395H25.0005V27.3234H31.0999C30.8372 28.7401 30.0387 29.9404 28.8384 30.744V33.5877H32.5011C34.6441 31.6146 35.8805 28.7092 35.8805 25.2576Z"
                                                            fill="white" />
                                                        <path fill-rule="evenodd" clip-rule="evenodd"
                                                            d="M24.9995 36.3324C28.0595 36.3324 30.6249 35.3175 32.5001 33.5866L28.8374 30.743C27.8225 31.423 26.5243 31.8248 24.9995 31.8248C22.0477 31.8248 19.5492 29.8311 18.658 27.1523H14.8716V30.0887C16.7364 33.7927 20.5692 36.3324 24.9995 36.3324Z"
                                                            fill="white" />
                                                        <path fill-rule="evenodd" clip-rule="evenodd"
                                                            d="M18.6583 27.1532C18.4317 26.4732 18.3029 25.7468 18.3029 24.9999C18.3029 24.2529 18.4317 23.5265 18.6583 22.8465V19.9102H14.872C14.1044 21.4402 13.6665 23.1711 13.6665 24.9999C13.6665 26.8287 14.1044 28.5596 14.872 30.0896L18.6583 27.1532Z"
                                                            fill="white" />
                                                        <path fill-rule="evenodd" clip-rule="evenodd"
                                                            d="M24.9995 18.1736C26.6634 18.1736 28.1574 18.7454 29.3319 19.8685L32.5825 16.6178C30.6198 14.789 28.0543 13.666 24.9995 13.666C20.5692 13.666 16.7364 16.2057 14.8716 19.9097L18.658 22.846C19.5492 20.1672 22.0477 18.1736 24.9995 18.1736Z"
                                                            fill="white" />
                                                    </g>
                                                    <defs>
                                                        <filter id="filter0_b_3928_143933" x="-8" y="-8" width="66"
                                                            height="66" filterUnits="userSpaceOnUse"
                                                            color-interpolation-filters="sRGB">
                                                            <feFlood flood-opacity="0" result="BackgroundImageFix" />
                                                            <feGaussianBlur in="BackgroundImageFix" stdDeviation="4" />
                                                            <feComposite in2="SourceAlpha" operator="in"
                                                                result="effect1_backgroundBlur_3928_143933" />
                                                            <feBlend mode="normal" in="SourceGraphic"
                                                                in2="effect1_backgroundBlur_3928_143933"
                                                                result="shape" />
                                                        </filter>
                                                    </defs>
                                                </svg></div>
                                        </div>
                                    </div>
                                </div>
                                <div class="ad-button-wrapper">
                                    <div class="infra-button">
                                        <div class="fix-24">
                                            <div data-button-icon="hover" class="embed w-embed"><svg width="24"
                                                    height="24" viewBox="0 0 24 24" fill="none"
                                                    xmlns="http://www.w3.org/2000/svg">
                                                    <path d="M5 12H19M19 12L12 5M19 12L12 19" stroke="currentColor"
                                                        stroke-width="2" stroke-linecap="round"
                                                        stroke-linejoin="round" />
                                                </svg></div>
                                            <div data-button-icon="normal" class="embed w-embed"><svg width="24"
                                                    height="24" viewBox="0 0 24 24" fill="none"
                                                    xmlns="http://www.w3.org/2000/svg">
                                                    <path d="M9 18L15 12L9 6" stroke="white" stroke-width="2"
                                                        stroke-linecap="round" stroke-linejoin="round" />
                                                </svg></div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </a>
                    </div>
                    <div class="infrastracture-block">
                        <div class="infrastracture-list-block"><a href="#" class="infrastracture-box w-inline-block">
                                <div class="ad-bg-box"></div>
                                <div class="infra-box _24 _2">
                                    <div data-show="false" data-whitelist-content="second" class="hide">
                                        <div class="margin-bottom-8">
                                            <div class="text-size-12 text-color-gray-300">Up to</div>
                                        </div>
                                        <div class="percent-box">
                                            <div data-whitelist-number="7" class="percent-text">7</div>
                                            <div class="embed hide-this w-embed"><svg width="94" height="48"
                                                    viewBox="0 0 94 48" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                    <path fill-rule="evenodd" clip-rule="evenodd"
                                                        d="M79.726 0.749022L42.0251 47.251H50.7638L88.4647 0.749022H79.726ZM43.0238 22.7204C44.8964 23.8023 46.977 24.3433 49.2657 24.3433C51.596 24.3433 53.6766 23.8023 55.5076 22.7204C57.3385 21.5969 58.795 20.1196 59.8769 18.2887C60.9588 16.4577 61.4998 14.4187 61.4998 12.1716C61.4998 9.92457 60.9588 7.88556 59.8769 6.05462C58.795 4.18205 57.3385 2.70481 55.5076 1.62289C53.6766 0.540963 51.596 0 49.2657 0C46.977 0 44.8964 0.540963 43.0238 1.62289C41.1929 2.70481 39.7364 4.18205 38.6545 6.05462C37.5726 7.88556 37.0316 9.92457 37.0316 12.1716C37.0316 14.4187 37.5726 16.4577 38.6545 18.2887C39.7364 20.1196 41.1929 21.5969 43.0238 22.7204ZM52.3866 17.2276C51.5544 17.7685 50.5141 18.039 49.2657 18.039C48.1006 18.039 47.0811 17.7685 46.2072 17.2276C45.3749 16.645 44.7299 15.896 44.2722 14.9805C43.8145 14.065 43.5856 13.1287 43.5856 12.1716C43.5856 11.173 43.8145 10.2367 44.2722 9.36281C44.7299 8.44733 45.3749 7.69831 46.2072 7.11574C47.0811 6.53316 48.1006 6.24187 49.2657 6.24187C50.5141 6.24187 51.5544 6.53316 52.3866 7.11574C53.2189 7.69831 53.8431 8.42653 54.2592 9.30039C54.7169 10.1743 54.9458 11.1313 54.9458 12.1716C54.9458 13.1703 54.7169 14.1274 54.2592 15.0429C53.8431 15.9168 53.2189 16.645 52.3866 17.2276ZM74.7325 46.3771C76.6051 47.459 78.6857 48 80.9744 48C83.3047 48 85.3853 47.459 87.2163 46.3771C89.0472 45.2536 90.5037 43.7763 91.5856 41.9454C92.6675 40.1144 93.2085 38.0754 93.2085 35.8283C93.2085 33.5813 92.6675 31.5423 91.5856 29.7113C90.5037 27.8387 89.0472 26.3615 87.2163 25.2796C85.3853 24.1977 83.3047 23.6567 80.9744 23.6567C78.6857 23.6567 76.6051 24.1977 74.7325 25.2796C72.9016 26.3615 71.4452 27.8387 70.3632 29.7113C69.2813 31.5423 68.7403 33.5813 68.7403 35.8283C68.7403 38.0754 69.2813 40.1144 70.3632 41.9454C71.4452 43.7763 72.9016 45.2536 74.7325 46.3771ZM84.0329 40.8843C83.2007 41.4252 82.1812 41.6957 80.9744 41.6957C79.8093 41.6957 78.7898 41.4252 77.9159 40.8843C77.0837 40.3017 76.4387 39.5527 75.9809 38.6372C75.5232 37.7217 75.2943 36.7854 75.2943 35.8283C75.2943 34.8296 75.5232 33.8934 75.9809 33.0195C76.4387 32.104 77.0837 31.355 77.9159 30.7724C78.7898 30.1899 79.8093 29.8986 80.9744 29.8986C82.1812 29.8986 83.2007 30.1899 84.0329 30.7724C84.9068 31.355 85.5518 32.0832 85.9679 32.9571C86.4257 33.8309 86.6545 34.788 86.6545 35.8283C86.6545 36.827 86.4257 37.7841 85.9679 38.6996C85.5518 39.5735 84.9068 40.3017 84.0329 40.8843ZM22.7006 7.92711L3.35078 47.2509H12.7136L31.6265 7.92711V0.748954H0.791607V7.92711H22.7006Z"
                                                        fill="#E9394B" />
                                                </svg></div>
                                            <div class="embed w-embed"><svg width="57" height="48" viewBox="0 0 57 48"
                                                    fill="none" xmlns="http://www.w3.org/2000/svg">
                                                    <path
                                                        d="M4.9935 47.251L42.6944 0.749022H51.433L13.7321 47.251H4.9935ZM12.2341 24.3433C9.94539 24.3433 7.86476 23.8023 5.9922 22.7204C4.16125 21.5969 2.70481 20.1196 1.62289 18.2887C0.540964 16.4577 0 14.4187 0 12.1717C0 9.92458 0.540964 7.88556 1.62289 6.05462C2.70481 4.18205 4.16125 2.70481 5.9922 1.62289C7.86476 0.540963 9.94539 0 12.2341 0C14.5644 0 16.645 0.540963 18.4759 1.62289C20.3069 2.70481 21.7633 4.18205 22.8453 6.05462C23.9272 7.88556 24.4681 9.92458 24.4681 12.1717C24.4681 14.4187 23.9272 16.4577 22.8453 18.2887C21.7633 20.1196 20.3069 21.5969 18.4759 22.7204C16.645 23.8023 14.5644 24.3433 12.2341 24.3433ZM12.2341 18.039C13.4824 18.039 14.5228 17.7685 15.355 17.2276C16.1873 16.645 16.8114 15.9168 17.2276 15.0429C17.6853 14.1274 17.9142 13.1703 17.9142 12.1717C17.9142 11.1313 17.6853 10.1743 17.2276 9.30039C16.8114 8.42653 16.1873 7.69831 15.355 7.11574C14.5228 6.53316 13.4824 6.24187 12.2341 6.24187C11.0689 6.24187 10.0494 6.53316 9.17556 7.11574C8.34331 7.69831 7.69831 8.44733 7.24057 9.36281C6.78283 10.2367 6.55397 11.173 6.55397 12.1717C6.55397 13.1287 6.78283 14.065 7.24057 14.9805C7.69831 15.896 8.34331 16.645 9.17556 17.2276C10.0494 17.7685 11.0689 18.039 12.2341 18.039ZM43.9428 48C41.6541 48 39.5735 47.459 37.7009 46.3771C35.87 45.2536 34.4135 43.7763 33.3316 41.9454C32.2497 40.1144 31.7087 38.0754 31.7087 35.8283C31.7087 33.5813 32.2497 31.5423 33.3316 29.7113C34.4135 27.8387 35.87 26.3615 37.7009 25.2796C39.5735 24.1977 41.6541 23.6567 43.9428 23.6567C46.2731 23.6567 48.3537 24.1977 50.1847 25.2796C52.0156 26.3615 53.4721 27.8387 54.554 29.7113C55.6359 31.5423 56.1769 33.5813 56.1769 35.8283C56.1769 38.0754 55.6359 40.1144 54.554 41.9454C53.4721 43.7763 52.0156 45.2536 50.1847 46.3771C48.3537 47.459 46.2731 48 43.9428 48ZM43.9428 41.6957C45.1496 41.6957 46.1691 41.4252 47.0013 40.8843C47.8752 40.3017 48.5202 39.5735 48.9363 38.6996C49.394 37.7841 49.6229 36.827 49.6229 35.8283C49.6229 34.788 49.394 33.8309 48.9363 32.9571C48.5202 32.0832 47.8752 31.355 47.0013 30.7724C46.1691 30.1899 45.1496 29.8986 43.9428 29.8986C42.7776 29.8986 41.7581 30.1899 40.8843 30.7724C40.052 31.355 39.407 32.104 38.9493 33.0195C38.4916 33.8934 38.2627 34.8296 38.2627 35.8283C38.2627 36.7854 38.4916 37.7217 38.9493 38.6372C39.407 39.5527 40.052 40.3017 40.8843 40.8843C41.7581 41.4252 42.7776 41.6957 43.9428 41.6957Z"
                                                        fill="#E9394B" />
                                                </svg></div>
                                        </div>
                                    </div>
                                    <div class="max-width-108 set-max-width-74">
                                        <div class="max-width-83 div-center"><img
                                                src="https://cdn.prod.website-files.com/668b3733f80ed0dcd2c46207/67d8cf8b5fcd4f8d71a88fd1_unlock-cashback.svg"
                                                loading="lazy" alt="Meta Logo" /></div>
                                    </div>
                                    <div>
                                        <div class="margin-bottom-8">
                                            <h3>Unlock cashback on advertising spend</h3>
                                        </div>
                                        <div class="text-color-gray-300">Boost your bottom-line margins through cashback on advertising spend for a significant competitive advantage.</div>
                                    </div>
                                    <div class="ad-button-wrapper">
                                        <div class="infra-button">
                                            <div class="fix-24">
                                                <div data-button-icon="hover" class="embed w-embed"><svg width="24"
                                                        height="24" viewBox="0 0 24 24" fill="none"
                                                        xmlns="http://www.w3.org/2000/svg">
                                                        <path d="M5 12H19M19 12L12 5M19 12L12 19" stroke="currentColor"
                                                            stroke-width="2" stroke-linecap="round"
                                                            stroke-linejoin="round" />
                                                    </svg></div>
                                                <div data-button-icon="normal" class="embed w-embed"><svg width="24"
                                                        height="24" viewBox="0 0 24 24" fill="none"
                                                        xmlns="http://www.w3.org/2000/svg">
                                                        <path d="M9 18L15 12L9 6" stroke="white" stroke-width="2"
                                                            stroke-linecap="round" stroke-linejoin="round" />
                                                    </svg></div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </a><a href="#" class="infrastracture-box w-inline-block">
                                <div class="ad-bg-box"></div>
                                <div class="infra-box _24 rev">
                                    <div class="max-width-447">
                                        <div class="margin-bottom-8">
                                            <h3>Affiliate program</h3>
                                        </div>
                                        <div class="set-margin-bottom-24">
                                            <div class="text-color-gray-300">Get paid for every new signup, advertising spend and more. Partner with the market-leaders in advertising solutions for immense growth.</div>
                                        </div>
                                    </div>
                                    <div class="max-width-248 max-width-none"><img
                                            src="https://cdn.prod.website-files.com/668b3733f80ed0dcd2c46207/672dc2adea785e5eb332c44e_affiliate-stats.svg"
                                            loading="lazy" alt="" /></div>
                                    <div class="ad-button-wrapper">
                                        <div class="infra-button">
                                            <div class="fix-24">
                                                <div data-button-icon="hover" class="embed w-embed"><svg width="24"
                                                        height="24" viewBox="0 0 24 24" fill="none"
                                                        xmlns="http://www.w3.org/2000/svg">
                                                        <path d="M5 12H19M19 12L12 5M19 12L12 19" stroke="currentColor"
                                                            stroke-width="2" stroke-linecap="round"
                                                            stroke-linejoin="round" />
                                                    </svg></div>
                                                <div data-button-icon="normal" class="embed w-embed"><svg width="24"
                                                        height="24" viewBox="0 0 24 24" fill="none"
                                                        xmlns="http://www.w3.org/2000/svg">
                                                        <path d="M9 18L15 12L9 6" stroke="white" stroke-width="2"
                                                            stroke-linecap="round" stroke-linejoin="round" />
                                                    </svg></div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </a><a href="#" class="infrastracture-box w-inline-block">
                                <div class="ad-bg-box"></div>
                                <div class="infra-box _24">
                                    <div class="max-width-108 set-max-width-74">
                                        <div class="embed height-56 w-embed"><svg width="108" height="80"
                                                viewBox="0 0 108 80" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                <g clip-path="url(#clip0_60_9267)">
                                                    <path
                                                        d="M107.143 2.92683C107.143 3.70307 106.832 4.44752 106.278 4.99641C105.725 5.5453 104.974 5.85366 104.191 5.85366C103.408 5.85366 102.657 5.5453 102.103 4.99641C101.549 4.44752 101.238 3.70307 101.238 2.92683C101.238 2.15059 101.549 1.40614 102.103 0.857248C102.657 0.308361 103.408 0 104.191 0C104.974 0 105.725 0.308361 106.278 0.857248C106.832 1.40614 107.143 2.15059 107.143 2.92683Z"
                                                        fill="white" />
                                                    <path fill-rule="evenodd" clip-rule="evenodd"
                                                        d="M27.9209 79.598C12.974 79.598 0.857422 67.5863 0.857422 52.7687V1.95117H10.6987V52.7687C10.6987 57.2968 12.5132 61.6395 15.743 64.8413C18.9728 68.0431 23.3533 69.8419 27.9209 69.8419C37.5516 69.8419 45.1431 62.4839 45.1431 53.1707H54.9844V67.8048C54.9844 68.4517 55.2436 69.0721 55.705 69.5295C56.1664 69.9869 56.7922 70.2439 57.4447 70.2439C58.0972 70.2439 58.723 69.9869 59.1844 69.5295C59.6458 69.0721 59.905 68.4517 59.905 67.8048V50.4878C58.1175 50.8495 56.2712 50.8125 54.4999 50.3796C52.7286 49.9466 51.0766 49.1285 49.6635 47.9845C48.2505 46.8406 47.1118 45.3993 46.33 43.7652C45.5482 42.1311 45.1428 40.3451 45.1431 38.5365V14.1463C45.1431 10.9119 46.4392 7.81007 48.7462 5.52304C51.0532 3.23601 54.1821 1.95117 57.4447 1.95117C60.7073 1.95117 63.8363 3.23601 66.1432 5.52304C68.4502 7.81007 69.7463 10.9119 69.7463 14.1463V67.8048C69.7463 68.4517 70.0055 69.0721 70.4669 69.5295C70.9283 69.9869 71.5541 70.2439 72.2066 70.2439C72.8591 70.2439 73.4849 69.9869 73.9463 69.5295C74.4077 69.0721 74.6669 68.4517 74.6669 67.8048V14.1463C74.6669 10.9119 75.963 7.81007 78.27 5.52304C80.577 3.23601 83.7059 1.95117 86.9685 1.95117C90.2311 1.95117 93.3601 3.23601 95.6671 5.52304C97.9741 7.81007 99.2701 10.9119 99.2701 14.1463V67.8048C99.2701 70.0696 98.6339 72.2896 97.4329 74.2162C96.2318 76.1427 94.5133 77.6996 92.47 78.7125C90.4266 79.7253 88.1391 80.1541 85.8638 79.9507C83.5885 79.7473 81.4152 78.9198 79.5876 77.5609C77.4601 79.1477 74.869 80.0039 72.2066 80C69.5443 80.0039 66.9531 79.1477 64.8257 77.5609C63.3451 78.6616 61.6331 79.417 59.8173 79.7709C58.0014 80.1248 56.1284 80.068 54.3377 79.6048C52.547 79.1416 50.8848 78.2839 49.4748 77.0956C48.0649 75.9072 46.9435 74.4189 46.1942 72.7414C41.3601 77.0282 34.9299 79.598 27.9209 79.598ZM86.9685 70.2439C85.6104 70.2439 84.5082 69.1512 84.5082 67.8048V14.1463C84.5082 13.4994 84.7674 12.879 85.2288 12.4216C85.6902 11.9642 86.316 11.7073 86.9685 11.7073C87.621 11.7073 88.2468 11.9642 88.7082 12.4216C89.1696 12.879 89.4288 13.4994 89.4288 14.1463V67.8048C89.4288 69.1512 88.3266 70.2439 86.9685 70.2439ZM59.905 38.5365C59.905 39.1834 59.6458 39.8038 59.1844 40.2612C58.723 40.7186 58.0972 40.9756 57.4447 40.9756C56.7922 40.9756 56.1664 40.7186 55.705 40.2612C55.2436 39.8038 54.9844 39.1834 54.9844 38.5365V14.1463C54.9844 13.4994 55.2436 12.879 55.705 12.4216C56.1664 11.9642 56.7922 11.7073 57.4447 11.7073C58.0972 11.7073 58.723 11.9642 59.1844 12.4216C59.6458 12.879 59.905 13.4994 59.905 14.1463V38.5365Z"
                                                        fill="white" />
                                                    <path fill-rule="evenodd" clip-rule="evenodd"
                                                        d="M15.6191 53.1707C15.6191 56.405 16.9152 59.5069 19.2222 61.7939C21.5292 64.081 24.6581 65.3658 27.9207 65.3658C31.1833 65.3658 34.3123 64.081 36.6193 61.7939C38.9263 59.5069 40.2223 56.405 40.2223 53.1707V14.1463C40.2223 10.9119 38.9263 7.81007 36.6193 5.52304C34.3123 3.23601 31.1833 1.95117 27.9207 1.95117C24.6581 1.95117 21.5292 3.23601 19.2222 5.52304C16.9152 7.81007 15.6191 10.9119 15.6191 14.1463V53.1707ZM27.9207 55.6097C26.5626 55.6097 25.4604 54.517 25.4604 53.1707V14.1463C25.4604 13.4994 25.7196 12.879 26.181 12.4216C26.6424 11.9642 27.2682 11.7073 27.9207 11.7073C28.5732 11.7073 29.199 11.9642 29.6604 12.4216C30.1218 12.879 30.381 13.4994 30.381 14.1463V53.1707C30.381 54.517 29.2788 55.6097 27.9207 55.6097Z"
                                                        fill="white" />
                                                </g>
                                                <defs>
                                                    <clipPath id="clip0_60_9267">
                                                        <rect width="106.286" height="80" fill="white"
                                                            transform="translate(0.857422)" />
                                                    </clipPath>
                                                </defs>
                                            </svg></div>
                                    </div>
                                    <div>
                                        <div class="margin-bottom-8">
                                            <h3>Whitelabeling and reselling</h3>
                                        </div>
                                        <div class="text-color-gray-300">Offer advertising account services as a reseller, branded with your agency name.</div>
                                    </div>
                                    <div class="ad-button-wrapper">
                                        <div class="infra-button">
                                            <div class="fix-24">
                                                <div data-button-icon="hover" class="embed w-embed"><svg width="24"
                                                        height="24" viewBox="0 0 24 24" fill="none"
                                                        xmlns="http://www.w3.org/2000/svg">
                                                        <path d="M5 12H19M19 12L12 5M19 12L12 19" stroke="currentColor"
                                                            stroke-width="2" stroke-linecap="round"
                                                            stroke-linejoin="round" />
                                                    </svg></div>
                                                <div data-button-icon="normal" class="embed w-embed"><svg width="24"
                                                        height="24" viewBox="0 0 24 24" fill="none"
                                                        xmlns="http://www.w3.org/2000/svg">
                                                        <path d="M9 18L15 12L9 6" stroke="white" stroke-width="2"
                                                            stroke-linecap="round" stroke-linejoin="round" />
                                                    </svg></div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </a></div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="section_home-scaling">
        <div class="padding-global">
            <div class="container-1600">
                <div class="position-relative">
                    <div class="display-inline-block">
                        <div class="position-relative z-2">
                            <div class="margin-bottom-280 set-margin-bottom-32">
                                <div class="max-width-485 max-width-none">
                                    <div class="header-section">
                                        <div class="header-tag">
                                            <div>Global performance</div>
                                        </div>
                                        <h2 class="text-color-gray-200">The backbone for global advertising
                                        </h2>
                                        <div
                                            class="text-size-20 text-color-gray-300 text-weight-medium set-text-size-18 set-text-weight-regular">
                                            Connecting marketers with enterprise advertising accounts, payment solutions, dedicated support, industry insights and consulting.</div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="scale-component">
                        <div class="scale-box">
                            <div class="scale-line"></div>
                            <div class="max-width-208 set-max-width-none">
                                <div class="margin-bottom-16 set-margin-bottom-8">
                                    <h2 class="heading-36">$<span>1</span>.<span>4</span>B</h2>
                                </div>
                                <div class="text-color-gray-300">Attributed returns on campaigns</div>
                            </div>
                        </div>
                        <div class="scale-box">
                            <div class="scale-line"></div>
                            <div class="max-width-208 set-max-width-none">
                                <div class="margin-bottom-16 set-margin-bottom-8">
                                    <h2 class="heading-36"><span>3000</span>+</h2>
                                </div>
                                <div class="text-color-gray-300">Unique advertisers</div>
                            </div>
                        </div>
                        <div class="scale-box">
                            <div class="scale-line"></div>
                            <div class="max-width-208 set-max-width-none">
                                <div class="margin-bottom-16 set-margin-bottom-8">
                                    <h2 class="heading-36"><span>40</span>+</h2>
                                </div>
                                <div class="text-color-gray-300">Partner platforms</div>
                            </div>
                        </div>
                        <div class="scale-box">
                            <div class="scale-line"></div>
                            <div class="max-width-208 set-max-width-none">
                                <div class="margin-bottom-16 set-margin-bottom-8">
                                    <h2 class="heading-36">$<span>350</span>M</h2>
                                </div>
                                <div class="text-color-gray-300">Annual advertising spend</div>
                            </div>
                        </div>
                        <div class="scale-box">
                            <div class="scale-line"></div>
                            <div class="max-width-208 set-max-width-none">
                                <div class="margin-bottom-16 set-margin-bottom-8">
                                    <h2 class="heading-36"><span>100</span>+</h2>
                                </div>
                                <div class="text-color-gray-300">Reseller agencies</div>
                            </div>
                        </div>
                    </div>
                    <div class="globe-box no-bg">
                        <div id="globe-container" class="globe-box-side v4"></div>
                        <div class="hide w-embed w-script">
                            <script
                                type="importmap">{ "imports": { "three": "https://unpkg.com/three/build/three.module.js" }}</script>
                            <script type="module">
                                import { OrbitControls } from "https://unpkg.com/three/examples/jsm/controls/OrbitControls.js";

                                // Gen random data
                                const N = 20;
                                const ARC_REL_LEN = 0.4; // relative to whole arc
                                const FLIGHT_TIME = 1000;
                                const NUM_RINGS = 3;
                                const RINGS_MAX_R = 5; // deg
                                const RING_PROPAGATION_SPEED = 5; // deg/sec

                                // United Kingdom, Bulgaria, Serbia, Cambodia, Philippines, Belgium, Georgia, Romania, Hong Kong
                                const allLat = [
                                    54.103561, 42.6204299, 44.1843332, 12.1382978, 11.5315466, 50.4953234, 42.3153645, 45.8370898, 22.3529584
                                ];

                                const allLon = [
                                    -14.9994984, 20.53911, 18.2714005, 102.3412699, 112.4998062, 3.1472125, 42.0386217, 20.0180788, 113.9745913
                                ];

                                const arcsData = [...Array(N).keys()].map(function () {
                                    let st = Math.round(Math.random() * 8);
                                    let en = noDuplicate(st);

                                    return {
                                        startLat: allLat[st],
                                        startLng: allLon[st],
                                        endLat: allLat[en],
                                        endLng: allLon[en],
                                        color: ['#ffffff', '#e9394b', '#ffffff', '#ffffff', '#e9394b', '#ffffff'][Math.round(Math.random() * 5)],
                                    };
                                });

                                function noDuplicate(taken) {
                                    let i = Math.round(Math.random() * 8);
                                    while (i == taken) {
                                        i = Math.round(Math.random() * 8);
                                    }
                                    return i;
                                }

                                const Globe = new ThreeGlobe()
                                    .globeImageUrl('https://cdn.prod.website-files.com/668b3733f80ed0dcd2c46207/671a01e8d865e46118c69565_light_map.jpg')
                                    .arcsData(arcsData)
                                    .arcColor('color')
                                    .arcDashLength(0.4)
                                    .arcDashGap(4)
                                    .arcCircularResolution(10)
                                    .showAtmosphere(true)
                                    .atmosphereColor('#101828')
                                    .arcDashInitialGap(() => Math.random() * 5)
                                    .arcDashAnimateTime(5000);
                                Globe.scale.set(1.0, 1.0, 1.0);

                                // Setup renderer
                                const renderer = new THREE.WebGLRenderer();

                                const factor = 0.5; // percentage of the screen
                                const globeDiv = document.getElementById("globe-container");
                                let w = globeDiv.offsetWidth;
                                let h = globeDiv.offsetHeight;

                                renderer.setSize(w, h);
                                renderer.setClearColor(0x000000, 0);
                                document.getElementById('globe-container').appendChild(renderer.domElement);

                                // Setup scene
                                const scene = new THREE.Scene();
                                scene.add(Globe);
                                scene.add(new THREE.AmbientLight(0xbbbbbb));

                                // Setup camera
                                const camera = new THREE.PerspectiveCamera(50, w / h, 0.1, 1000);
                                camera.aspect = w / h;
                                camera.updateProjectionMatrix();
                                camera.position.z = 350;

                                // Add camera controls
                                const controls = new OrbitControls(camera, renderer.domElement);
                                controls.minDistance = 101;
                                controls.maxDistance = 400;
                                controls.enablePan = false; // Disable panning
                                controls.enableZoom = false; // Disable zoom
                                controls.rotateSpeed = 1.5;

                                // Restrict vertical rotation
                                controls.minPolarAngle = Math.PI / 2; // Prevent the globe from rotating upwards
                                controls.maxPolarAngle = Math.PI / 2; // Prevent the globe from rotating downwards

                                let rotation = 0;
                                // Kick-off renderer
                                (function animate() { // IIFE
                                    // Frame cycle
                                    rotation -= 0.0005;
                                    Globe.rotation.y = rotation;
                                    controls.update();
                                    renderer.render(scene, camera);
                                    requestAnimationFrame(animate);
                                })();

                                window.addEventListener('resize', () => {
                                    const w = globeDiv.offsetWidth;
                                    const h = globeDiv.offsetHeight;
                                    camera.aspect = w / h;
                                    camera.updateProjectionMatrix();
                                    renderer.setSize(w, h);
                                });
                            </script>

                            <script>
                                document.getElementById("globe-container").addEventListener("mousedown", mouseDown);
                                document.getElementById("globe-container").addEventListener("mouseup", mouseUp);

                                function mouseDown() {
                                    document.getElementById("globe-container").style.cursor = "grabbing";
                                }

                                function mouseUp() {
                                    document.getElementById("globe-container").style.cursor = "grab";
                                }
                            </script>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<div class="section_home-solutions">
    <div class="padding-global">
        <div class="container-1600">
            <div class="margin-bottom-48 set-margin-bottom-32">
                <div class="header-section">
                    <div class="header-tag bg-color-gray-700">
                        <div>One-stop solution</div>
                    </div>
                    <h2 class="text-color-gray-200">The only advertising partner you will ever need</h2>
                    <div
                        class="text-size-20 text-color-gray-300 text-weight-medium set-text-size-18 set-text-weight-regular">
                        Work with us to discover an unrivalled advertising experience. Enjoy hands-on support from dedicated account managers, a full suite of technology solutions and an account setup that is designed to maximize your profitability without any risk.
                    </div>
                </div>
            </div>
            <div class="solutions-component">
                <div class="solutions-box-wrapper">
                    <div class="solutions-box expand-hover">
                        <div class="embed w-embed"><svg width="48" height="48" viewBox="0 0 48 48" fill="none"
                                xmlns="http://www.w3.org/2000/svg">
                                <path
                                    d="M10 21.4286C12.2063 21.4286 14 19.5708 14 17.2857C14 15.0007 12.2063 13.1429 10 13.1429C7.79375 13.1429 6 15.0007 6 17.2857C6 19.5708 7.79375 21.4286 10 21.4286ZM38 21.4286C40.2062 21.4286 42 19.5708 42 17.2857C42 15.0007 40.2062 13.1429 38 13.1429C35.7938 13.1429 34 15.0007 34 17.2857C34 19.5708 35.7938 21.4286 38 21.4286ZM40 23.5H36C34.9 23.5 33.9062 23.9596 33.1812 24.704C35.7 26.1346 37.4875 28.7174 37.875 31.7857H42C43.1063 31.7857 44 30.86 44 29.7143V27.6429C44 25.3578 42.2062 23.5 40 23.5ZM24 23.5C27.8687 23.5 31 20.2569 31 16.25C31 12.2431 27.8687 9 24 9C20.1313 9 17 12.2431 17 16.25C17 20.2569 20.1313 23.5 24 23.5ZM28.8 25.5714H28.2812C26.9813 26.2188 25.5375 26.6071 24 26.6071C22.4625 26.6071 21.025 26.2188 19.7188 25.5714H19.2C15.225 25.5714 12 28.9116 12 33.0286V34.8929C12 36.6083 13.3438 38 15 38H33C34.6562 38 36 36.6083 36 34.8929V33.0286C36 28.9116 32.775 25.5714 28.8 25.5714ZM14.8188 24.704C14.0938 23.9596 13.1 23.5 12 23.5H8C5.79375 23.5 4 25.3578 4 27.6429V29.7143C4 30.86 4.89375 31.7857 6 31.7857H10.1188C10.5125 28.7174 12.3 26.1346 14.8188 24.704Z"
                                    fill="#E9394B" />
                                <g style="mix-blend-mode:plus-lighter" opacity="0.5">
                                    <path
                                        d="M30.6428 29.1868C30.8342 28.6695 31.5658 28.6695 31.7572 29.1868L33.3518 33.496C33.412 33.6587 33.5402 33.7869 33.7028 33.8471L38.0121 35.4416C38.5293 35.633 38.5293 36.3646 38.012 36.556L33.7028 38.1506C33.5402 38.2108 33.412 38.339 33.3518 38.5016L31.7572 42.8109C31.5658 43.3281 30.8342 43.3281 30.6428 42.8109L29.0482 38.5016C28.988 38.339 28.8598 38.2108 28.6972 38.1506L24.3879 36.556C23.8707 36.3646 23.8707 35.633 24.3879 35.4416L28.6972 33.8471C28.8598 33.7869 28.988 33.6587 29.0482 33.496L30.6428 29.1868Z"
                                        fill="white" />
                                </g>
                                <g style="mix-blend-mode:plus-lighter" opacity="0.5">
                                    <path
                                        d="M40.9821 20.6914C41.1256 20.3034 41.6744 20.3034 41.8179 20.6914L43.0138 23.9233C43.059 24.0453 43.1551 24.1414 43.2771 24.1866L46.509 25.3825C46.897 25.526 46.897 26.0747 46.509 26.2183L43.2771 27.4142C43.1551 27.4594 43.059 27.5555 43.0138 27.6775L41.8179 30.9094C41.6744 31.2974 41.1256 31.2974 40.9821 30.9094L39.7862 27.6775C39.741 27.5555 39.6449 27.4594 39.5229 27.4142L36.291 26.2183C35.903 26.0747 35.903 25.526 36.291 25.3825L39.5229 24.1866C39.6449 24.1414 39.741 24.0453 39.7862 23.9233L40.9821 20.6914Z"
                                        fill="white" />
                                </g>
                            </svg></div>
                        <div class="hide">
                            <div class="box-48" data-w-id="9e86de20-9957-4440-6520-5b62847f3fb2"
                                data-animation-type="lottie"
                                data-src="https://cdn.prod.website-files.com/668b3733f80ed0dcd2c46207/66d95fc110e51570ad68f3a3_Whitelisted%20ad%20accounts%20(1).lottie"
                                data-loop="1" data-direction="1" data-autoplay="1" data-is-ix2-target="0"
                                data-renderer="svg" data-default-duration="4.983333333333333" data-duration="0"></div>
                        </div>
                        <div class="lead-full-box">
                            <div class="margin-bottom-8">
                                <div class="text-size-18 text-weight-bold">Whitelisted ad accounts</div>
                            </div>
                            <div class="text-color-gray-300">Supercharge your marketing with enterprise accounts: no ad restrictions, cashback on spend, unlimited scalability, and cheaper results.</div>
                        </div>
                    </div>
                </div>
                <div class="solutions-box-wrapper">
                    <div class="solutions-box expand-hover">
                        <div class="embed w-embed"><svg width="48" height="48" viewBox="0 0 48 48" fill="none"
                                xmlns="http://www.w3.org/2000/svg">
                                <path fill-rule="evenodd" clip-rule="evenodd"
                                    d="M10.6111 25.1111H20.2778C20.7051 25.1111 21.1149 24.9414 21.417 24.6392C21.7191 24.3371 21.8889 23.9273 21.8889 23.5V10.6111C21.8889 10.1838 21.7191 9.77403 21.417 9.47188C21.1149 9.16974 20.7051 9 20.2778 9H10.6111C10.1838 9 9.77403 9.16974 9.47188 9.47188C9.16974 9.77403 9 10.1838 9 10.6111V23.5C9 23.9273 9.16974 24.3371 9.47188 24.6392C9.77403 24.9414 10.1838 25.1111 10.6111 25.1111ZM9 36.3889C9 36.8162 9.16974 37.226 9.47188 37.5281C9.77403 37.8303 10.1838 38 10.6111 38H20.2778C20.7051 38 21.1149 37.8303 21.417 37.5281C21.7191 37.226 21.8889 36.8162 21.8889 36.3889V29.9444C21.8889 29.5172 21.7191 29.1074 21.417 28.8052C21.1149 28.5031 20.7051 28.3333 20.2778 28.3333H10.6111C10.1838 28.3333 9.77403 28.5031 9.47188 28.8052C9.16974 29.1074 9 29.5172 9 29.9444V36.3889ZM25.1111 36.3889C25.1111 36.8162 25.2809 37.226 25.583 37.5281C25.8851 37.8303 26.2949 38 26.7222 38H36.3889C36.8162 38 37.226 37.8303 37.5281 37.5281C37.8303 37.226 38 36.8162 38 36.3889V25.1111C38 24.6838 37.8303 24.274 37.5281 23.9719C37.226 23.6697 36.8162 23.5 36.3889 23.5H26.7222C26.2949 23.5 25.8851 23.6697 25.583 23.9719C25.2809 24.274 25.1111 24.6838 25.1111 25.1111V36.3889ZM26.7222 20.2778H36.3889C36.8162 20.2778 37.226 20.108 37.5281 19.8059C37.8303 19.5038 38 19.094 38 18.6667V10.6111C38 10.1838 37.8303 9.77403 37.5281 9.47188C37.226 9.16974 36.8162 9 36.3889 9H26.7222C26.2949 9 25.8851 9.16974 25.583 9.47188C25.2809 9.77403 25.1111 10.1838 25.1111 10.6111V18.6667C25.1111 19.094 25.2809 19.5038 25.583 19.8059C25.8851 20.108 26.2949 20.2778 26.7222 20.2778ZM16.6072 16.8906C16.4585 16.8906 16.3158 16.8315 16.2107 16.7263C16.1055 16.6212 16.0465 16.4785 16.0465 16.3298V13.5263C16.0465 13.2167 16.2988 12.9616 16.6055 13.0048C17.445 13.1254 18.2228 13.5148 18.8225 14.1145C19.4222 14.7142 19.8116 15.492 19.9322 16.3315C19.976 16.6382 19.7203 16.8906 19.4108 16.8906H16.6072ZM14.925 14.6477C14.925 14.3388 14.6727 14.0836 14.366 14.1262C13.4314 14.2607 12.5765 14.7276 11.9583 15.4414C11.34 16.1551 10.9998 17.0678 11 18.012C11.0006 19.0042 11.377 19.9593 12.0533 20.6853C12.7296 21.4113 13.6557 21.8542 14.6453 21.9251C15.635 21.9959 16.6148 21.6894 17.3876 21.0671C18.1604 20.4448 18.6689 19.553 18.8108 18.571C18.8545 18.2643 18.5988 18.012 18.2893 18.012H15.4857C15.337 18.012 15.1944 17.9529 15.0893 17.8478C14.9841 17.7426 14.925 17.6 14.925 17.4513V14.6477Z"
                                    fill="#E9394B" />
                                <g style="mix-blend-mode:plus-lighter" opacity="0.5">
                                    <path
                                        d="M33.3612 29.3162C33.0433 30.1124 32.8052 30.9381 32.6504 31.7812H38.3496C38.1944 30.9381 37.956 30.1124 37.6377 29.3162C37.3179 28.5374 36.9492 27.9414 36.5667 27.5493C36.1864 27.1583 35.8262 27 35.5 27C35.1738 27 34.8136 27.1583 34.4333 27.5493C34.0508 27.9424 33.6821 28.5374 33.3612 29.3162ZM33.2592 27.2986C32.9256 27.7512 32.6323 28.2984 32.3794 28.9114C32.0394 29.7402 31.7632 30.7113 31.5698 31.7812H27.8543C28.385 30.6929 29.1415 29.7302 30.0735 28.9573C31.0055 28.1843 32.0915 27.6189 33.2592 27.2986ZM37.7419 27.2986C38.0744 27.7512 38.3687 28.2984 38.6206 28.9114C38.9606 29.7402 39.2368 30.7113 39.4302 31.7812H43.1457C42.615 30.6929 41.8585 29.7302 40.9265 28.9573C39.9945 28.1843 38.9096 27.6189 37.7419 27.2986ZM43.5771 32.8438H39.5906C39.6947 33.6884 39.75 34.5799 39.75 35.5C39.75 36.4201 39.6947 37.3116 39.5906 38.1562H43.5771C43.8582 37.2989 44.0009 36.4022 44 35.5C44.0009 34.5978 43.8582 33.7011 43.5771 32.8438ZM43.1457 39.2188H39.4302C39.2368 40.2887 38.9616 41.2609 38.6206 42.0875C38.3936 42.6588 38.0986 43.2007 37.7419 43.7014C38.9094 43.381 39.9952 42.8155 40.927 42.0425C41.8587 41.2696 42.6151 40.3069 43.1457 39.2188ZM35.5 44C35.8262 44 36.1864 43.8417 36.5667 43.4507C36.9492 43.0576 37.3179 42.4626 37.6377 41.6838C37.956 40.8876 38.1944 40.0619 38.3496 39.2188H32.6504C32.8289 40.1463 33.0722 40.9793 33.3623 41.6838C33.6821 42.4626 34.0508 43.0586 34.4333 43.4507C34.8136 43.8417 35.1738 44 35.5 44ZM33.2581 43.7014C32.0908 43.3809 31.0052 42.8153 30.0736 42.0423C29.142 41.2694 28.3858 40.3068 27.8553 39.2188H31.5709C31.7643 40.2887 32.0394 41.2609 32.3805 42.0875C32.6323 42.7016 32.9266 43.2488 33.2603 43.7014M27.4239 38.1562H31.4094C31.3035 37.2748 31.2502 36.3878 31.25 35.5C31.25 34.5799 31.3053 33.6884 31.4094 32.8438H27.4229C27.1418 33.7011 26.9991 34.5978 27 35.5C27 36.4276 27.1498 37.3201 27.4239 38.1562ZM32.3125 35.5C32.3125 34.5703 32.372 33.6778 32.4804 32.8438H38.5196C38.628 33.6778 38.6875 34.5703 38.6875 35.5C38.6875 36.4297 38.628 37.3211 38.5196 38.1562H32.4804C32.366 37.2755 32.31 36.3881 32.3125 35.5Z"
                                        fill="white" />
                                </g>
                            </svg></div>
                        <div class="hide">
                            <div class="box-48" data-w-id="b7a8b44b-be36-5149-f3c1-39170f510e0b"
                                data-animation-type="lottie"
                                data-src="https://cdn.prod.website-files.com/668b3733f80ed0dcd2c46207/66d95f939eec7ad5e90bfc5f_Leading%20technology%20(1).lottie"
                                data-loop="1" data-direction="1" data-autoplay="1" data-is-ix2-target="0"
                                data-renderer="svg" data-default-duration="4.983333333333333" data-duration="0"></div>
                        </div>
                        <div class="lead-full-box">
                            <div class="margin-bottom-8">
                                <div class="text-size-18 text-weight-bold">Leading technology</div>
                            </div>
                            <div class="text-color-gray-300">Our all-in-one proprietary technology lets advertisers manage, optimize, organize, and strategize on a single, mobile-friendly platform accessible anywhere.</div>
                        </div>
                    </div>
                </div>
                <div class="solutions-box-wrapper">
                    <div class="solutions-box expand-hover">
                        <div class="embed w-embed"><svg width="48" height="48" viewBox="0 0 48 48" fill="none"
                                xmlns="http://www.w3.org/2000/svg">
                                <g clip-path="url(#clip0_60_20983)">
                                    <path d="M37.1035 14.9808L40.9749 11.1094" stroke="#E9394B"
                                        stroke-linecap="round" />
                                    <path d="M10.6956 14.9808L6.82422 11.1094" stroke="#E9394B"
                                        stroke-linecap="round" />
                                    <path d="M23.8994 9.4203V3.94531" stroke="#E9394B" stroke-linecap="round" />
                                    <path d="M40.3242 25.9629H45.7992" stroke="#E9394B" stroke-linecap="round" />
                                    <path d="M7.47498 25.9629H2" stroke="#E9394B" stroke-linecap="round" />
                                    <path fill-rule="evenodd" clip-rule="evenodd"
                                        d="M37.9174 25.9602C37.9174 31.7779 34.3441 36.7611 29.2725 38.8348V40.1699C29.2725 41.2744 28.3771 42.1699 27.2725 42.1699H26.5357V42.538C26.5357 43.0903 26.088 43.538 25.5357 43.538H22.0607C21.5084 43.538 21.0607 43.0903 21.0607 42.538V42.1699H20.3226C19.218 42.1699 18.3226 41.2744 18.3226 40.1699V38.6492C13.4816 36.4746 10.1104 31.6111 10.1104 25.9602C10.1104 18.2815 16.3352 12.0566 24.0139 12.0566C31.6926 12.0566 37.9174 18.2815 37.9174 25.9602Z"
                                        fill="#E9394B" />
                                    <g style="mix-blend-mode:plus-lighter" opacity="0.5">
                                        <path fill-rule="evenodd" clip-rule="evenodd"
                                            d="M32.2227 34.4636C27.6873 38.8406 20.4621 38.7916 15.987 34.3165C11.4622 29.7917 11.4622 22.4557 15.987 17.931C20.5117 13.4063 27.8477 13.4063 32.3724 17.931C36.4666 22.0252 36.8562 28.4212 33.541 32.9535L38.8786 38.291C39.2691 38.6815 39.2691 39.3147 38.8786 39.7052C38.488 40.0958 37.8549 40.0958 37.4644 39.7052L32.2227 34.4636Z"
                                            fill="white" />
                                    </g>
                                    <path
                                        d="M17.3623 29.3078L20.2489 26.4213C20.6394 26.0307 21.2726 26.0307 21.6631 26.4213L23.8425 28.6007C24.233 28.9912 24.8662 28.9912 25.2567 28.6007L30.8222 23.0352"
                                        stroke="#E9394B" stroke-width="2" stroke-linecap="round" />
                                </g>
                                <defs>
                                    <clipPath id="clip0_60_20983">
                                        <rect width="48" height="48" fill="white" />
                                    </clipPath>
                                </defs>
                            </svg></div>
                        <div class="hide">
                            <div class="box-48" data-w-id="7fc18df3-deb5-ff2e-e294-0c6c5124b139"
                                data-animation-type="lottie"
                                data-src="https://cdn.prod.website-files.com/668b3733f80ed0dcd2c46207/66d95f7584c263906f336ea4_Media%20buying%20consulting%20(1).lottie"
                                data-loop="1" data-direction="1" data-autoplay="1" data-is-ix2-target="0"
                                data-renderer="svg" data-default-duration="4.983333333333333" data-duration="0"></div>
                        </div>
                        <div class="lead-full-box">
                            <div class="margin-bottom-8">
                                <div class="text-size-18 text-weight-bold">Media buying consulting</div>
                            </div>
                            <div class="text-color-gray-300">Gain insights from industry experts and our top agency, managing hundreds of millions in ad spend. Improve strategy with platform representatives.</div>
                        </div>
                    </div>
                </div>
                <div class="solutions-box-wrapper">
                    <div class="solutions-box expand-hover">
                        <div class="embed w-embed"><svg width="48" height="48" viewBox="0 0 48 48" fill="none"
                                xmlns="http://www.w3.org/2000/svg">
                                <path
                                    d="M19.0021 34.6871C27.287 34.6871 34.0042 28.6518 34.0042 21.2069C34.0042 13.7619 27.287 7.72656 19.0021 7.72656C10.7172 7.72656 4 13.7619 4 21.2069C4 24.5962 5.39332 27.6967 7.69426 30.0653C7.51236 32.0219 6.91228 34.1672 6.24844 35.7771C6.10029 36.1353 6.38721 36.5359 6.76038 36.4742C10.991 35.7617 13.5057 34.6679 14.599 34.0979C16.035 34.4926 17.5155 34.6907 19.0021 34.6871Z"
                                    fill="#E9394B" />
                                <g style="mix-blend-mode:plus-lighter" opacity="0.5">
                                    <path fill-rule="evenodd" clip-rule="evenodd"
                                        d="M21.5029 30.095C21.5029 35.5808 26.5097 40.0279 32.6851 40.0279C33.7932 40.0305 34.8967 39.8845 35.9671 39.5937C36.782 40.0137 38.6564 40.8197 41.8098 41.3447C42.0879 41.3901 42.3018 41.095 42.1914 40.8311C41.6965 39.6448 41.2493 38.064 41.1137 36.6223C42.8287 34.877 43.8673 32.5924 43.8673 30.095C43.8673 24.6092 38.8605 20.1621 32.6851 20.1621C26.5097 20.1621 21.5029 24.6092 21.5029 30.095ZM26.7998 31.9305C27.7749 31.9305 28.5654 31.14 28.5654 30.1649C28.5654 29.1897 27.7749 28.3993 26.7998 28.3993C25.8246 28.3993 25.0342 29.1897 25.0342 30.1649C25.0342 31.14 25.8246 31.9305 26.7998 31.9305ZM34.4507 30.1649C34.4507 31.14 33.6602 31.9305 32.6851 31.9305C31.71 31.9305 30.9195 31.14 30.9195 30.1649C30.9195 29.1897 31.71 28.3993 32.6851 28.3993C33.6602 28.3993 34.4507 29.1897 34.4507 30.1649ZM38.5704 31.9305C39.5455 31.9305 40.336 31.14 40.336 30.1649C40.336 29.1897 39.5455 28.3993 38.5704 28.3993C37.5953 28.3993 36.8048 29.1897 36.8048 30.1649C36.8048 31.14 37.5953 31.9305 38.5704 31.9305Z"
                                        fill="white" />
                                </g>
                            </svg></div>
                        <div class="hide">
                            <div class="box-48" data-w-id="7c18165b-d6c5-b1b4-bc95-18e1bb3ce99c"
                                data-animation-type="lottie"
                                data-src="https://cdn.prod.website-files.com/668b3733f80ed0dcd2c46207/66d90a3ab7864acf3c51882d_Dedicated%20%20support.lottie"
                                data-loop="1" data-direction="1" data-autoplay="1" data-is-ix2-target="0"
                                data-renderer="svg" data-duration="0"></div>
                        </div>
                        <div class="lead-full-box">
                            <div class="margin-bottom-8">
                                <div class="text-size-18 text-weight-bold">Dedicated support</div>
                            </div>
                            <div class="text-color-gray-300">Strategize with our dedicated account management team. Get daily support from someone who understands and helps achieve your goals.</div>
                        </div>
                    </div>
                </div>
                <div class="hide w-embed">
                    <style>
                        /**
.expand-hover {
transition: flex 200ms ease-in-out;
}
.expand-hover:hover {
flex: 10%;
}**/
                    </style>
                </div>
            </div>
        </div>
    </div>
</div>
<div class="section_cta">
    <div class="padding-global">
        <div class="container-1600">
            <div class="" style="text-align: center;">
                <h2  class="heading-36 text-color-gray-100">Ready to start today and boost your ad perfomance?</h2>
                
            </div>
        </div>
    </div>
</div>
<div class="section_home-platforms">
    <div class="padding-global">
        <div class="container-1600">
            <div class="margin-bottom-48">
                <div class="header-section">
                    <div class="header-tag">
                        <div>Integrated Solutions</div>
                    </div>
                    <h2 class="text-color-gray-200">Grow with multi-channel advertising</h2>
                    <div
                        class="text-size-20 text-color-gray-300 text-weight-medium set-text-size-18 set-text-weight-regular">
                        Save time with a unified advertising partner. With AdsAsia, you can access all advertising accounts, platforms, partners and services through one single dashboard, with a dedicated team for your success.</div>
                </div>
            </div>
            <div>
                <div>
                    <div data-current="Tab 1" data-easing="ease" data-duration-in="300" data-duration-out="100"
                        class="platforms-component w-tabs">
                        <div class="max-width-516 flex-first platforms-list-block w-tab-menu"><a data-w-tab="Tab 1"
                                class="platform-item-box w-inline-block w-tab-link w--current">
                                <div class="margin-bottom-8">
                                    <h3>Single dashboard integration</h3>
                                </div>
                                <div class="text-color-gray-300">Manage all of your advertising accounts in one single dashboard. Request new accounts, top up existing ones and plan your campaign strategy.</div>
                            </a><a data-w-tab="Tab 2" class="platform-item-box w-inline-block w-tab-link">
                                <div class="margin-bottom-8">
                                    <h3>One dedicated team</h3>
                                </div>
                                <div class="text-color-gray-300">Collaborate with your dedicated account manager at any time, and receive tailored feedback regarding the questions that you need answering.</div>
                            </a><a data-w-tab="Tab 3" class="platform-item-box w-inline-block w-tab-link">
                                <div class="margin-bottom-8">
                                    <h3>Multi-channel scalability</h3>
                                </div>
                                <div class="text-color-gray-300">Save time and money by signing up with our complete suite of services, including access to over 40+ advertising platforms from one single point of contact.</div>
                            </a></div>
                        <div class="max-width-928 flex-last no-hide w-tab-content">
                            <div data-w-tab="Tab 1" class="w-tab-pane w--tab-active">
                                <div data-scroll-image-box="1" class="platforms-image-box">
                                    <div class="gradient-background opacity-5"></div>
                                    <div class="platforms-image-shadow-box"></div><img loading="lazy"
                                        src="/assets/img2.png"
                                        alt="AdsAsia Dashboard" class="position-relative" />
                                </div>
                            </div>
                            <div data-w-tab="Tab 2" class="w-tab-pane">
                                <div class="platforms-image-box">
                                    <div class="gradient-background opacity-5"></div>
                                    <div class="platforms-image-shadow-box"></div>
                                    <div class="image-actual-size-box"><img sizes="100vw"
                                            srcset="https://cdn.prod.website-files.com/668b3733f80ed0dcd2c46207/678dcaf5372aafca63a94282_slack-image-big-min-p-500.png 500w, https://cdn.prod.website-files.com/668b3733f80ed0dcd2c46207/678dcaf5372aafca63a94282_slack-image-big-min-p-800.png 800w, https://cdn.prod.website-files.com/668b3733f80ed0dcd2c46207/678dcaf5372aafca63a94282_slack-image-big-min.png 1600w"
                                            alt="AdsAsia Dashboard"
                                            src="https://cdn.prod.website-files.com/668b3733f80ed0dcd2c46207/678dcaf5372aafca63a94282_slack-image-big-min.png"
                                            loading="lazy" class="position-relative" /></div>
                                </div>
                            </div>
                            <div data-w-tab="Tab 3" class="w-tab-pane">
                                <div class="platforms-image-box">
                                    <div class="gradient-background opacity-5"></div>
                                    <div class="platforms-image-shadow-box"></div><img loading="lazy"
                                        src="https://cdn.prod.website-files.com/668b3733f80ed0dcd2c46207/672dff58f9f194ff1de95e9c_partner-platforms.svg"
                                        alt="AdsAsia Services" class="position-relative" />
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<div class="section_home-features">
    <div class="padding-global">
        <div class="container-1600">
            <div class="margin-bottom-48">
                <div class="header-section">
                    <div class="header-tag">
                        <div>Features</div>
                    </div>
                    <h2 class="text-color-gray-200">Seamlessly create profitable marketing campaigns</h2>
                    <div class="subheading set-text-size-18 set-text-weight-regular">Trusted by a range industry-leading companies around the globe, AdsAsia's solutions are designed to help marketers scale campaigns profitably, consistently and with hands-on support.<br />
                    </div>
                </div>
            </div>
            <div class="features-grid">
                <div data-show="false" data-anim-show-up="1" class="features-box">
                    <div class="margin-bottom-56 set-margin-bottom-48">
                        <div class="list-box">
                            <div class="embed hide-this w-embed"><svg width="48" height="48" viewBox="0 0 48 48"
                                    fill="none" xmlns="http://www.w3.org/2000/svg">
                                    <path fill-rule="evenodd" clip-rule="evenodd"
                                        d="M8.79805 13.998C6.14708 13.998 3.99805 16.1471 3.99805 18.7981V34.2007C3.99805 36.8517 6.14708 39.0007 8.79805 39.0007H34.2017C36.8527 39.0007 39.0017 36.8517 39.0017 34.2007V18.798C39.0017 16.1471 36.8527 13.998 34.2017 13.998H8.79805ZM10.2487 31.85C9.75165 31.85 9.34871 32.253 9.34871 32.75C9.34871 33.2471 9.75165 33.65 10.2487 33.65H32.7511C33.2481 33.65 33.6511 33.2471 33.6511 32.75C33.6511 32.253 33.2481 31.85 32.7511 31.85H10.2487Z"
                                        fill="#E9394B" />
                                    <g style="mix-blend-mode:plus-lighter" opacity="0.5">
                                        <path fill-rule="evenodd" clip-rule="evenodd"
                                            d="M44.0019 17.7509C44.0019 22.5839 40.0839 26.5019 35.2509 26.5019C30.4179 26.5019 26.5 22.5839 26.5 17.7509C26.5 12.9179 30.4179 9 35.2509 9C40.0839 9 44.0019 12.9179 44.0019 17.7509ZM39.8261 15.7629C40.1775 15.4115 40.1775 14.8416 39.8261 14.4901C39.4746 14.1387 38.9047 14.1387 38.5533 14.4901L33.9391 19.1043L31.9502 17.1154C31.5987 16.764 31.0289 16.764 30.6774 17.1154C30.326 17.4669 30.326 18.0367 30.6774 18.3882L33.3027 21.0135C33.4715 21.1823 33.7004 21.2771 33.9391 21.2771C34.1778 21.2771 34.4067 21.1823 34.5755 21.0135L39.8261 15.7629Z"
                                            fill="white" />
                                    </g>
                                </svg></div>
                            <div class="box-48">
                                <div data-w-id="7a719183-6784-ac6f-2172-68e6fd1c2bc0" data-animation-type="lottie"
                                    data-src="https://cdn.prod.website-files.com/668b3733f80ed0dcd2c46207/66d9610d34540d92ef8588f5_Payment%20method%20freedom.lottie"
                                    data-loop="1" data-direction="1" data-autoplay="1" data-is-ix2-target="0"
                                    data-renderer="svg" data-default-duration="4.983333333333333" data-duration="0">
                                </div>
                            </div>
                            <div>
                                <div class="margin-bottom-8">
                                    <h3>Payment method freedom</h3>
                                </div>
                                <div class="text-color-gray-300">Bridge the gap between the payments your business relies on, and the marketing platforms that fuel growth. We help you to pay advertising spend in the easiest way for you. Including credit and debit card, transfer, ACH, wire, SWIFT, cryptocurrencies and more.</div>
                            </div>
                        </div>
                    </div>
                    <div class="image-box">
                        <div class="hide-mobile-portrait"><img
                                src="https://cdn.prod.website-files.com/668b3733f80ed0dcd2c46207/668cd589b0b433bab985ae03_feature-1.png"
                                loading="lazy" sizes="(max-width: 720px) 100vw, 720px"
                                srcset="https://cdn.prod.website-files.com/668b3733f80ed0dcd2c46207/668cd589b0b433bab985ae03_feature-1-p-500.png 500w, https://cdn.prod.website-files.com/668b3733f80ed0dcd2c46207/668cd589b0b433bab985ae03_feature-1.png 720w"
                                alt="Select Deposit Method" /></div>
                        <div class="show-mobile-portrait-only"><img
                                src="https://cdn.prod.website-files.com/668b3733f80ed0dcd2c46207/672dc3ae2e95c584b8bfa41c_payment-method-freedom.svg"
                                loading="lazy" alt="Conversion" /></div>
                    </div>
                </div>
                <div data-show="false" data-anim-show-up="2" class="features-box">
                    <div class="margin-bottom-56 set-margin-bottom-48">
                        <div class="list-box">
                            <div class="embed hide-this w-embed"><svg width="48" height="48" viewBox="0 0 48 48"
                                    fill="none" xmlns="http://www.w3.org/2000/svg">
                                    <path
                                        d="M20.2256 13.0875C19.6647 14.4925 19.2445 15.9496 18.9713 17.4375H29.0287C28.7549 15.9495 28.3341 14.4924 27.7725 13.0875C27.2081 11.7131 26.5575 10.6612 25.8825 9.96937C25.2113 9.27937 24.5756 9 24 9C23.4244 9 22.7888 9.27937 22.1175 9.96937C21.4425 10.6631 20.7919 11.7131 20.2256 13.0875ZM20.0456 9.52687C19.4569 10.3256 18.9394 11.2912 18.4931 12.3731C17.8931 13.8356 17.4056 15.5494 17.0644 17.4375H10.5075C11.4441 15.517 12.7792 13.8181 14.4238 12.454C16.0685 11.09 17.985 10.0921 20.0456 9.52687ZM27.9562 9.52687C28.5431 10.3256 29.0625 11.2912 29.5069 12.3731C30.1069 13.8356 30.5944 15.5494 30.9356 17.4375H37.4925C36.5559 15.517 35.2208 13.8181 33.5762 12.454C31.9315 11.09 30.0169 10.0921 27.9562 9.52687ZM38.2537 19.3125H31.2187C31.4025 20.8031 31.5 22.3763 31.5 24C31.5 25.6238 31.4025 27.1969 31.2187 28.6875H38.2537C38.7497 27.1745 39.0016 25.5922 39 24C39.0016 22.4078 38.7497 20.8255 38.2537 19.3125ZM37.4925 30.5625H30.9356C30.5944 32.4506 30.1087 34.1663 29.5069 35.625C29.1063 36.6332 28.5857 37.5895 27.9562 38.4731C30.0165 37.9077 31.9326 36.9097 33.577 35.5456C35.2213 34.1816 36.5561 32.4828 37.4925 30.5625ZM24 39C24.5756 39 25.2113 38.7206 25.8825 38.0306C26.5575 37.3369 27.2081 36.2869 27.7725 34.9125C28.3341 33.5076 28.7549 32.0505 29.0287 30.5625H18.9713C19.2863 32.1994 19.7156 33.6694 20.2275 34.9125C20.7919 36.2869 21.4425 37.3388 22.1175 38.0306C22.7888 38.7206 23.4244 39 24 39ZM20.0438 38.4731C17.9838 37.9074 16.0681 36.9093 14.4241 35.5453C12.7801 34.1813 11.4455 32.4826 10.5094 30.5625H17.0663C17.4075 32.4506 17.8931 34.1663 18.495 35.625C18.9394 36.7088 19.4588 37.6744 20.0475 38.4731M9.74813 28.6875H16.7813C16.5943 27.132 16.5004 25.5667 16.5 24C16.5 22.3763 16.5975 20.8031 16.7813 19.3125H9.74626C9.2503 20.8255 8.9984 22.4078 9.00001 24C9.00001 25.6369 9.26438 27.2119 9.74813 28.6875ZM18.375 24C18.375 22.3594 18.48 20.7844 18.6713 19.3125H29.3287C29.52 20.7844 29.625 22.3594 29.625 24C29.625 25.6406 29.52 27.2138 29.3287 28.6875H18.6713C18.4695 27.1332 18.3705 25.5673 18.375 24Z"
                                        fill="#E9394B" />
                                    <g style="mix-blend-mode:plus-lighter" opacity="0.5">
                                        <path fill-rule="evenodd" clip-rule="evenodd"
                                            d="M10 30C13.3137 30 16 27.3137 16 24C16 20.6863 13.3137 18 10 18C6.68629 18 4 20.6863 4 24C4 27.3137 6.68629 30 10 30ZM10.4903 26.9164V27.6H9.75913V26.9057C9.50603 26.8758 9.26517 26.8177 9.03655 26.7314C8.69247 26.5994 8.39426 26.4165 8.14193 26.1829C7.89533 25.9441 7.71469 25.6673 7.59999 25.3524L8.57204 24.979C8.72687 25.3041 8.95053 25.5606 9.243 25.7486C9.40378 25.8491 9.57583 25.922 9.75913 25.9672V24.4262L9.34623 24.3086C8.8473 24.1714 8.47168 23.9657 8.21935 23.6914C7.96702 23.4171 7.84085 23.0946 7.84085 22.7238C7.84085 22.3987 7.92974 22.1117 8.10752 21.8629C8.29103 21.614 8.54336 21.4209 8.86451 21.2838C9.132 21.1674 9.4302 21.0987 9.75913 21.0775V20.4H10.4903V21.1087C10.6831 21.139 10.8666 21.1872 11.0409 21.2533C11.362 21.3702 11.6373 21.5352 11.8667 21.7486C12.1018 21.9568 12.2767 22.2032 12.3914 22.4876L11.428 22.8686C11.3018 22.5841 11.1125 22.3657 10.8602 22.2133C10.7452 22.1416 10.6219 22.0862 10.4903 22.0471V23.5938L10.8688 23.699C11.3792 23.8463 11.7606 24.0495 12.0129 24.3086C12.271 24.5676 12.4 24.8876 12.4 25.2686C12.4 25.5936 12.3054 25.8806 12.1161 26.1295C11.9269 26.3784 11.6659 26.574 11.3333 26.7162C11.0831 26.8232 10.8021 26.8899 10.4903 26.9164ZM10.4903 24.6345V26.0063C10.5909 25.9925 10.6827 25.9701 10.7656 25.939C10.9204 25.8781 11.038 25.7968 11.1183 25.6952C11.2043 25.5936 11.2473 25.4717 11.2473 25.3295C11.2473 25.1619 11.19 25.0248 11.0753 24.9181C10.9663 24.8063 10.8 24.72 10.5763 24.659L10.4903 24.6345ZM9.75913 21.9919C9.65342 22.0065 9.55593 22.0321 9.46666 22.0686C9.31756 22.1244 9.19999 22.2057 9.11397 22.3124C9.03368 22.414 8.99354 22.5359 8.99354 22.6781C8.99354 22.8356 9.05089 22.9752 9.16558 23.0971C9.28028 23.214 9.45519 23.3054 9.69032 23.3714L9.75913 23.3906V21.9919Z"
                                            fill="white" />
                                    </g>
                                    <g style="mix-blend-mode:plus-lighter" opacity="0.5">
                                        <path fill-rule="evenodd" clip-rule="evenodd"
                                            d="M38 18C41.3137 18 44 15.3137 44 12C44 8.68629 41.3137 6 38 6C34.6863 6 32 8.68629 32 12C32 15.3137 34.6863 18 38 18ZM37.0684 15.3378C37.4554 15.5126 37.8767 15.6 38.3324 15.6C38.7568 15.6 39.1469 15.5251 39.5027 15.3753C39.8648 15.2255 40.1737 15.0164 40.4296 14.748C40.6918 14.4733 40.8853 14.1456 41.0101 13.7649L39.8585 13.3248C39.7337 13.6744 39.5371 13.949 39.2687 14.1488C39.0003 14.3485 38.6882 14.4484 38.3324 14.4484C37.9579 14.4484 37.627 14.3454 37.3399 14.1394C37.059 13.9334 36.8374 13.6463 36.6752 13.278C36.646 13.2081 36.6196 13.1363 36.5959 13.0627H38.5664V12.2762H36.4504C36.4442 12.1847 36.4411 12.091 36.4411 11.9953C36.4411 11.8993 36.4443 11.8057 36.4508 11.7144H38.5664V10.928H36.6064C36.6299 10.8606 36.656 10.795 36.6845 10.7313C36.8468 10.3631 37.0715 10.0728 37.3586 9.86059C37.6458 9.64837 37.9703 9.54226 38.3324 9.54226C38.6882 9.54226 39.0003 9.64213 39.2687 9.84187C39.5371 10.0416 39.7337 10.3194 39.8585 10.6752L41.0101 10.2351C40.8229 9.6671 40.4889 9.2208 40.0083 8.89622C39.5277 8.56541 38.9722 8.4 38.3417 8.4C37.8736 8.4 37.446 8.48738 37.059 8.66215C36.672 8.83693 36.335 9.0866 36.0478 9.41118C35.767 9.72951 35.5485 10.1071 35.3925 10.5441C35.3499 10.6683 35.3134 10.7962 35.2829 10.928H34.4V11.7144H35.175C35.1702 11.8066 35.1677 11.9002 35.1677 11.9953C35.1677 12.0903 35.1702 12.184 35.1753 12.2762H34.4V13.0627H35.2865C35.3185 13.1974 35.3569 13.3284 35.4018 13.4559C35.5579 13.8928 35.7763 14.2736 36.0572 14.5982C36.3443 14.9165 36.6814 15.1631 37.0684 15.3378Z"
                                            fill="white" />
                                    </g>
                                    <g style="mix-blend-mode:plus-lighter" opacity="0.5">
                                        <path fill-rule="evenodd" clip-rule="evenodd"
                                            d="M32 42C35.3137 42 38 39.3137 38 36C38 32.6863 35.3137 30 32 30C28.6863 30 26 32.6863 26 36C26 39.3137 28.6863 42 32 42ZM31.3428 38.1987V39.6H32.6669V38.1987H34.0295V37.3868H32.6669V36.807H34.0295V36.0048H32.9061L35.083 32.4H33.585L32.0041 35.0816L30.415 32.4H28.9171L31.0973 36.0048H29.9705V36.807H31.3428V37.3868H29.9705V38.1987H31.3428Z"
                                            fill="white" />
                                    </g>
                                </svg></div>
                            <div class="box-48">
                                <div data-w-id="8d4f09c9-0aff-bc1a-4fde-0311b4cce3be" data-animation-type="lottie"
                                    data-src="https://cdn.prod.website-files.com/668b3733f80ed0dcd2c46207/66d9610d5fc11c9bd7a802f3_International%20multi-currency.lottie"
                                    data-loop="1" data-direction="1" data-autoplay="1" data-is-ix2-target="0"
                                    data-renderer="svg" data-default-duration="4.983333333333333" data-duration="0">
                                </div>
                            </div>
                            <div>
                                <div class="margin-bottom-8">
                                    <h3>International multi-currency support</h3>
                                </div>
                                <div class="text-color-gray-300">No matter where you are in the world, you can send funds to AdsAsia. We will handle all currency conversion and assist you with the payment requirements for your account and campaigns.
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="image-box">
                        <div class="hide-mobile-portrait"><img
                                src="https://cdn.prod.website-files.com/668b3733f80ed0dcd2c46207/66c5833aeb05b91933beaa09_currency-support.png"
                                loading="lazy" sizes="(max-width: 720px) 100vw, 720px"
                                srcset="https://cdn.prod.website-files.com/668b3733f80ed0dcd2c46207/66c5833aeb05b91933beaa09_currency-support-p-500.png 500w, https://cdn.prod.website-files.com/668b3733f80ed0dcd2c46207/66c5833aeb05b91933beaa09_currency-support.png 720w"
                                alt="Support" /></div>
                        <div class="show-mobile-portrait-only"><img
                                src="https://cdn.prod.website-files.com/668b3733f80ed0dcd2c46207/672dc3aeea785e5eb3339523_convert-currency.svg"
                                loading="lazy" alt="Conversion" /></div>
                    </div>
                </div>
                <div data-show="false" data-anim-show-up="3" class="features-box">
                    <div class="margin-bottom-56 set-margin-bottom-48">
                        <div class="list-box">
                            <div class="embed hide-this w-embed"><svg width="48" height="48" viewBox="0 0 48 48"
                                    fill="none" xmlns="http://www.w3.org/2000/svg">
                                    <path
                                        d="M10.0001 20.3291C12.2063 20.3291 14.0001 18.4713 14.0001 16.1862C14.0001 13.9011 12.2063 12.0433 10.0001 12.0433C7.79379 12.0433 6.00002 13.9011 6.00002 16.1862C6.00002 18.4713 7.79379 20.3291 10.0001 20.3291ZM24.0002 22.4005C27.869 22.4005 31.0003 19.1574 31.0003 15.1505C31.0003 11.1435 27.869 7.90039 24.0002 7.90039C20.1314 7.90039 17.0001 11.1435 17.0001 15.1505C17.0001 19.1574 20.1314 22.4005 24.0002 22.4005ZM28.8002 24.472H28.2815C26.9815 25.1193 25.5377 25.5077 24.0002 25.5077C22.4627 25.5077 21.0252 25.1193 19.7189 24.472H19.2002C15.2251 24.472 12.0001 27.8122 12.0001 31.9292V33.7935C12.0001 35.5089 13.3438 36.9007 15.0001 36.9007H33.0003C34.6566 36.9007 36.0003 35.5089 36.0003 33.7935V31.9292C36.0003 27.8122 32.7753 24.472 28.8002 24.472ZM14.8189 23.6046C14.0939 22.8601 13.1001 22.4005 12.0001 22.4005H8.00004C5.79377 22.4005 4 24.2584 4 26.5434V28.6149C4 29.7607 4.89376 30.6863 6.00002 30.6863H10.1188C10.5126 27.618 12.3001 25.0352 14.8189 23.6046Z"
                                        fill="#E9394B" />
                                    <g style="mix-blend-mode:plus-lighter" opacity="0.5">
                                        <path fill-rule="evenodd" clip-rule="evenodd"
                                            d="M22 26C19.7909 26 18 27.7909 18 30C18 32.2091 19.7909 34 22 34H40C42.2091 34 44 32.2091 44 30C44 27.7909 42.2091 26 40 26H22ZM22 32C23.1046 32 24 31.1046 24 30C24 28.8954 23.1046 28 22 28C20.8954 28 20 28.8954 20 30C20 31.1046 20.8954 32 22 32Z"
                                            fill="white" />
                                    </g>
                                    <g style="mix-blend-mode:plus-lighter" opacity="0.5">
                                        <path fill-rule="evenodd" clip-rule="evenodd"
                                            d="M40 36C42.2091 36 44 37.7909 44 40C44 42.2091 42.2091 44 40 44H22C19.7909 44 18 42.2091 18 40C18 37.7909 19.7909 36 22 36H40ZM40 42C38.8954 42 38 41.1046 38 40C38 38.8954 38.8954 38 40 38C41.1046 38 42 38.8954 42 40C42 41.1046 41.1046 42 40 42Z"
                                            fill="white" />
                                    </g>
                                </svg></div>
                            <div class="box-48">
                                <div data-w-id="0d31b41d-b56d-94a7-bcfe-b0b7787b876a" data-animation-type="lottie"
                                    data-src="https://cdn.prod.website-files.com/668b3733f80ed0dcd2c46207/66d9610dd240d83f9ce82a4b_Manage%20accounts.lottie"
                                    data-loop="1" data-direction="1" data-autoplay="1" data-is-ix2-target="0"
                                    data-renderer="svg" data-default-duration="4.983333333333333" data-duration="0">
                                </div>
                            </div>
                            <div>
                                <div class="margin-bottom-8">
                                    <h3>Manage accounts anytime, anywhere</h3>
                                </div>
                                <div class="text-color-gray-300">Never worry about breaching circumvention rules when managing your advertising accounts with AdsAsia. With our dedicated App, you can manage your accounts from anywhere, on any device.</div>
                            </div>
                        </div>
                    </div>
                    <div class="image-box">
                        <div class="hide-mobile-portrait"><img
                                src="https://cdn.prod.website-files.com/668b3733f80ed0dcd2c46207/668cd58971bea816147d3556_feature-3.png"
                                loading="lazy" sizes="(max-width: 720px) 100vw, 720px"
                                srcset="https://cdn.prod.website-files.com/668b3733f80ed0dcd2c46207/668cd58971bea816147d3556_feature-3-p-500.png 500w, https://cdn.prod.website-files.com/668b3733f80ed0dcd2c46207/668cd58971bea816147d3556_feature-3.png 720w"
                                alt="Agency Ad Accounts" /></div>
                        <div class="show-mobile-portrait-only"><img
                                src="https://cdn.prod.website-files.com/668b3733f80ed0dcd2c46207/672dc3aeea785e5eb333953a_mini-dashboard.svg"
                                loading="lazy" alt="Agency Ad Accounts" /></div>
                    </div>
                </div>
                <div data-show="false" data-anim-show-up="4" class="features-box">
                    <div class="margin-bottom-56 set-margin-bottom-48">
                        <div class="list-box">
                            <div class="embed hide-this w-embed"><svg width="48" height="48" viewBox="0 0 48 48"
                                    fill="none" xmlns="http://www.w3.org/2000/svg">
                                    <path
                                        d="M7.63655 24C7.63655 22.3123 8.307 20.6936 9.5004 19.5002C10.6938 18.3068 12.3124 17.6364 14.0001 17.6364C16.1892 17.6364 17.6728 18.4255 18.9091 19.66C20.2291 20.9818 21.2455 22.7873 22.4109 24.8836L22.4727 24.9927C23.5636 26.96 24.8054 29.1945 26.5218 30.9109C28.3545 32.7436 30.7327 34 33.9999 34C35.6748 34 37.3228 33.5794 38.7928 32.7766C40.2628 31.9739 41.5076 30.8148 42.413 29.4057C43.3184 27.9966 43.8554 26.3826 43.9746 24.712C44.0939 23.0413 43.7916 21.3675 43.0955 19.8441C42.3994 18.3206 41.3319 16.9965 39.9908 15.9931C38.6497 14.9897 37.0781 14.3392 35.4202 14.1014C33.7623 13.8635 32.0712 14.0459 30.5021 14.6318C28.933 15.2177 27.5363 16.1883 26.44 17.4545C27.1705 18.5487 27.8512 19.6753 28.4799 20.8309C29.0365 19.8617 29.8385 19.0563 30.8052 18.4955C31.7719 17.9347 32.8693 17.6384 33.9869 17.6364C35.1045 17.6344 36.2029 17.9267 37.1716 18.484C38.1403 19.0414 38.9452 19.844 39.5052 20.8111C40.0653 21.7783 40.3607 22.8759 40.3618 23.9935C40.363 25.1111 40.0698 26.2093 39.5117 27.1776C38.9537 28.1459 38.1505 28.9502 37.1829 29.5095C36.2153 30.0687 35.1175 30.3634 33.9999 30.3636C31.8126 30.3636 30.3272 29.5745 29.0909 28.34C27.7709 27.0182 26.7545 25.2127 25.5891 23.1164L25.5273 23.0073C24.4364 21.04 23.1946 18.8055 21.4782 17.0891C19.6455 15.2564 17.2674 14 14.0001 14C12.3252 14 10.6772 14.4206 9.20717 15.2234C7.73718 16.0261 6.49237 17.1852 5.58698 18.5943C4.68159 20.0034 4.14463 21.6174 4.02538 23.288C3.90613 24.9587 4.20842 26.6325 4.90449 28.1559C5.60057 29.6794 6.66813 31.0035 8.0092 32.0069C9.35027 33.0103 10.9219 33.6608 12.5798 33.8986C14.2377 34.1365 15.9288 33.9541 17.4979 33.3682C19.067 32.7823 20.4637 31.8117 21.56 30.5455C20.8295 29.4513 20.1488 28.3247 19.5201 27.1691C18.8222 28.3858 17.7419 29.3378 16.4471 29.8771C15.1523 30.4165 13.7156 30.513 12.3604 30.1515C11.0052 29.7901 9.80728 28.9911 8.95301 27.8786C8.09874 26.7662 7.63594 25.4026 7.63655 24Z"
                                        fill="#E9394B" />
                                    <g style="mix-blend-mode:plus-lighter" opacity="0.5">
                                        <path fill-rule="evenodd" clip-rule="evenodd"
                                            d="M33.9056 28.8111C36.6148 28.8111 38.8111 26.6148 38.8111 23.9056C38.8111 21.1963 36.6148 19 33.9056 19C31.1963 19 29 21.1963 29 23.9056C29 26.6148 31.1963 28.8111 33.9056 28.8111ZM35.4664 22.2703C35.4664 23.174 34.7682 23.9055 33.9056 23.9055C33.0429 23.9055 32.3447 23.174 32.3447 22.2703C32.3447 21.3666 33.0429 20.6351 33.9056 20.6351C34.7682 20.6351 35.4664 21.3666 35.4664 22.2703ZM34.8602 24.3727H34.9759C35.8622 24.3727 36.5813 25.1261 36.5813 26.0546V26.4751C36.5813 26.862 36.2817 27.1759 35.9124 27.1759H31.8987C31.5294 27.1759 31.2298 26.862 31.2298 26.4751V26.0546C31.2298 25.1261 31.9489 24.3727 32.8353 24.3727H32.9509C33.2422 24.5187 33.5627 24.6063 33.9056 24.6063C34.2484 24.6063 34.5703 24.5187 34.8602 24.3727Z"
                                            fill="white" />
                                    </g>
                                    <g style="mix-blend-mode:plus-lighter" opacity="0.5">
                                        <path fill-rule="evenodd" clip-rule="evenodd"
                                            d="M13.9056 28.8111C16.6148 28.8111 18.8111 26.6148 18.8111 23.9056C18.8111 21.1963 16.6148 19 13.9056 19C11.1963 19 9 21.1963 9 23.9056C9 26.6148 11.1963 28.8111 13.9056 28.8111ZM15.4664 22.2703C15.4664 23.174 14.7682 23.9055 13.9056 23.9055C13.0429 23.9055 12.3447 23.174 12.3447 22.2703C12.3447 21.3666 13.0429 20.6351 13.9056 20.6351C14.7682 20.6351 15.4664 21.3666 15.4664 22.2703ZM14.8602 24.3727H14.9759C15.8622 24.3727 16.5813 25.1261 16.5813 26.0546V26.4751C16.5813 26.862 16.2817 27.1759 15.9124 27.1759H11.8987C11.5294 27.1759 11.2298 26.862 11.2298 26.4751V26.0546C11.2298 25.1261 11.9489 24.3727 12.8353 24.3727H12.9509C13.2422 24.5187 13.5627 24.6063 13.9056 24.6063C14.2484 24.6063 14.5703 24.5187 14.8602 24.3727Z"
                                            fill="white" />
                                    </g>
                                    <g style="mix-blend-mode:plus-lighter" opacity="0.5">
                                        <path fill-rule="evenodd" clip-rule="evenodd"
                                            d="M23.9056 13.8111C26.6148 13.8111 28.8111 11.6148 28.8111 8.90556C28.8111 6.19629 26.6148 4 23.9056 4C21.1963 4 19 6.19629 19 8.90556C19 11.6148 21.1963 13.8111 23.9056 13.8111ZM25.4664 7.27032C25.4664 8.17405 24.7682 8.9055 23.9056 8.9055C23.0429 8.9055 22.3447 8.17405 22.3447 7.27032C22.3447 6.36659 23.0429 5.63513 23.9056 5.63513C24.7682 5.63513 25.4664 6.36659 25.4664 7.27032ZM24.8602 9.3727H24.9759C25.8622 9.3727 26.5813 10.1261 26.5813 11.0546V11.4751C26.5813 11.862 26.2817 12.1759 25.9124 12.1759H21.8987C21.5294 12.1759 21.2298 11.862 21.2298 11.4751V11.0546C21.2298 10.1261 21.9489 9.3727 22.8353 9.3727H22.9509C23.2422 9.5187 23.5627 9.6063 23.9056 9.6063C24.2484 9.6063 24.5703 9.5187 24.8602 9.3727Z"
                                            fill="white" />
                                    </g>
                                    <g style="mix-blend-mode:plus-lighter" opacity="0.5">
                                        <path fill-rule="evenodd" clip-rule="evenodd"
                                            d="M23.9056 43.8111C26.6148 43.8111 28.8111 41.6148 28.8111 38.9056C28.8111 36.1963 26.6148 34 23.9056 34C21.1963 34 19 36.1963 19 38.9056C19 41.6148 21.1963 43.8111 23.9056 43.8111ZM25.4664 37.2703C25.4664 38.174 24.7682 38.9055 23.9056 38.9055C23.0429 38.9055 22.3447 38.174 22.3447 37.2703C22.3447 36.3666 23.0429 35.6351 23.9056 35.6351C24.7682 35.6351 25.4664 36.3666 25.4664 37.2703ZM24.8602 39.3727H24.9759C25.8622 39.3727 26.5813 40.1261 26.5813 41.0546V41.4751C26.5813 41.862 26.2817 42.1759 25.9124 42.1759H21.8987C21.5294 42.1759 21.2298 41.862 21.2298 41.4751V41.0546C21.2298 40.1261 21.9489 39.3727 22.8353 39.3727H22.9509C23.2422 39.5187 23.5627 39.6063 23.9056 39.6063C24.2484 39.6063 24.5703 39.5187 24.8602 39.3727Z"
                                            fill="white" />
                                    </g>
                                </svg></div>
                            <div class="box-48">
                                <div data-w-id="2e6b48cc-80c2-8928-a40b-56052978774f" data-animation-type="lottie"
                                    data-src="https://cdn.prod.website-files.com/668b3733f80ed0dcd2c46207/66d9610d9eec7ad5e90d50b6_Unlimited%20accounts.lottie"
                                    data-loop="1" data-direction="1" data-autoplay="1" data-is-ix2-target="0"
                                    data-renderer="svg" data-default-duration="4.983333333333333" data-duration="0">
                                </div>
                            </div>
                            <div>
                                <div class="margin-bottom-8">
                                    <h3>Unlimited ad account opening</h3>
                                </div>
                                <div class="text-color-gray-300">Free your business from advertising restrictions by leveraging AdsAsia's status as a leading partner. With us, you can receive unlimited enterprise level advertising accounts for any platform, on demand.</div>
                            </div>
                        </div>
                    </div>
                    <div class="image-box">
                        <div class="hide-mobile-portrait"><img
                                src="https://cdn.prod.website-files.com/668b3733f80ed0dcd2c46207/668cd5898c39cf84da714620_feature-4.png"
                                loading="lazy" sizes="(max-width: 720px) 100vw, 720px"
                                srcset="https://cdn.prod.website-files.com/668b3733f80ed0dcd2c46207/668cd5898c39cf84da714620_feature-4-p-500.png 500w, https://cdn.prod.website-files.com/668b3733f80ed0dcd2c46207/668cd5898c39cf84da714620_feature-4.png 720w"
                                alt="Agency Ad Account Request Status" /></div>
                        <div class="show-mobile-portrait-only"><img
                                src="https://cdn.prod.website-files.com/668b3733f80ed0dcd2c46207/672dc3ae015375128466d156_account-status.svg"
                                loading="lazy" alt="Agency Ad Account Request Status" /></div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<div class="section_platform-testimonials">
    <div class="padding-global">
        <div class="container-1600">
            <div class="margin-bottom-48">
                <div class="header-section">
                    <div class="header-tag">
                        <div>Testimonials</div>
                    </div>
                    <h2 class="text-color-gray-200">What our clients say</h2>
                    <div class="text-size-20 text-color-gray-300 set-text-size-18">Read real reviews and success stories from our satisfied clients.</div>
                </div>
            </div>
            <div data-delay="3000" data-animation="slide" class="testimonial-slider w-slider" data-autoplay="true"
                data-easing="ease" data-hide-arrows="false" data-disable-swipe="false" data-autoplay-limit="0"
                data-nav-spacing="3" data-duration="500" data-infinite="true">
                <div class="w-slider-mask">
                    <div class="w-slide">
                        <div class="platform-testimonial-slide hide-this">
                            <div class="max-width-312">
                                <div class="testimonial-client-score">
                                    <div>
                                        <div class="margin-bottom-8">
                                            <div class="heading-64 text-weight-bold line-height-1">5</div>
                                        </div>
                                        <div class="margin-bottom-16">
                                            <div class="text-size-14">Client’s score</div>
                                        </div>
                                        <div class="testimonial-rating-box">
                                            <div class="embed w-embed"><svg width="25" height="25" viewBox="0 0 25 25"
                                                    fill="none" xmlns="http://www.w3.org/2000/svg">
                                                    <rect width="24.1379" height="24.1379"
                                                        transform="translate(0 0.484863)" fill="#219653" />
                                                    <path
                                                        d="M12.0689 16.9904L15.7399 16.0074L17.2736 21.002L12.0689 16.9904ZM20.5172 10.5347H14.0552L12.0689 4.10547L10.0825 10.5347H3.62061L8.85049 14.5197L6.86414 20.9489L12.094 16.9638L15.3124 14.5197L20.5172 10.5347Z"
                                                        fill="white" />
                                                </svg></div>
                                            <div class="embed w-embed"><svg width="25" height="25" viewBox="0 0 25 25"
                                                    fill="none" xmlns="http://www.w3.org/2000/svg">
                                                    <rect width="24.1379" height="24.1379"
                                                        transform="translate(0 0.484863)" fill="#219653" />
                                                    <path
                                                        d="M12.0689 16.9904L15.7399 16.0074L17.2736 21.002L12.0689 16.9904ZM20.5172 10.5347H14.0552L12.0689 4.10547L10.0825 10.5347H3.62061L8.85049 14.5197L6.86414 20.9489L12.094 16.9638L15.3124 14.5197L20.5172 10.5347Z"
                                                        fill="white" />
                                                </svg></div>
                                            <div class="embed w-embed"><svg width="25" height="25" viewBox="0 0 25 25"
                                                    fill="none" xmlns="http://www.w3.org/2000/svg">
                                                    <rect width="24.1379" height="24.1379"
                                                        transform="translate(0 0.484863)" fill="#219653" />
                                                    <path
                                                        d="M12.0689 16.9904L15.7399 16.0074L17.2736 21.002L12.0689 16.9904ZM20.5172 10.5347H14.0552L12.0689 4.10547L10.0825 10.5347H3.62061L8.85049 14.5197L6.86414 20.9489L12.094 16.9638L15.3124 14.5197L20.5172 10.5347Z"
                                                        fill="white" />
                                                </svg></div>
                                            <div class="embed w-embed"><svg width="25" height="25" viewBox="0 0 25 25"
                                                    fill="none" xmlns="http://www.w3.org/2000/svg">
                                                    <rect width="24.1379" height="24.1379"
                                                        transform="translate(0 0.484863)" fill="#219653" />
                                                    <path
                                                        d="M12.0689 16.9904L15.7399 16.0074L17.2736 21.002L12.0689 16.9904ZM20.5172 10.5347H14.0552L12.0689 4.10547L10.0825 10.5347H3.62061L8.85049 14.5197L6.86414 20.9489L12.094 16.9638L15.3124 14.5197L20.5172 10.5347Z"
                                                        fill="white" />
                                                </svg></div>
                                            <div class="embed w-embed"><svg width="25" height="25" viewBox="0 0 25 25"
                                                    fill="none" xmlns="http://www.w3.org/2000/svg">
                                                    <rect width="24.1379" height="24.1379"
                                                        transform="translate(0 0.484863)" fill="#219653" />
                                                    <path
                                                        d="M12.0689 16.9904L15.7399 16.0074L17.2736 21.002L12.0689 16.9904ZM20.5172 10.5347H14.0552L12.0689 4.10547L10.0825 10.5347H3.62061L8.85049 14.5197L6.86414 20.9489L12.094 16.9638L15.3124 14.5197L20.5172 10.5347Z"
                                                        fill="white" />
                                                </svg></div>
                                        </div>
                                    </div>
                                    <div class="testimonial-logo-bottom">
                                        <div><img loading="lazy"
                                                src="https://cdn.prod.website-files.com/668b3733f80ed0dcd2c46207/668f55e450eeb735f8c47eb3_Trustpilot%20logo.png"
                                                alt="" /></div>
                                    </div>
                                </div>
                            </div>
                            <div class="inner-line width"></div>
                            <div class="platform-testimonial-content">
                                <div class="embed w-embed"><svg width="48" height="49" viewBox="0 0 48 49" fill="none"
                                        xmlns="http://www.w3.org/2000/svg">
                                        <path d="M0 6.05371V42.0537L18 24.0537V6.05371H0Z" fill="#D5283A" />
                                        <path d="M30 6.05371V42.0537L48 24.0537V6.05371H30Z" fill="#D5283A" />
                                    </svg></div>
                                <div>
                                    <div class="margin-bottom-8">
                                        <h3>Fast, helpful AdsAsia team</h3>
                                    </div>
                                    <div class="max-width-852">
                                        <div class="text-color-gray-300">As a small business owner, I was
                                            always restricted when running ads for my own product line.
                                            AdsAsia provided a smooth solution and now I can finally
                                            advertise!</div>
                                    </div>
                                </div>
                                <div class="testimonial-link-box">
                                    <div class="testimonial-author-box">
                                        <div class="text-size-18 text-weight-bold">—</div>
                                        <div class="text-color-gray-300">Matthew Colby, France</div>
                                    </div><a href="https://uk.trustpilot.com/users/66c0f8a75635e909b6de844a"
                                        target="_blank" class="testimonial-link-source w-inline-block">
                                        <div class="text-size-18 text-weight-bold">Source</div>
                                        <div class="embed w-embed"><svg width="24" height="25" viewBox="0 0 24 25"
                                                fill="none" xmlns="http://www.w3.org/2000/svg">
                                                <path d="M7 17.0793L17 7.07935M17 7.07935H7M17 7.07935V17.0793"
                                                    stroke="currentColor" stroke-width="2" stroke-linecap="round"
                                                    stroke-linejoin="round" />
                                            </svg></div>
                                    </a>
                                </div>
                            </div>
                        </div>
                        <div class="w-dyn-list">
                            <div role="list" class="w-dyn-items">
                                <div role="listitem" class="w-dyn-item">
                                    <div class="platform-testimonial-slide">
                                        <div class="max-width-312 set-max-width-none">
                                            <div class="testimonial-client-score">
                                                <div class="set-text-align-left">
                                                    <div class="margin-bottom-8">
                                                        <div class="heading-64 text-weight-bold line-height-1">
                                                            5</div>
                                                    </div>
                                                    <div class="margin-bottom-16 set-margin-bottom-24">
                                                        <div class="text-size-14">Client’s score</div>
                                                    </div>
                                                    <div class="testimonial-rating-box">
                                                        <div class="embed w-embed"><svg width="25" height="25"
                                                                viewBox="0 0 25 25" fill="none"
                                                                xmlns="http://www.w3.org/2000/svg">
                                                                <rect width="24.1379" height="24.1379"
                                                                    transform="translate(0 0.484863)" fill="#219653" />
                                                                <path
                                                                    d="M12.0689 16.9904L15.7399 16.0074L17.2736 21.002L12.0689 16.9904ZM20.5172 10.5347H14.0552L12.0689 4.10547L10.0825 10.5347H3.62061L8.85049 14.5197L6.86414 20.9489L12.094 16.9638L15.3124 14.5197L20.5172 10.5347Z"
                                                                    fill="white" />
                                                            </svg></div>
                                                        <div class="embed w-embed"><svg width="25" height="25"
                                                                viewBox="0 0 25 25" fill="none"
                                                                xmlns="http://www.w3.org/2000/svg">
                                                                <rect width="24.1379" height="24.1379"
                                                                    transform="translate(0 0.484863)" fill="#219653" />
                                                                <path
                                                                    d="M12.0689 16.9904L15.7399 16.0074L17.2736 21.002L12.0689 16.9904ZM20.5172 10.5347H14.0552L12.0689 4.10547L10.0825 10.5347H3.62061L8.85049 14.5197L6.86414 20.9489L12.094 16.9638L15.3124 14.5197L20.5172 10.5347Z"
                                                                    fill="white" />
                                                            </svg></div>
                                                        <div class="embed w-embed"><svg width="25" height="25"
                                                                viewBox="0 0 25 25" fill="none"
                                                                xmlns="http://www.w3.org/2000/svg">
                                                                <rect width="24.1379" height="24.1379"
                                                                    transform="translate(0 0.484863)" fill="#219653" />
                                                                <path
                                                                    d="M12.0689 16.9904L15.7399 16.0074L17.2736 21.002L12.0689 16.9904ZM20.5172 10.5347H14.0552L12.0689 4.10547L10.0825 10.5347H3.62061L8.85049 14.5197L6.86414 20.9489L12.094 16.9638L15.3124 14.5197L20.5172 10.5347Z"
                                                                    fill="white" />
                                                            </svg></div>
                                                        <div class="embed w-embed"><svg width="25" height="25"
                                                                viewBox="0 0 25 25" fill="none"
                                                                xmlns="http://www.w3.org/2000/svg">
                                                                <rect width="24.1379" height="24.1379"
                                                                    transform="translate(0 0.484863)" fill="#219653" />
                                                                <path
                                                                    d="M12.0689 16.9904L15.7399 16.0074L17.2736 21.002L12.0689 16.9904ZM20.5172 10.5347H14.0552L12.0689 4.10547L10.0825 10.5347H3.62061L8.85049 14.5197L6.86414 20.9489L12.094 16.9638L15.3124 14.5197L20.5172 10.5347Z"
                                                                    fill="white" />
                                                            </svg></div>
                                                        <div class="embed w-embed"><svg width="25" height="25"
                                                                viewBox="0 0 25 25" fill="none"
                                                                xmlns="http://www.w3.org/2000/svg">
                                                                <rect width="24.1379" height="24.1379"
                                                                    transform="translate(0 0.484863)" fill="#219653" />
                                                                <path
                                                                    d="M12.0689 16.9904L15.7399 16.0074L17.2736 21.002L12.0689 16.9904ZM20.5172 10.5347H14.0552L12.0689 4.10547L10.0825 10.5347H3.62061L8.85049 14.5197L6.86414 20.9489L12.094 16.9638L15.3124 14.5197L20.5172 10.5347Z"
                                                                    fill="white" />
                                                            </svg></div>
                                                    </div>
                                                </div>
                                                <div class="testimonial-logo-bottom"><a
                                                        href="https://uk.trustpilot.com/reviews/66f2bf88c73148e80b938e33"
                                                        target="_blank" class="testimonial-link-source w-inline-block">
                                                        <div class="text-size-18 text-weight-bold set-text-size-14">
                                                            Source</div>
                                                        <div class="fix-24">
                                                            <div data-button-icon="hover" class="embed w-embed"><svg
                                                                    width="24" height="24" viewBox="0 0 24 24"
                                                                    fill="none" xmlns="http://www.w3.org/2000/svg">
                                                                    <path d="M5 12H19M19 12L12 5M19 12L12 19"
                                                                        stroke="currentColor" stroke-width="2"
                                                                        stroke-linecap="round"
                                                                        stroke-linejoin="round" />
                                                                </svg></div>
                                                            <div data-button-icon="normal" class="embed w-embed"><svg
                                                                    width="24" height="24" viewBox="0 0 24 24"
                                                                    fill="none" xmlns="http://www.w3.org/2000/svg">
                                                                    <path d="M9 18L15 12L9 6" stroke="white"
                                                                        stroke-width="2" stroke-linecap="round"
                                                                        stroke-linejoin="round" />
                                                                </svg></div>
                                                        </div>
                                                    </a>
                                                    <div><img loading="lazy"
                                                            src="https://cdn.prod.website-files.com/668b3733f80ed0dcd2c46207/668f55e450eeb735f8c47eb3_Trustpilot%20logo.png"
                                                            alt="" /></div>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="inner-line width"></div>
                                        <div class="platform-testimonial-content">
                                            <div class="embed w-embed"><svg width="48" height="49" viewBox="0 0 48 49"
                                                    fill="none" xmlns="http://www.w3.org/2000/svg">
                                                    <path d="M0 6.05371V42.0537L18 24.0537V6.05371H0Z" fill="#D5283A" />
                                                    <path d="M30 6.05371V42.0537L48 24.0537V6.05371H30Z"
                                                        fill="#D5283A" />
                                                </svg></div>
                                            <div>
                                                <div class="margin-bottom-8">
                                                    <h3>JV and his team are amazing</h3>
                                                </div>
                                                <div class="max-width-852">
                                                    <div class="text-color-gray-300">JV and his team are amazing! He is always super quick to respond, and even helps me out on weekends. His dedication and experience in advertising makes a huge difference. I highly recommend!</div>
                                                </div>
                                            </div>
                                            <div class="testimonial-link-box">
                                                <div class="testimonial-author-box">
                                                    <div class="text-size-18 text-weight-bold">—</div>
                                                    <div class="testimonial-box-author">
                                                        <div class="text-color-gray-300">Paulo M</div>
                                                        <div class="text-color-gray-300">, </div>
                                                        <div class="text-color-gray-300">BR</div>
                                                    </div>
                                                </div>
                                                <div class="hide-mobile-landscape"><a
                                                        href="https://uk.trustpilot.com/reviews/66f2bf88c73148e80b938e33"
                                                        target="_blank" class="testimonial-link-source w-inline-block">
                                                        <div class="text-size-18 text-weight-bold">Source
                                                        </div>
                                                        <div class="fix-24">
                                                            <div data-button-icon="hover" class="embed w-embed"><svg
                                                                    width="24" height="24" viewBox="0 0 24 24"
                                                                    fill="none" xmlns="http://www.w3.org/2000/svg">
                                                                    <path d="M5 12H19M19 12L12 5M19 12L12 19"
                                                                        stroke="currentColor" stroke-width="2"
                                                                        stroke-linecap="round"
                                                                        stroke-linejoin="round" />
                                                                </svg></div>
                                                            <div data-button-icon="normal" class="embed w-embed"><svg
                                                                    width="24" height="24" viewBox="0 0 24 24"
                                                                    fill="none" xmlns="http://www.w3.org/2000/svg">
                                                                    <path d="M9 18L15 12L9 6" stroke="white"
                                                                        stroke-width="2" stroke-linecap="round"
                                                                        stroke-linejoin="round" />
                                                                </svg></div>
                                                        </div>
                                                    </a></div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="w-slide">
                        <div class="platform-testimonial-slide hide-this">
                            <div class="max-width-312">
                                <div class="testimonial-client-score">
                                    <div>
                                        <div class="margin-bottom-8">
                                            <div class="heading-64 text-weight-bold line-height-1">5</div>
                                        </div>
                                        <div class="margin-bottom-16">
                                            <div class="text-size-14">Client’s score</div>
                                        </div>
                                        <div class="testimonial-rating-box">
                                            <div class="embed w-embed"><svg width="25" height="25" viewBox="0 0 25 25"
                                                    fill="none" xmlns="http://www.w3.org/2000/svg">
                                                    <rect width="24.1379" height="24.1379"
                                                        transform="translate(0 0.484863)" fill="#219653" />
                                                    <path
                                                        d="M12.0689 16.9904L15.7399 16.0074L17.2736 21.002L12.0689 16.9904ZM20.5172 10.5347H14.0552L12.0689 4.10547L10.0825 10.5347H3.62061L8.85049 14.5197L6.86414 20.9489L12.094 16.9638L15.3124 14.5197L20.5172 10.5347Z"
                                                        fill="white" />
                                                </svg></div>
                                            <div class="embed w-embed"><svg width="25" height="25" viewBox="0 0 25 25"
                                                    fill="none" xmlns="http://www.w3.org/2000/svg">
                                                    <rect width="24.1379" height="24.1379"
                                                        transform="translate(0 0.484863)" fill="#219653" />
                                                    <path
                                                        d="M12.0689 16.9904L15.7399 16.0074L17.2736 21.002L12.0689 16.9904ZM20.5172 10.5347H14.0552L12.0689 4.10547L10.0825 10.5347H3.62061L8.85049 14.5197L6.86414 20.9489L12.094 16.9638L15.3124 14.5197L20.5172 10.5347Z"
                                                        fill="white" />
                                                </svg></div>
                                            <div class="embed w-embed"><svg width="25" height="25" viewBox="0 0 25 25"
                                                    fill="none" xmlns="http://www.w3.org/2000/svg">
                                                    <rect width="24.1379" height="24.1379"
                                                        transform="translate(0 0.484863)" fill="#219653" />
                                                    <path
                                                        d="M12.0689 16.9904L15.7399 16.0074L17.2736 21.002L12.0689 16.9904ZM20.5172 10.5347H14.0552L12.0689 4.10547L10.0825 10.5347H3.62061L8.85049 14.5197L6.86414 20.9489L12.094 16.9638L15.3124 14.5197L20.5172 10.5347Z"
                                                        fill="white" />
                                                </svg></div>
                                            <div class="embed w-embed"><svg width="25" height="25" viewBox="0 0 25 25"
                                                    fill="none" xmlns="http://www.w3.org/2000/svg">
                                                    <rect width="24.1379" height="24.1379"
                                                        transform="translate(0 0.484863)" fill="#219653" />
                                                    <path
                                                        d="M12.0689 16.9904L15.7399 16.0074L17.2736 21.002L12.0689 16.9904ZM20.5172 10.5347H14.0552L12.0689 4.10547L10.0825 10.5347H3.62061L8.85049 14.5197L6.86414 20.9489L12.094 16.9638L15.3124 14.5197L20.5172 10.5347Z"
                                                        fill="white" />
                                                </svg></div>
                                            <div class="embed w-embed"><svg width="25" height="25" viewBox="0 0 25 25"
                                                    fill="none" xmlns="http://www.w3.org/2000/svg">
                                                    <rect width="24.1379" height="24.1379"
                                                        transform="translate(0 0.484863)" fill="#219653" />
                                                    <path
                                                        d="M12.0689 16.9904L15.7399 16.0074L17.2736 21.002L12.0689 16.9904ZM20.5172 10.5347H14.0552L12.0689 4.10547L10.0825 10.5347H3.62061L8.85049 14.5197L6.86414 20.9489L12.094 16.9638L15.3124 14.5197L20.5172 10.5347Z"
                                                        fill="white" />
                                                </svg></div>
                                        </div>
                                    </div>
                                    <div class="testimonial-logo-bottom">
                                        <div><img loading="lazy"
                                                src="https://cdn.prod.website-files.com/668b3733f80ed0dcd2c46207/668f55e450eeb735f8c47eb3_Trustpilot%20logo.png"
                                                alt="" /></div>
                                    </div>
                                </div>
                            </div>
                            <div class="inner-line width"></div>
                            <div class="platform-testimonial-content">
                                <div class="embed w-embed"><svg width="48" height="49" viewBox="0 0 48 49" fill="none"
                                        xmlns="http://www.w3.org/2000/svg">
                                        <path d="M0 6.05371V42.0537L18 24.0537V6.05371H0Z" fill="#D5283A" />
                                        <path d="M30 6.05371V42.0537L48 24.0537V6.05371H30Z" fill="#D5283A" />
                                    </svg></div>
                                <div>
                                    <div class="margin-bottom-8">
                                        <h3>Manager’s advice fixed product issues</h3>
                                    </div>
                                    <div class="max-width-852">
                                        <div class="text-color-gray-300">Whilst trying to run a new product
                                            I ran into some issues. The account manager gave me good advice
                                            and I can now run, very happy with the results.</div>
                                    </div>
                                </div>
                                <div class="testimonial-link-box">
                                    <div class="testimonial-author-box">
                                        <div class="text-size-18 text-weight-bold">—</div>
                                        <div class="text-color-gray-300">Noah Calloway, Belgium</div>
                                    </div><a href="https://uk.trustpilot.com/users/66bbc7bc6ad35b8243cb3e43"
                                        target="_blank" class="testimonial-link-source w-inline-block">
                                        <div class="text-size-18 text-weight-bold">Source</div>
                                        <div class="embed w-embed"><svg width="24" height="25" viewBox="0 0 24 25"
                                                fill="none" xmlns="http://www.w3.org/2000/svg">
                                                <path d="M7 17.0793L17 7.07935M17 7.07935H7M17 7.07935V17.0793"
                                                    stroke="currentColor" stroke-width="2" stroke-linecap="round"
                                                    stroke-linejoin="round" />
                                            </svg></div>
                                    </a>
                                </div>
                            </div>
                        </div>
                        <div class="w-dyn-list">
                            <div role="list" class="w-dyn-items">
                                <div role="listitem" class="w-dyn-item">
                                    <div class="platform-testimonial-slide">
                                        <div class="max-width-312 set-max-width-none">
                                            <div class="testimonial-client-score">
                                                <div class="set-text-align-left">
                                                    <div class="margin-bottom-8">
                                                        <div class="heading-64 text-weight-bold line-height-1">
                                                            5</div>
                                                    </div>
                                                    <div class="margin-bottom-16 set-margin-bottom-24">
                                                        <div class="text-size-14">Client’s score</div>
                                                    </div>
                                                    <div class="testimonial-rating-box">
                                                        <div class="embed w-embed"><svg width="25" height="25"
                                                                viewBox="0 0 25 25" fill="none"
                                                                xmlns="http://www.w3.org/2000/svg">
                                                                <rect width="24.1379" height="24.1379"
                                                                    transform="translate(0 0.484863)" fill="#219653" />
                                                                <path
                                                                    d="M12.0689 16.9904L15.7399 16.0074L17.2736 21.002L12.0689 16.9904ZM20.5172 10.5347H14.0552L12.0689 4.10547L10.0825 10.5347H3.62061L8.85049 14.5197L6.86414 20.9489L12.094 16.9638L15.3124 14.5197L20.5172 10.5347Z"
                                                                    fill="white" />
                                                            </svg></div>
                                                        <div class="embed w-embed"><svg width="25" height="25"
                                                                viewBox="0 0 25 25" fill="none"
                                                                xmlns="http://www.w3.org/2000/svg">
                                                                <rect width="24.1379" height="24.1379"
                                                                    transform="translate(0 0.484863)" fill="#219653" />
                                                                <path
                                                                    d="M12.0689 16.9904L15.7399 16.0074L17.2736 21.002L12.0689 16.9904ZM20.5172 10.5347H14.0552L12.0689 4.10547L10.0825 10.5347H3.62061L8.85049 14.5197L6.86414 20.9489L12.094 16.9638L15.3124 14.5197L20.5172 10.5347Z"
                                                                    fill="white" />
                                                            </svg></div>
                                                        <div class="embed w-embed"><svg width="25" height="25"
                                                                viewBox="0 0 25 25" fill="none"
                                                                xmlns="http://www.w3.org/2000/svg">
                                                                <rect width="24.1379" height="24.1379"
                                                                    transform="translate(0 0.484863)" fill="#219653" />
                                                                <path
                                                                    d="M12.0689 16.9904L15.7399 16.0074L17.2736 21.002L12.0689 16.9904ZM20.5172 10.5347H14.0552L12.0689 4.10547L10.0825 10.5347H3.62061L8.85049 14.5197L6.86414 20.9489L12.094 16.9638L15.3124 14.5197L20.5172 10.5347Z"
                                                                    fill="white" />
                                                            </svg></div>
                                                        <div class="embed w-embed"><svg width="25" height="25"
                                                                viewBox="0 0 25 25" fill="none"
                                                                xmlns="http://www.w3.org/2000/svg">
                                                                <rect width="24.1379" height="24.1379"
                                                                    transform="translate(0 0.484863)" fill="#219653" />
                                                                <path
                                                                    d="M12.0689 16.9904L15.7399 16.0074L17.2736 21.002L12.0689 16.9904ZM20.5172 10.5347H14.0552L12.0689 4.10547L10.0825 10.5347H3.62061L8.85049 14.5197L6.86414 20.9489L12.094 16.9638L15.3124 14.5197L20.5172 10.5347Z"
                                                                    fill="white" />
                                                            </svg></div>
                                                        <div class="embed w-embed"><svg width="25" height="25"
                                                                viewBox="0 0 25 25" fill="none"
                                                                xmlns="http://www.w3.org/2000/svg">
                                                                <rect width="24.1379" height="24.1379"
                                                                    transform="translate(0 0.484863)" fill="#219653" />
                                                                <path
                                                                    d="M12.0689 16.9904L15.7399 16.0074L17.2736 21.002L12.0689 16.9904ZM20.5172 10.5347H14.0552L12.0689 4.10547L10.0825 10.5347H3.62061L8.85049 14.5197L6.86414 20.9489L12.094 16.9638L15.3124 14.5197L20.5172 10.5347Z"
                                                                    fill="white" />
                                                            </svg></div>
                                                    </div>
                                                </div>
                                                <div class="testimonial-logo-bottom"><a
                                                        href="https://uk.trustpilot.com/reviews/66f790372d6aa9a6143f7a31"
                                                        target="_blank" class="testimonial-link-source w-inline-block">
                                                        <div class="text-size-18 text-weight-bold set-text-size-14">
                                                            Source</div>
                                                        <div class="fix-24">
                                                            <div data-button-icon="hover" class="embed w-embed"><svg
                                                                    width="24" height="24" viewBox="0 0 24 24"
                                                                    fill="none" xmlns="http://www.w3.org/2000/svg">
                                                                    <path d="M5 12H19M19 12L12 5M19 12L12 19"
                                                                        stroke="currentColor" stroke-width="2"
                                                                        stroke-linecap="round"
                                                                        stroke-linejoin="round" />
                                                                </svg></div>
                                                            <div data-button-icon="normal" class="embed w-embed"><svg
                                                                    width="24" height="24" viewBox="0 0 24 24"
                                                                    fill="none" xmlns="http://www.w3.org/2000/svg">
                                                                    <path d="M9 18L15 12L9 6" stroke="white"
                                                                        stroke-width="2" stroke-linecap="round"
                                                                        stroke-linejoin="round" />
                                                                </svg></div>
                                                        </div>
                                                    </a>
                                                    <div><img loading="lazy"
                                                            src="https://cdn.prod.website-files.com/668b3733f80ed0dcd2c46207/668f55e450eeb735f8c47eb3_Trustpilot%20logo.png"
                                                            alt="" /></div>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="inner-line width"></div>
                                        <div class="platform-testimonial-content">
                                            <div class="embed w-embed"><svg width="48" height="49" viewBox="0 0 48 49"
                                                    fill="none" xmlns="http://www.w3.org/2000/svg">
                                                    <path d="M0 6.05371V42.0537L18 24.0537V6.05371H0Z" fill="#D5283A" />
                                                    <path d="M30 6.05371V42.0537L48 24.0537V6.05371H30Z"
                                                        fill="#D5283A" />
                                                </svg></div>
                                            <div>
                                                <div class="margin-bottom-8">
                                                    <h3>Beyond outstanding service - thank you</h3>
                                                </div>
                                                <div class="max-width-852">
                                                    <div class="text-color-gray-300">I&#x27;I've been using AdsAsia for just over a month now, and they've been beyond outstanding. Within 30 minutes I had my
                                                        dashboard account ready and ad accounts requested.
                                                        Within 24 hours I received my Facebook agency
                                                        accounts and could start advertising. My account
                                                        manager, Dom, has always been very helpful and
                                                        supportive with all of my questions, and my results
                                                        on their ad accounts have been great. I usually do
                                                        not write any reviews, but I had to for AdsAsia.
                                                        Highly recommended!</div>
                                                </div>
                                            </div>
                                            <div class="testimonial-link-box">
                                                <div class="testimonial-author-box">
                                                    <div class="text-size-18 text-weight-bold">—</div>
                                                    <div class="testimonial-box-author">
                                                        <div class="text-color-gray-300">Christopher Jones
                                                        </div>
                                                        <div class="text-color-gray-300">, </div>
                                                        <div class="text-color-gray-300">US</div>
                                                    </div>
                                                </div>
                                                <div class="hide-mobile-landscape"><a
                                                        href="https://uk.trustpilot.com/reviews/66f790372d6aa9a6143f7a31"
                                                        target="_blank" class="testimonial-link-source w-inline-block">
                                                        <div class="text-size-18 text-weight-bold">Source
                                                        </div>
                                                        <div class="fix-24">
                                                            <div data-button-icon="hover" class="embed w-embed"><svg
                                                                    width="24" height="24" viewBox="0 0 24 24"
                                                                    fill="none" xmlns="http://www.w3.org/2000/svg">
                                                                    <path d="M5 12H19M19 12L12 5M19 12L12 19"
                                                                        stroke="currentColor" stroke-width="2"
                                                                        stroke-linecap="round"
                                                                        stroke-linejoin="round" />
                                                                </svg></div>
                                                            <div data-button-icon="normal" class="embed w-embed"><svg
                                                                    width="24" height="24" viewBox="0 0 24 24"
                                                                    fill="none" xmlns="http://www.w3.org/2000/svg">
                                                                    <path d="M9 18L15 12L9 6" stroke="white"
                                                                        stroke-width="2" stroke-linecap="round"
                                                                        stroke-linejoin="round" />
                                                                </svg></div>
                                                        </div>
                                                    </a></div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="w-slide">
                        <div class="platform-testimonial-slide hide-this">
                            <div class="max-width-312">
                                <div class="testimonial-client-score">
                                    <div>
                                        <div class="margin-bottom-8">
                                            <div class="heading-64 text-weight-bold line-height-1">5</div>
                                        </div>
                                        <div class="margin-bottom-16">
                                            <div class="text-size-14">Client’s score</div>
                                        </div>
                                        <div class="testimonial-rating-box">
                                            <div class="embed w-embed"><svg width="25" height="25" viewBox="0 0 25 25"
                                                    fill="none" xmlns="http://www.w3.org/2000/svg">
                                                    <rect width="24.1379" height="24.1379"
                                                        transform="translate(0 0.484863)" fill="#219653" />
                                                    <path
                                                        d="M12.0689 16.9904L15.7399 16.0074L17.2736 21.002L12.0689 16.9904ZM20.5172 10.5347H14.0552L12.0689 4.10547L10.0825 10.5347H3.62061L8.85049 14.5197L6.86414 20.9489L12.094 16.9638L15.3124 14.5197L20.5172 10.5347Z"
                                                        fill="white" />
                                                </svg></div>
                                            <div class="embed w-embed"><svg width="25" height="25" viewBox="0 0 25 25"
                                                    fill="none" xmlns="http://www.w3.org/2000/svg">
                                                    <rect width="24.1379" height="24.1379"
                                                        transform="translate(0 0.484863)" fill="#219653" />
                                                    <path
                                                        d="M12.0689 16.9904L15.7399 16.0074L17.2736 21.002L12.0689 16.9904ZM20.5172 10.5347H14.0552L12.0689 4.10547L10.0825 10.5347H3.62061L8.85049 14.5197L6.86414 20.9489L12.094 16.9638L15.3124 14.5197L20.5172 10.5347Z"
                                                        fill="white" />
                                                </svg></div>
                                            <div class="embed w-embed"><svg width="25" height="25" viewBox="0 0 25 25"
                                                    fill="none" xmlns="http://www.w3.org/2000/svg">
                                                    <rect width="24.1379" height="24.1379"
                                                        transform="translate(0 0.484863)" fill="#219653" />
                                                    <path
                                                        d="M12.0689 16.9904L15.7399 16.0074L17.2736 21.002L12.0689 16.9904ZM20.5172 10.5347H14.0552L12.0689 4.10547L10.0825 10.5347H3.62061L8.85049 14.5197L6.86414 20.9489L12.094 16.9638L15.3124 14.5197L20.5172 10.5347Z"
                                                        fill="white" />
                                                </svg></div>
                                            <div class="embed w-embed"><svg width="25" height="25" viewBox="0 0 25 25"
                                                    fill="none" xmlns="http://www.w3.org/2000/svg">
                                                    <rect width="24.1379" height="24.1379"
                                                        transform="translate(0 0.484863)" fill="#219653" />
                                                    <path
                                                        d="M12.0689 16.9904L15.7399 16.0074L17.2736 21.002L12.0689 16.9904ZM20.5172 10.5347H14.0552L12.0689 4.10547L10.0825 10.5347H3.62061L8.85049 14.5197L6.86414 20.9489L12.094 16.9638L15.3124 14.5197L20.5172 10.5347Z"
                                                        fill="white" />
                                                </svg></div>
                                            <div class="embed w-embed"><svg width="25" height="25" viewBox="0 0 25 25"
                                                    fill="none" xmlns="http://www.w3.org/2000/svg">
                                                    <rect width="24.1379" height="24.1379"
                                                        transform="translate(0 0.484863)" fill="#219653" />
                                                    <path
                                                        d="M12.0689 16.9904L15.7399 16.0074L17.2736 21.002L12.0689 16.9904ZM20.5172 10.5347H14.0552L12.0689 4.10547L10.0825 10.5347H3.62061L8.85049 14.5197L6.86414 20.9489L12.094 16.9638L15.3124 14.5197L20.5172 10.5347Z"
                                                        fill="white" />
                                                </svg></div>
                                        </div>
                                    </div>
                                    <div class="testimonial-logo-bottom">
                                        <div><img loading="lazy"
                                                src="https://cdn.prod.website-files.com/668b3733f80ed0dcd2c46207/668f55e450eeb735f8c47eb3_Trustpilot%20logo.png"
                                                alt="" /></div>
                                    </div>
                                </div>
                            </div>
                            <div class="inner-line width"></div>
                            <div class="platform-testimonial-content">
                                <div class="embed w-embed"><svg width="48" height="49" viewBox="0 0 48 49" fill="none"
                                        xmlns="http://www.w3.org/2000/svg">
                                        <path d="M0 6.05371V42.0537L18 24.0537V6.05371H0Z" fill="#D5283A" />
                                        <path d="M30 6.05371V42.0537L48 24.0537V6.05371H30Z" fill="#D5283A" />
                                    </svg></div>
                                <div>
                                    <div class="margin-bottom-8">
                                        <h3>Excellent results with AdsAsia ads</h3>
                                    </div>
                                    <div class="max-width-852">
                                        <div class="text-color-gray-300">Finally found an agency that allows
                                            me to run campaigns without problems.</div>
                                    </div>
                                </div>
                                <div class="testimonial-link-box">
                                    <div class="testimonial-author-box">
                                        <div class="text-size-18 text-weight-bold">—</div>
                                        <div class="text-color-gray-300">Alexander Penrose, Norway</div>
                                    </div><a href="https://uk.trustpilot.com/users/66c44ba1d02d0533104989e2"
                                        target="_blank" class="testimonial-link-source w-inline-block">
                                        <div class="text-size-18 text-weight-bold">Source</div>
                                        <div class="embed w-embed"><svg width="24" height="25" viewBox="0 0 24 25"
                                                fill="none" xmlns="http://www.w3.org/2000/svg">
                                                <path d="M7 17.0793L17 7.07935M17 7.07935H7M17 7.07935V17.0793"
                                                    stroke="currentColor" stroke-width="2" stroke-linecap="round"
                                                    stroke-linejoin="round" />
                                            </svg></div>
                                    </a>
                                </div>
                            </div>
                        </div>
                        <div class="w-dyn-list">
                            <div role="list" class="w-dyn-items">
                                <div role="listitem" class="w-dyn-item">
                                    <div class="platform-testimonial-slide">
                                        <div class="max-width-312 set-max-width-none">
                                            <div class="testimonial-client-score">
                                                <div class="set-text-align-left">
                                                    <div class="margin-bottom-8">
                                                        <div class="heading-64 text-weight-bold line-height-1">
                                                            5</div>
                                                    </div>
                                                    <div class="margin-bottom-16 set-margin-bottom-24">
                                                        <div class="text-size-14">Client’s score</div>
                                                    </div>
                                                    <div class="testimonial-rating-box">
                                                        <div class="embed w-embed"><svg width="25" height="25"
                                                                viewBox="0 0 25 25" fill="none"
                                                                xmlns="http://www.w3.org/2000/svg">
                                                                <rect width="24.1379" height="24.1379"
                                                                    transform="translate(0 0.484863)" fill="#219653" />
                                                                <path
                                                                    d="M12.0689 16.9904L15.7399 16.0074L17.2736 21.002L12.0689 16.9904ZM20.5172 10.5347H14.0552L12.0689 4.10547L10.0825 10.5347H3.62061L8.85049 14.5197L6.86414 20.9489L12.094 16.9638L15.3124 14.5197L20.5172 10.5347Z"
                                                                    fill="white" />
                                                            </svg></div>
                                                        <div class="embed w-embed"><svg width="25" height="25"
                                                                viewBox="0 0 25 25" fill="none"
                                                                xmlns="http://www.w3.org/2000/svg">
                                                                <rect width="24.1379" height="24.1379"
                                                                    transform="translate(0 0.484863)" fill="#219653" />
                                                                <path
                                                                    d="M12.0689 16.9904L15.7399 16.0074L17.2736 21.002L12.0689 16.9904ZM20.5172 10.5347H14.0552L12.0689 4.10547L10.0825 10.5347H3.62061L8.85049 14.5197L6.86414 20.9489L12.094 16.9638L15.3124 14.5197L20.5172 10.5347Z"
                                                                    fill="white" />
                                                            </svg></div>
                                                        <div class="embed w-embed"><svg width="25" height="25"
                                                                viewBox="0 0 25 25" fill="none"
                                                                xmlns="http://www.w3.org/2000/svg">
                                                                <rect width="24.1379" height="24.1379"
                                                                    transform="translate(0 0.484863)" fill="#219653" />
                                                                <path
                                                                    d="M12.0689 16.9904L15.7399 16.0074L17.2736 21.002L12.0689 16.9904ZM20.5172 10.5347H14.0552L12.0689 4.10547L10.0825 10.5347H3.62061L8.85049 14.5197L6.86414 20.9489L12.094 16.9638L15.3124 14.5197L20.5172 10.5347Z"
                                                                    fill="white" />
                                                            </svg></div>
                                                        <div class="embed w-embed"><svg width="25" height="25"
                                                                viewBox="0 0 25 25" fill="none"
                                                                xmlns="http://www.w3.org/2000/svg">
                                                                <rect width="24.1379" height="24.1379"
                                                                    transform="translate(0 0.484863)" fill="#219653" />
                                                                <path
                                                                    d="M12.0689 16.9904L15.7399 16.0074L17.2736 21.002L12.0689 16.9904ZM20.5172 10.5347H14.0552L12.0689 4.10547L10.0825 10.5347H3.62061L8.85049 14.5197L6.86414 20.9489L12.094 16.9638L15.3124 14.5197L20.5172 10.5347Z"
                                                                    fill="white" />
                                                            </svg></div>
                                                        <div class="embed w-embed"><svg width="25" height="25"
                                                                viewBox="0 0 25 25" fill="none"
                                                                xmlns="http://www.w3.org/2000/svg">
                                                                <rect width="24.1379" height="24.1379"
                                                                    transform="translate(0 0.484863)" fill="#219653" />
                                                                <path
                                                                    d="M12.0689 16.9904L15.7399 16.0074L17.2736 21.002L12.0689 16.9904ZM20.5172 10.5347H14.0552L12.0689 4.10547L10.0825 10.5347H3.62061L8.85049 14.5197L6.86414 20.9489L12.094 16.9638L15.3124 14.5197L20.5172 10.5347Z"
                                                                    fill="white" />
                                                            </svg></div>
                                                    </div>
                                                </div>
                                                <div class="testimonial-logo-bottom"><a
                                                        href="https://uk.trustpilot.com/reviews/66f6bae97b5a12773ae5d668"
                                                        target="_blank" class="testimonial-link-source w-inline-block">
                                                        <div class="text-size-18 text-weight-bold set-text-size-14">
                                                            Source</div>
                                                        <div class="fix-24">
                                                            <div data-button-icon="hover" class="embed w-embed"><svg
                                                                    width="24" height="24" viewBox="0 0 24 24"
                                                                    fill="none" xmlns="http://www.w3.org/2000/svg">
                                                                    <path d="M5 12H19M19 12L12 5M19 12L12 19"
                                                                        stroke="currentColor" stroke-width="2"
                                                                        stroke-linecap="round"
                                                                        stroke-linejoin="round" />
                                                                </svg></div>
                                                            <div data-button-icon="normal" class="embed w-embed"><svg
                                                                    width="24" height="24" viewBox="0 0 24 24"
                                                                    fill="none" xmlns="http://www.w3.org/2000/svg">
                                                                    <path d="M9 18L15 12L9 6" stroke="white"
                                                                        stroke-width="2" stroke-linecap="round"
                                                                        stroke-linejoin="round" />
                                                                </svg></div>
                                                        </div>
                                                    </a>
                                                    <div><img loading="lazy"
                                                            src="https://cdn.prod.website-files.com/668b3733f80ed0dcd2c46207/668f55e450eeb735f8c47eb3_Trustpilot%20logo.png"
                                                            alt="" /></div>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="inner-line width"></div>
                                        <div class="platform-testimonial-content">
                                            <div class="embed w-embed"><svg width="48" height="49" viewBox="0 0 48 49"
                                                    fill="none" xmlns="http://www.w3.org/2000/svg">
                                                    <path d="M0 6.05371V42.0537L18 24.0537V6.05371H0Z" fill="#D5283A" />
                                                    <path d="M30 6.05371V42.0537L48 24.0537V6.05371H30Z"
                                                        fill="#D5283A" />
                                                </svg></div>
                                            <div>
                                                <div class="margin-bottom-8">
                                                    <h3>One year experience with AdsAsia</h3>
                                                </div>
                                                <div class="max-width-852">
                                                    <div class="text-color-gray-300">Hello, I am from Russia. I have worked with AdsAsia for almost one year. I am very happy with the service from this agency and the account managers always respond very quickly and most actions I can manage myself from the dashboard. Also they do not charge me any commission on ad spending so I am more happy.</div>
                                                </div>
                                            </div>
                                            <div class="testimonial-link-box">
                                                <div class="testimonial-author-box">
                                                    <div class="text-size-18 text-weight-bold">—</div>
                                                    <div class="testimonial-box-author">
                                                        <div class="text-color-gray-300">Aleksey F</div>
                                                        <div class="text-color-gray-300">, </div>
                                                        <div class="text-color-gray-300">RU</div>
                                                    </div>
                                                </div>
                                                <div class="hide-mobile-landscape"><a
                                                        href="https://uk.trustpilot.com/reviews/66f6bae97b5a12773ae5d668"
                                                        target="_blank" class="testimonial-link-source w-inline-block">
                                                        <div class="text-size-18 text-weight-bold">Source
                                                        </div>
                                                        <div class="fix-24">
                                                            <div data-button-icon="hover" class="embed w-embed"><svg
                                                                    width="24" height="24" viewBox="0 0 24 24"
                                                                    fill="none" xmlns="http://www.w3.org/2000/svg">
                                                                    <path d="M5 12H19M19 12L12 5M19 12L12 19"
                                                                        stroke="currentColor" stroke-width="2"
                                                                        stroke-linecap="round"
                                                                        stroke-linejoin="round" />
                                                                </svg></div>
                                                            <div data-button-icon="normal" class="embed w-embed"><svg
                                                                    width="24" height="24" viewBox="0 0 24 24"
                                                                    fill="none" xmlns="http://www.w3.org/2000/svg">
                                                                    <path d="M9 18L15 12L9 6" stroke="white"
                                                                        stroke-width="2" stroke-linecap="round"
                                                                        stroke-linejoin="round" />
                                                                </svg></div>
                                                        </div>
                                                    </a></div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="w-slide">
                        <div class="platform-testimonial-slide hide-this">
                            <div class="max-width-312">
                                <div class="testimonial-client-score">
                                    <div>
                                        <div class="margin-bottom-8">
                                            <div class="heading-64 text-weight-bold line-height-1">5</div>
                                        </div>
                                        <div class="margin-bottom-16">
                                            <div class="text-size-14">Client’s score</div>
                                        </div>
                                        <div class="testimonial-rating-box">
                                            <div class="embed w-embed"><svg width="25" height="25" viewBox="0 0 25 25"
                                                    fill="none" xmlns="http://www.w3.org/2000/svg">
                                                    <rect width="24.1379" height="24.1379"
                                                        transform="translate(0 0.484863)" fill="#219653" />
                                                    <path
                                                        d="M12.0689 16.9904L15.7399 16.0074L17.2736 21.002L12.0689 16.9904ZM20.5172 10.5347H14.0552L12.0689 4.10547L10.0825 10.5347H3.62061L8.85049 14.5197L6.86414 20.9489L12.094 16.9638L15.3124 14.5197L20.5172 10.5347Z"
                                                        fill="white" />
                                                </svg></div>
                                            <div class="embed w-embed"><svg width="25" height="25" viewBox="0 0 25 25"
                                                    fill="none" xmlns="http://www.w3.org/2000/svg">
                                                    <rect width="24.1379" height="24.1379"
                                                        transform="translate(0 0.484863)" fill="#219653" />
                                                    <path
                                                        d="M12.0689 16.9904L15.7399 16.0074L17.2736 21.002L12.0689 16.9904ZM20.5172 10.5347H14.0552L12.0689 4.10547L10.0825 10.5347H3.62061L8.85049 14.5197L6.86414 20.9489L12.094 16.9638L15.3124 14.5197L20.5172 10.5347Z"
                                                        fill="white" />
                                                </svg></div>
                                            <div class="embed w-embed"><svg width="25" height="25" viewBox="0 0 25 25"
                                                    fill="none" xmlns="http://www.w3.org/2000/svg">
                                                    <rect width="24.1379" height="24.1379"
                                                        transform="translate(0 0.484863)" fill="#219653" />
                                                    <path
                                                        d="M12.0689 16.9904L15.7399 16.0074L17.2736 21.002L12.0689 16.9904ZM20.5172 10.5347H14.0552L12.0689 4.10547L10.0825 10.5347H3.62061L8.85049 14.5197L6.86414 20.9489L12.094 16.9638L15.3124 14.5197L20.5172 10.5347Z"
                                                        fill="white" />
                                                </svg></div>
                                            <div class="embed w-embed"><svg width="25" height="25" viewBox="0 0 25 25"
                                                    fill="none" xmlns="http://www.w3.org/2000/svg">
                                                    <rect width="24.1379" height="24.1379"
                                                        transform="translate(0 0.484863)" fill="#219653" />
                                                    <path
                                                        d="M12.0689 16.9904L15.7399 16.0074L17.2736 21.002L12.0689 16.9904ZM20.5172 10.5347H14.0552L12.0689 4.10547L10.0825 10.5347H3.62061L8.85049 14.5197L6.86414 20.9489L12.094 16.9638L15.3124 14.5197L20.5172 10.5347Z"
                                                        fill="white" />
                                                </svg></div>
                                            <div class="embed w-embed"><svg width="25" height="25" viewBox="0 0 25 25"
                                                    fill="none" xmlns="http://www.w3.org/2000/svg">
                                                    <rect width="24.1379" height="24.1379"
                                                        transform="translate(0 0.484863)" fill="#219653" />
                                                    <path
                                                        d="M12.0689 16.9904L15.7399 16.0074L17.2736 21.002L12.0689 16.9904ZM20.5172 10.5347H14.0552L12.0689 4.10547L10.0825 10.5347H3.62061L8.85049 14.5197L6.86414 20.9489L12.094 16.9638L15.3124 14.5197L20.5172 10.5347Z"
                                                        fill="white" />
                                                </svg></div>
                                        </div>
                                    </div>
                                    <div class="testimonial-logo-bottom">
                                        <div><img loading="lazy"
                                                src="https://cdn.prod.website-files.com/668b3733f80ed0dcd2c46207/668f55e450eeb735f8c47eb3_Trustpilot%20logo.png"
                                                alt="" /></div>
                                    </div>
                                </div>
                            </div>
                            <div class="inner-line width"></div>
                            <div class="platform-testimonial-content">
                                <div class="embed w-embed"><svg width="48" height="49" viewBox="0 0 48 49" fill="none"
                                        xmlns="http://www.w3.org/2000/svg">
                                        <path d="M0 6.05371V42.0537L18 24.0537V6.05371H0Z" fill="#D5283A" />
                                        <path d="M30 6.05371V42.0537L48 24.0537V6.05371H30Z" fill="#D5283A" />
                                    </svg></div>
                                <div>
                                    <div class="margin-bottom-8">
                                        <h3>Great Job AdsAsia!</h3>
                                    </div>
                                    <div class="max-width-852">
                                        <div class="text-color-gray-300">AdsAsia Agency has done an excellent
                                            job! They recently reduced their crypto fee from 2% to 1.5%,
                                            which has been incredibly beneficial for our small business.
                                            This reduction helps us save on costs and manage our finances
                                            more effectively. Thank you, AdsAsia, for supporting small
                                            businesses like ours!</div>
                                    </div>
                                </div>
                                <div class="testimonial-link-box">
                                    <div class="testimonial-author-box">
                                        <div class="text-size-18 text-weight-bold">—</div>
                                        <div class="text-color-gray-300">Annabelle Woolf, Canada</div>
                                    </div><a href="https://uk.trustpilot.com/users/6653bdd4d11b292c6d2f3c96"
                                        target="_blank" class="testimonial-link-source w-inline-block">
                                        <div class="text-size-18 text-weight-bold">Source</div>
                                        <div class="embed w-embed"><svg width="24" height="25" viewBox="0 0 24 25"
                                                fill="none" xmlns="http://www.w3.org/2000/svg">
                                                <path d="M7 17.0793L17 7.07935M17 7.07935H7M17 7.07935V17.0793"
                                                    stroke="currentColor" stroke-width="2" stroke-linecap="round"
                                                    stroke-linejoin="round" />
                                            </svg></div>
                                    </a>
                                </div>
                            </div>
                        </div>
                        <div class="w-dyn-list">
                            <div role="list" class="w-dyn-items">
                                <div role="listitem" class="w-dyn-item">
                                    <div class="platform-testimonial-slide">
                                        <div class="max-width-312 set-max-width-none">
                                            <div class="testimonial-client-score">
                                                <div class="set-text-align-left">
                                                    <div class="margin-bottom-8">
                                                        <div class="heading-64 text-weight-bold line-height-1">
                                                            5</div>
                                                    </div>
                                                    <div class="margin-bottom-16 set-margin-bottom-24">
                                                        <div class="text-size-14">Client’s score</div>
                                                    </div>
                                                    <div class="testimonial-rating-box">
                                                        <div class="embed w-embed"><svg width="25" height="25"
                                                                viewBox="0 0 25 25" fill="none"
                                                                xmlns="http://www.w3.org/2000/svg">
                                                                <rect width="24.1379" height="24.1379"
                                                                    transform="translate(0 0.484863)" fill="#219653" />
                                                                <path
                                                                    d="M12.0689 16.9904L15.7399 16.0074L17.2736 21.002L12.0689 16.9904ZM20.5172 10.5347H14.0552L12.0689 4.10547L10.0825 10.5347H3.62061L8.85049 14.5197L6.86414 20.9489L12.094 16.9638L15.3124 14.5197L20.5172 10.5347Z"
                                                                    fill="white" />
                                                            </svg></div>
                                                        <div class="embed w-embed"><svg width="25" height="25"
                                                                viewBox="0 0 25 25" fill="none"
                                                                xmlns="http://www.w3.org/2000/svg">
                                                                <rect width="24.1379" height="24.1379"
                                                                    transform="translate(0 0.484863)" fill="#219653" />
                                                                <path
                                                                    d="M12.0689 16.9904L15.7399 16.0074L17.2736 21.002L12.0689 16.9904ZM20.5172 10.5347H14.0552L12.0689 4.10547L10.0825 10.5347H3.62061L8.85049 14.5197L6.86414 20.9489L12.094 16.9638L15.3124 14.5197L20.5172 10.5347Z"
                                                                    fill="white" />
                                                            </svg></div>
                                                        <div class="embed w-embed"><svg width="25" height="25"
                                                                viewBox="0 0 25 25" fill="none"
                                                                xmlns="http://www.w3.org/2000/svg">
                                                                <rect width="24.1379" height="24.1379"
                                                                    transform="translate(0 0.484863)" fill="#219653" />
                                                                <path
                                                                    d="M12.0689 16.9904L15.7399 16.0074L17.2736 21.002L12.0689 16.9904ZM20.5172 10.5347H14.0552L12.0689 4.10547L10.0825 10.5347H3.62061L8.85049 14.5197L6.86414 20.9489L12.094 16.9638L15.3124 14.5197L20.5172 10.5347Z"
                                                                    fill="white" />
                                                            </svg></div>
                                                        <div class="embed w-embed"><svg width="25" height="25"
                                                                viewBox="0 0 25 25" fill="none"
                                                                xmlns="http://www.w3.org/2000/svg">
                                                                <rect width="24.1379" height="24.1379"
                                                                    transform="translate(0 0.484863)" fill="#219653" />
                                                                <path
                                                                    d="M12.0689 16.9904L15.7399 16.0074L17.2736 21.002L12.0689 16.9904ZM20.5172 10.5347H14.0552L12.0689 4.10547L10.0825 10.5347H3.62061L8.85049 14.5197L6.86414 20.9489L12.094 16.9638L15.3124 14.5197L20.5172 10.5347Z"
                                                                    fill="white" />
                                                            </svg></div>
                                                        <div class="embed w-embed"><svg width="25" height="25"
                                                                viewBox="0 0 25 25" fill="none"
                                                                xmlns="http://www.w3.org/2000/svg">
                                                                <rect width="24.1379" height="24.1379"
                                                                    transform="translate(0 0.484863)" fill="#219653" />
                                                                <path
                                                                    d="M12.0689 16.9904L15.7399 16.0074L17.2736 21.002L12.0689 16.9904ZM20.5172 10.5347H14.0552L12.0689 4.10547L10.0825 10.5347H3.62061L8.85049 14.5197L6.86414 20.9489L12.094 16.9638L15.3124 14.5197L20.5172 10.5347Z"
                                                                    fill="white" />
                                                            </svg></div>
                                                    </div>
                                                </div>
                                                <div class="testimonial-logo-bottom"><a
                                                        href="https://www.trustpilot.com/reviews/66f66d3a17eb00679859cc64"
                                                        target="_blank" class="testimonial-link-source w-inline-block">
                                                        <div class="text-size-18 text-weight-bold set-text-size-14">
                                                            Source</div>
                                                        <div class="fix-24">
                                                            <div data-button-icon="hover" class="embed w-embed"><svg
                                                                    width="24" height="24" viewBox="0 0 24 24"
                                                                    fill="none" xmlns="http://www.w3.org/2000/svg">
                                                                    <path d="M5 12H19M19 12L12 5M19 12L12 19"
                                                                        stroke="currentColor" stroke-width="2"
                                                                        stroke-linecap="round"
                                                                        stroke-linejoin="round" />
                                                                </svg></div>
                                                            <div data-button-icon="normal" class="embed w-embed"><svg
                                                                    width="24" height="24" viewBox="0 0 24 24"
                                                                    fill="none" xmlns="http://www.w3.org/2000/svg">
                                                                    <path d="M9 18L15 12L9 6" stroke="white"
                                                                        stroke-width="2" stroke-linecap="round"
                                                                        stroke-linejoin="round" />
                                                                </svg></div>
                                                        </div>
                                                    </a>
                                                    <div><img loading="lazy"
                                                            src="https://cdn.prod.website-files.com/668b3733f80ed0dcd2c46207/668f55e450eeb735f8c47eb3_Trustpilot%20logo.png"
                                                            alt="" /></div>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="inner-line width"></div>
                                        <div class="platform-testimonial-content">
                                            <div class="embed w-embed"><svg width="48" height="49" viewBox="0 0 48 49"
                                                    fill="none" xmlns="http://www.w3.org/2000/svg">
                                                    <path d="M0 6.05371V42.0537L18 24.0537V6.05371H0Z" fill="#D5283A" />
                                                    <path d="M30 6.05371V42.0537L48 24.0537V6.05371H30Z"
                                                        fill="#D5283A" />
                                                </svg></div>
                                            <div>
                                                <div class="margin-bottom-8">
                                                    <h3>High quality service and ad accounts</h3>
                                                </div>
                                                <div class="max-width-852">
                                                    <div class="text-color-gray-300">Grace is super helpful. She helped me with all requests very quick and I really recommend anyone to choose AdsAsia over any other agency. The process is simple and the service, top-ups and responses are very quick. And most importantly the ad account quality is great.</div>
                                                </div>
                                            </div>
                                            <div class="testimonial-link-box">
                                                <div class="testimonial-author-box">
                                                    <div class="text-size-18 text-weight-bold">—</div>
                                                    <div class="testimonial-box-author">
                                                        <div class="text-color-gray-300">Mohamed Z</div>
                                                        <div class="text-color-gray-300">, </div>
                                                        <div class="text-color-gray-300">DZ</div>
                                                    </div>
                                                </div>
                                                <div class="hide-mobile-landscape"><a
                                                        href="https://www.trustpilot.com/reviews/66f66d3a17eb00679859cc64"
                                                        target="_blank" class="testimonial-link-source w-inline-block">
                                                        <div class="text-size-18 text-weight-bold">Source
                                                        </div>
                                                        <div class="fix-24">
                                                            <div data-button-icon="hover" class="embed w-embed"><svg
                                                                    width="24" height="24" viewBox="0 0 24 24"
                                                                    fill="none" xmlns="http://www.w3.org/2000/svg">
                                                                    <path d="M5 12H19M19 12L12 5M19 12L12 19"
                                                                        stroke="currentColor" stroke-width="2"
                                                                        stroke-linecap="round"
                                                                        stroke-linejoin="round" />
                                                                </svg></div>
                                                            <div data-button-icon="normal" class="embed w-embed"><svg
                                                                    width="24" height="24" viewBox="0 0 24 24"
                                                                    fill="none" xmlns="http://www.w3.org/2000/svg">
                                                                    <path d="M9 18L15 12L9 6" stroke="white"
                                                                        stroke-width="2" stroke-linecap="round"
                                                                        stroke-linejoin="round" />
                                                                </svg></div>
                                                        </div>
                                                    </a></div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="w-slide">
                        <div class="platform-testimonial-slide hide-this">
                            <div class="max-width-312">
                                <div class="testimonial-client-score">
                                    <div>
                                        <div class="margin-bottom-8">
                                            <div class="heading-64 text-weight-bold line-height-1">5</div>
                                        </div>
                                        <div class="margin-bottom-16">
                                            <div class="text-size-14">Client’s score</div>
                                        </div>
                                        <div class="testimonial-rating-box">
                                            <div class="embed w-embed"><svg width="25" height="25" viewBox="0 0 25 25"
                                                    fill="none" xmlns="http://www.w3.org/2000/svg">
                                                    <rect width="24.1379" height="24.1379"
                                                        transform="translate(0 0.484863)" fill="#219653" />
                                                    <path
                                                        d="M12.0689 16.9904L15.7399 16.0074L17.2736 21.002L12.0689 16.9904ZM20.5172 10.5347H14.0552L12.0689 4.10547L10.0825 10.5347H3.62061L8.85049 14.5197L6.86414 20.9489L12.094 16.9638L15.3124 14.5197L20.5172 10.5347Z"
                                                        fill="white" />
                                                </svg></div>
                                            <div class="embed w-embed"><svg width="25" height="25" viewBox="0 0 25 25"
                                                    fill="none" xmlns="http://www.w3.org/2000/svg">
                                                    <rect width="24.1379" height="24.1379"
                                                        transform="translate(0 0.484863)" fill="#219653" />
                                                    <path
                                                        d="M12.0689 16.9904L15.7399 16.0074L17.2736 21.002L12.0689 16.9904ZM20.5172 10.5347H14.0552L12.0689 4.10547L10.0825 10.5347H3.62061L8.85049 14.5197L6.86414 20.9489L12.094 16.9638L15.3124 14.5197L20.5172 10.5347Z"
                                                        fill="white" />
                                                </svg></div>
                                            <div class="embed w-embed"><svg width="25" height="25" viewBox="0 0 25 25"
                                                    fill="none" xmlns="http://www.w3.org/2000/svg">
                                                    <rect width="24.1379" height="24.1379"
                                                        transform="translate(0 0.484863)" fill="#219653" />
                                                    <path
                                                        d="M12.0689 16.9904L15.7399 16.0074L17.2736 21.002L12.0689 16.9904ZM20.5172 10.5347H14.0552L12.0689 4.10547L10.0825 10.5347H3.62061L8.85049 14.5197L6.86414 20.9489L12.094 16.9638L15.3124 14.5197L20.5172 10.5347Z"
                                                        fill="white" />
                                                </svg></div>
                                            <div class="embed w-embed"><svg width="25" height="25" viewBox="0 0 25 25"
                                                    fill="none" xmlns="http://www.w3.org/2000/svg">
                                                    <rect width="24.1379" height="24.1379"
                                                        transform="translate(0 0.484863)" fill="#219653" />
                                                    <path
                                                        d="M12.0689 16.9904L15.7399 16.0074L17.2736 21.002L12.0689 16.9904ZM20.5172 10.5347H14.0552L12.0689 4.10547L10.0825 10.5347H3.62061L8.85049 14.5197L6.86414 20.9489L12.094 16.9638L15.3124 14.5197L20.5172 10.5347Z"
                                                        fill="white" />
                                                </svg></div>
                                            <div class="embed w-embed"><svg width="25" height="25" viewBox="0 0 25 25"
                                                    fill="none" xmlns="http://www.w3.org/2000/svg">
                                                    <rect width="24.1379" height="24.1379"
                                                        transform="translate(0 0.484863)" fill="#219653" />
                                                    <path
                                                        d="M12.0689 16.9904L15.7399 16.0074L17.2736 21.002L12.0689 16.9904ZM20.5172 10.5347H14.0552L12.0689 4.10547L10.0825 10.5347H3.62061L8.85049 14.5197L6.86414 20.9489L12.094 16.9638L15.3124 14.5197L20.5172 10.5347Z"
                                                        fill="white" />
                                                </svg></div>
                                        </div>
                                    </div>
                                    <div class="testimonial-logo-bottom">
                                        <div><img loading="lazy"
                                                src="https://cdn.prod.website-files.com/668b3733f80ed0dcd2c46207/668f55e450eeb735f8c47eb3_Trustpilot%20logo.png"
                                                alt="" /></div>
                                    </div>
                                </div>
                            </div>
                            <div class="inner-line width"></div>
                            <div class="platform-testimonial-content">
                                <div class="embed w-embed"><svg width="48" height="49" viewBox="0 0 48 49" fill="none"
                                        xmlns="http://www.w3.org/2000/svg">
                                        <path d="M0 6.05371V42.0537L18 24.0537V6.05371H0Z" fill="#D5283A" />
                                        <path d="M30 6.05371V42.0537L48 24.0537V6.05371H30Z" fill="#D5283A" />
                                    </svg></div>
                                <div>
                                    <div class="margin-bottom-8">
                                        <h3>Fast, helpful AdsAsia team</h3>
                                    </div>
                                    <div class="max-width-852">
                                        <div class="text-color-gray-300">As a small business owner, I was always restricted when running ads for my own product line. AdsAsia provided a smooth solution and now I can finally advertise!</div>
                                    </div>
                                </div>
                                <div class="testimonial-link-box">
                                    <div class="testimonial-author-box">
                                        <div class="text-size-18 text-weight-bold">—</div>
                                        <div class="text-color-gray-300">Benjamin Harcourt, France</div>
                                    </div><a href="#" target="_blank" class="testimonial-link-source w-inline-block">
                                        <div class="text-size-18 text-weight-bold">Source</div>
                                        <div class="embed w-embed"><svg width="24" height="25" viewBox="0 0 24 25"
                                                fill="none" xmlns="http://www.w3.org/2000/svg">
                                                <path d="M7 17.0793L17 7.07935M17 7.07935H7M17 7.07935V17.0793"
                                                    stroke="currentColor" stroke-width="2" stroke-linecap="round"
                                                    stroke-linejoin="round" />
                                            </svg></div>
                                    </a>
                                </div>
                            </div>
                        </div>
                        <div class="w-dyn-list">
                            <div role="list" class="w-dyn-items">
                                <div role="listitem" class="w-dyn-item">
                                    <div class="platform-testimonial-slide">
                                        <div class="max-width-312 set-max-width-none">
                                            <div class="testimonial-client-score">
                                                <div class="set-text-align-left">
                                                    <div class="margin-bottom-8">
                                                        <div class="heading-64 text-weight-bold line-height-1">
                                                            5</div>
                                                    </div>
                                                    <div class="margin-bottom-16 set-margin-bottom-24">
                                                        <div class="text-size-14">Client’s score</div>
                                                    </div>
                                                    <div class="testimonial-rating-box">
                                                        <div class="embed w-embed"><svg width="25" height="25"
                                                                viewBox="0 0 25 25" fill="none"
                                                                xmlns="http://www.w3.org/2000/svg">
                                                                <rect width="24.1379" height="24.1379"
                                                                    transform="translate(0 0.484863)" fill="#219653" />
                                                                <path
                                                                    d="M12.0689 16.9904L15.7399 16.0074L17.2736 21.002L12.0689 16.9904ZM20.5172 10.5347H14.0552L12.0689 4.10547L10.0825 10.5347H3.62061L8.85049 14.5197L6.86414 20.9489L12.094 16.9638L15.3124 14.5197L20.5172 10.5347Z"
                                                                    fill="white" />
                                                            </svg></div>
                                                        <div class="embed w-embed"><svg width="25" height="25"
                                                                viewBox="0 0 25 25" fill="none"
                                                                xmlns="http://www.w3.org/2000/svg">
                                                                <rect width="24.1379" height="24.1379"
                                                                    transform="translate(0 0.484863)" fill="#219653" />
                                                                <path
                                                                    d="M12.0689 16.9904L15.7399 16.0074L17.2736 21.002L12.0689 16.9904ZM20.5172 10.5347H14.0552L12.0689 4.10547L10.0825 10.5347H3.62061L8.85049 14.5197L6.86414 20.9489L12.094 16.9638L15.3124 14.5197L20.5172 10.5347Z"
                                                                    fill="white" />
                                                            </svg></div>
                                                        <div class="embed w-embed"><svg width="25" height="25"
                                                                viewBox="0 0 25 25" fill="none"
                                                                xmlns="http://www.w3.org/2000/svg">
                                                                <rect width="24.1379" height="24.1379"
                                                                    transform="translate(0 0.484863)" fill="#219653" />
                                                                <path
                                                                    d="M12.0689 16.9904L15.7399 16.0074L17.2736 21.002L12.0689 16.9904ZM20.5172 10.5347H14.0552L12.0689 4.10547L10.0825 10.5347H3.62061L8.85049 14.5197L6.86414 20.9489L12.094 16.9638L15.3124 14.5197L20.5172 10.5347Z"
                                                                    fill="white" />
                                                            </svg></div>
                                                        <div class="embed w-embed"><svg width="25" height="25"
                                                                viewBox="0 0 25 25" fill="none"
                                                                xmlns="http://www.w3.org/2000/svg">
                                                                <rect width="24.1379" height="24.1379"
                                                                    transform="translate(0 0.484863)" fill="#219653" />
                                                                <path
                                                                    d="M12.0689 16.9904L15.7399 16.0074L17.2736 21.002L12.0689 16.9904ZM20.5172 10.5347H14.0552L12.0689 4.10547L10.0825 10.5347H3.62061L8.85049 14.5197L6.86414 20.9489L12.094 16.9638L15.3124 14.5197L20.5172 10.5347Z"
                                                                    fill="white" />
                                                            </svg></div>
                                                        <div class="embed w-embed"><svg width="25" height="25"
                                                                viewBox="0 0 25 25" fill="none"
                                                                xmlns="http://www.w3.org/2000/svg">
                                                                <rect width="24.1379" height="24.1379"
                                                                    transform="translate(0 0.484863)" fill="#219653" />
                                                                <path
                                                                    d="M12.0689 16.9904L15.7399 16.0074L17.2736 21.002L12.0689 16.9904ZM20.5172 10.5347H14.0552L12.0689 4.10547L10.0825 10.5347H3.62061L8.85049 14.5197L6.86414 20.9489L12.094 16.9638L15.3124 14.5197L20.5172 10.5347Z"
                                                                    fill="white" />
                                                            </svg></div>
                                                    </div>
                                                </div>
                                                <div class="testimonial-logo-bottom"><a
                                                        href="https://uk.trustpilot.com/reviews/66f1fa3af2b960e237ad5445"
                                                        target="_blank" class="testimonial-link-source w-inline-block">
                                                        <div class="text-size-18 text-weight-bold set-text-size-14">
                                                            Source</div>
                                                        <div class="fix-24">
                                                            <div data-button-icon="hover" class="embed w-embed"><svg
                                                                    width="24" height="24" viewBox="0 0 24 24"
                                                                    fill="none" xmlns="http://www.w3.org/2000/svg">
                                                                    <path d="M5 12H19M19 12L12 5M19 12L12 19"
                                                                        stroke="currentColor" stroke-width="2"
                                                                        stroke-linecap="round"
                                                                        stroke-linejoin="round" />
                                                                </svg></div>
                                                            <div data-button-icon="normal" class="embed w-embed"><svg
                                                                    width="24" height="24" viewBox="0 0 24 24"
                                                                    fill="none" xmlns="http://www.w3.org/2000/svg">
                                                                    <path d="M9 18L15 12L9 6" stroke="white"
                                                                        stroke-width="2" stroke-linecap="round"
                                                                        stroke-linejoin="round" />
                                                                </svg></div>
                                                        </div>
                                                    </a>
                                                    <div><img loading="lazy"
                                                            src="https://cdn.prod.website-files.com/668b3733f80ed0dcd2c46207/668f55e450eeb735f8c47eb3_Trustpilot%20logo.png"
                                                            alt="" /></div>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="inner-line width"></div>
                                        <div class="platform-testimonial-content">
                                            <div class="embed w-embed"><svg width="48" height="49" viewBox="0 0 48 49"
                                                    fill="none" xmlns="http://www.w3.org/2000/svg">
                                                    <path d="M0 6.05371V42.0537L18 24.0537V6.05371H0Z" fill="#D5283A" />
                                                    <path d="M30 6.05371V42.0537L48 24.0537V6.05371H30Z"
                                                        fill="#D5283A" />
                                                </svg></div>
                                            <div>
                                                <div class="margin-bottom-8">
                                                    <h3>Game changer for Facebook agency accounts</h3>
                                                </div>
                                                <div class="max-width-852">
                                                    <div class="text-color-gray-300">AdsAsia is a game changer for Facebook ads. I started using their agency accounts a month ago and I am more than impressed, it's been such a great experience. The setup and process was very smooth. The dashboard is easy to use and my account manager April is always so helpful and friendly. She responds whenever I need her and helps me answer any questions. Thanks AdsAsia.</div>
                                                </div>
                                            </div>
                                            <div class="testimonial-link-box">
                                                <div class="testimonial-author-box">
                                                    <div class="text-size-18 text-weight-bold">—</div>
                                                    <div class="testimonial-box-author">
                                                        <div class="text-color-gray-300">Thomas</div>
                                                        <div class="text-color-gray-300">, </div>
                                                        <div class="text-color-gray-300">US</div>
                                                    </div>
                                                </div>
                                                <div class="hide-mobile-landscape"><a
                                                        href="https://uk.trustpilot.com/reviews/66f1fa3af2b960e237ad5445"
                                                        target="_blank" class="testimonial-link-source w-inline-block">
                                                        <div class="text-size-18 text-weight-bold">Source
                                                        </div>
                                                        <div class="fix-24">
                                                            <div data-button-icon="hover" class="embed w-embed"><svg
                                                                    width="24" height="24" viewBox="0 0 24 24"
                                                                    fill="none" xmlns="http://www.w3.org/2000/svg">
                                                                    <path d="M5 12H19M19 12L12 5M19 12L12 19"
                                                                        stroke="currentColor" stroke-width="2"
                                                                        stroke-linecap="round"
                                                                        stroke-linejoin="round" />
                                                                </svg></div>
                                                            <div data-button-icon="normal" class="embed w-embed"><svg
                                                                    width="24" height="24" viewBox="0 0 24 24"
                                                                    fill="none" xmlns="http://www.w3.org/2000/svg">
                                                                    <path d="M9 18L15 12L9 6" stroke="white"
                                                                        stroke-width="2" stroke-linecap="round"
                                                                        stroke-linejoin="round" />
                                                                </svg></div>
                                                        </div>
                                                    </a></div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div id="ts-left-arrow" class="hide w-slider-arrow-left">
                    <div class="w-icon-slider-left"></div>
                </div>
                <div id="ts-right-arrow" class="hide w-slider-arrow-right">
                    <div class="w-icon-slider-right"></div>
                </div>
                <div class="hide w-slider-nav w-round w-num"></div>
                <div class="spacer-24"></div>
                <div class="platform-slider-arrows"><a id="out-right" href="#"
                        class="platform-testimonial-arrow w-inline-block">
                        <div class="fix-24">
                            <div data-button-icon="normal" class="embed w-embed"><svg width="24" height="24"
                                    viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                                    <path d="M15 18L9 12L15 6" stroke="currentColor" stroke-width="2"
                                        stroke-linecap="round" stroke-linejoin="round" />
                                </svg></div>
                            <div data-button-icon="hover" class="embed w-embed"><svg width="24" height="24"
                                    viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                                    <path d="M19 12H5M5 12L12 19M5 12L12 5" stroke="currentColor" stroke-width="2"
                                        stroke-linecap="round" stroke-linejoin="round" />
                                </svg></div>
                        </div>
                    </a><a id="out-left" href="#" class="platform-testimonial-arrow w-inline-block">
                        <div class="fix-24">
                            <div data-button-icon="hover" class="embed w-embed"><svg width="24" height="24"
                                    viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                                    <path d="M5 12H19M19 12L12 5M19 12L12 19" stroke="currentColor" stroke-width="2"
                                        stroke-linecap="round" stroke-linejoin="round" />
                                </svg></div>
                            <div data-button-icon="normal" class="embed w-embed"><svg width="24" height="24"
                                    viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                                    <path d="M9 18L15 12L9 6" stroke="white" stroke-width="2" stroke-linecap="round"
                                        stroke-linejoin="round" />
                                </svg></div>
                        </div>
                    </a>
                    <div class="hide w-embed w-script">
                        <script>

                            const leftArrow = document.getElementById("ts-left-arrow");
                            const leftButton = document.getElementById("out-left");
                            const rightArrow = document.getElementById("ts-right-arrow");
                            const rightButton = document.getElementById("out-right");

                            leftButton.addEventListener('click', function (e) {
                                rightArrow.click();
                            });

                            rightButton.addEventListener('click', function (e) {
                                leftArrow.click();
                            });

                        </script>
                    </div>
                </div>
            </div>
            <div class="platform-testimonial-container hide">
                <div class="splide__track">
                    <div class="platform-testimonial-slider splide__list">
                        <div class="splide__slide">
                            <div class="platform-testimonial-slide">
                                <div class="max-width-312">
                                    <div class="testimonial-client-score">
                                        <div>
                                            <div class="margin-bottom-8">
                                                <div class="heading-60 line-height-1">5</div>
                                            </div>
                                            <div class="margin-bottom-16">
                                                <div class="text-size-14">Client’s score</div>
                                            </div>
                                            <div class="testimonial-rating-box">
                                                <div class="embed w-embed"><svg width="25" height="25"
                                                        viewBox="0 0 25 25" fill="none"
                                                        xmlns="http://www.w3.org/2000/svg">
                                                        <rect width="24.1379" height="24.1379"
                                                            transform="translate(0 0.484863)" fill="#219653" />
                                                        <path
                                                            d="M12.0689 16.9904L15.7399 16.0074L17.2736 21.002L12.0689 16.9904ZM20.5172 10.5347H14.0552L12.0689 4.10547L10.0825 10.5347H3.62061L8.85049 14.5197L6.86414 20.9489L12.094 16.9638L15.3124 14.5197L20.5172 10.5347Z"
                                                            fill="white" />
                                                    </svg></div>
                                                <div class="embed w-embed"><svg width="25" height="25"
                                                        viewBox="0 0 25 25" fill="none"
                                                        xmlns="http://www.w3.org/2000/svg">
                                                        <rect width="24.1379" height="24.1379"
                                                            transform="translate(0 0.484863)" fill="#219653" />
                                                        <path
                                                            d="M12.0689 16.9904L15.7399 16.0074L17.2736 21.002L12.0689 16.9904ZM20.5172 10.5347H14.0552L12.0689 4.10547L10.0825 10.5347H3.62061L8.85049 14.5197L6.86414 20.9489L12.094 16.9638L15.3124 14.5197L20.5172 10.5347Z"
                                                            fill="white" />
                                                    </svg></div>
                                                <div class="embed w-embed"><svg width="25" height="25"
                                                        viewBox="0 0 25 25" fill="none"
                                                        xmlns="http://www.w3.org/2000/svg">
                                                        <rect width="24.1379" height="24.1379"
                                                            transform="translate(0 0.484863)" fill="#219653" />
                                                        <path
                                                            d="M12.0689 16.9904L15.7399 16.0074L17.2736 21.002L12.0689 16.9904ZM20.5172 10.5347H14.0552L12.0689 4.10547L10.0825 10.5347H3.62061L8.85049 14.5197L6.86414 20.9489L12.094 16.9638L15.3124 14.5197L20.5172 10.5347Z"
                                                            fill="white" />
                                                    </svg></div>
                                                <div class="embed w-embed"><svg width="25" height="25"
                                                        viewBox="0 0 25 25" fill="none"
                                                        xmlns="http://www.w3.org/2000/svg">
                                                        <rect width="24.1379" height="24.1379"
                                                            transform="translate(0 0.484863)" fill="#219653" />
                                                        <path
                                                            d="M12.0689 16.9904L15.7399 16.0074L17.2736 21.002L12.0689 16.9904ZM20.5172 10.5347H14.0552L12.0689 4.10547L10.0825 10.5347H3.62061L8.85049 14.5197L6.86414 20.9489L12.094 16.9638L15.3124 14.5197L20.5172 10.5347Z"
                                                            fill="white" />
                                                    </svg></div>
                                                <div class="embed w-embed"><svg width="25" height="25"
                                                        viewBox="0 0 25 25" fill="none"
                                                        xmlns="http://www.w3.org/2000/svg">
                                                        <rect width="24.1379" height="24.1379"
                                                            transform="translate(0 0.484863)" fill="#219653" />
                                                        <path
                                                            d="M12.0689 16.9904L15.7399 16.0074L17.2736 21.002L12.0689 16.9904ZM20.5172 10.5347H14.0552L12.0689 4.10547L10.0825 10.5347H3.62061L8.85049 14.5197L6.86414 20.9489L12.094 16.9638L15.3124 14.5197L20.5172 10.5347Z"
                                                            fill="white" />
                                                    </svg></div>
                                            </div>
                                        </div>
                                        <div class="testimonial-logo-bottom">
                                            <div><img
                                                    src="https://cdn.prod.website-files.com/668b3733f80ed0dcd2c46207/668f55e450eeb735f8c47eb3_Trustpilot%20logo.png"
                                                    loading="lazy" alt="" /></div>
                                        </div>
                                    </div>
                                </div>
                                <div class="inner-line width"></div>
                                <div class="platform-testimonial-content">
                                    <div class="embed w-embed"><svg width="48" height="49" viewBox="0 0 48 49"
                                            fill="none" xmlns="http://www.w3.org/2000/svg">
                                            <path d="M0 6.05371V42.0537L18 24.0537V6.05371H0Z" fill="#D5283A" />
                                            <path d="M30 6.05371V42.0537L48 24.0537V6.05371H30Z" fill="#D5283A" />
                                        </svg></div>
                                    <div>
                                        <div class="margin-bottom-8">
                                            <h3>High-Quality Ad Accounts</h3>
                                        </div>
                                        <div class="text-color-gray-300">The ad accounts provided by AdsAsia
                                            Agency are of high quality. I’ve seen a significant improvement
                                            in my campaign performance since switching to their accounts.
                                            Highly recommend their services to anyone in need of reliable ad
                                            accounts.</div>
                                    </div>
                                    <div class="testimonial-link-box">
                                        <div class="testimonial-author-box">
                                            <div class="text-size-18 text-weight-bold">—</div>
                                            <div class="text-color-gray-300">Sophia Christenbury</div>
                                        </div><a href="#" class="testimonial-link-source w-inline-block">
                                            <div class="text-size-18 text-weight-bold">Source</div>
                                            <div class="embed w-embed"><svg width="24" height="25" viewBox="0 0 24 25"
                                                    fill="none" xmlns="http://www.w3.org/2000/svg">
                                                    <path d="M7 17.0793L17 7.07935M17 7.07935H7M17 7.07935V17.0793"
                                                        stroke="currentColor" stroke-width="2" stroke-linecap="round"
                                                        stroke-linejoin="round" />
                                                </svg></div>
                                        </a>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="spacer-24"></div>
                <div class="platform-slider-arrows splide__arrows"><a href="#"
                        class="platform-testimonial-arrow w-inline-block">
                        <div class="embed w-embed"><svg width="24" height="25" viewBox="0 0 24 25" fill="none"
                                xmlns="http://www.w3.org/2000/svg">
                                <path d="M19 12.0537H5M5 12.0537L12 19.0537M5 12.0537L12 5.05371" stroke="white"
                                    stroke-width="2" stroke-linecap="round" stroke-linejoin="round" />
                            </svg></div>
                    </a><a href="#" class="platform-testimonial-arrow w-inline-block">
                        <div class="embed w-embed"><svg width="24" height="25" viewBox="0 0 24 25" fill="none"
                                xmlns="http://www.w3.org/2000/svg">
                                <path d="M5 12.0537H19M19 12.0537L12 5.05371M19 12.0537L12 19.0537" stroke="white"
                                    stroke-width="2" stroke-linecap="round" stroke-linejoin="round" />
                            </svg></div>
                    </a></div>
            </div>
        </div>
    </div>
</div>

<div class="section_before-footer" >
    <div class="watermark-image-box"><img
            src="https://cdn.prod.website-files.com/668b3733f80ed0dcd2c46207/668e1d5b327f4d97705634e9_Watermark.svg"
            loading="lazy" alt="" class="full-image" /></div>
    <div class="position-relative z-2">
        <div class="padding-global">
            <div class="container-1600">
                <div class="margin-bottom-48 set-margin-bottom-32">
                    <div class="header-section" id="contact">
                        <h2 class="heading-64 text-color-gray-200">Ready to scale your digital advertising?
                        </h2>
                        <div class="text-size-20 text-color-gray-200 text-weight-medium set-text-color-gray-300">
                            Chat with our team to find the solution that you need, or sign up and onboard your company within minutes.</div>
                    </div>
                </div>
                <div class="button-wrapper">
                    <div class="button-flex-block">
                        <a style="background-color: rgb(44 51 66); border: none;"
                            href="<?php echo $config['telegram1'] ?>" target="_blank"
                            class="primary-button w-button">Telegram Channel

                            <img style="width: 30px; padding-left: 6px" src="https://cdn-icons-png.flaticon.com/512/2111/2111646.png">
                        </a>

                        <a style="background-color: rgb(44 51 66); border: none;"
                            href="<?php echo $config['telegram2'] ?>" target="_blank"
                            class="primary-button w-button">Telegram Contact

                            <img style="width: 30px; padding-left: 6px" src="https://cdn-icons-png.flaticon.com/512/2111/2111646.png">
                        </a>

                        <a style="background-color: rgb(44 51 66); border: none;"
                            href="<?php echo $config['instagram'] ?>" target="_blank"
                            class="primary-button w-button">Instagram

                            <img style="width: 30px; padding-left: 6px" src="https://cdn-icons-png.flaticon.com/512/174/174855.png">
                        </a>


                        <a style="background-color: rgb(44 51 66); border: none;"
                            href="<?php echo $config["whatsapp"] ?>" target="_blank"
                            class="primary-button w-button">Whatsapp

                            <img style="width: 30px; padding-left: 6px;" src="https://cdn-icons-png.flaticon.com/512/733/733585.png">
                        </a>

                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="gradient-box">
        <div class="w-embed">
            <style>
                .gradient-box {
                    background: linear-gradient(270deg, #c728d5, #42f4f4, #c728d5, #42f4f4);
                    background-size: 800% 800%;

                    -webkit-animation: bottomgradient 11s ease infinite;
                    -moz-animation: bottomgradient 11s ease infinite;
                    -o-animation: bottomgradient 11s ease infinite;
                    animation: bottomgradient 11s ease infinite;
                }

                @-webkit-keyframes bottomgradient {
                    0% {
                        background-position: 0% 50%
                    }

                    50% {
                        background-position: 100% 50%
                    }

                    100% {
                        background-position: 0% 50%
                    }
                }

                @-moz-keyframes bottomgradient {
                    0% {
                        background-position: 0% 50%
                    }

                    50% {
                        background-position: 100% 50%
                    }

                    100% {
                        background-position: 0% 50%
                    }
                }

                @-o-keyframes bottomgradient {
                    0% {
                        background-position: 0% 50%
                    }

                    50% {
                        background-position: 100% 50%
                    }

                    100% {
                        background-position: 0% 50%
                    }
                }

                @keyframes bottomgradient {
                    0% {
                        background-position: 0% 50%
                    }

                    50% {
                        background-position: 100% 50%
                    }

                    100% {
                        background-position: 0% 50%
                    }
                }
            </style>
        </div>
    </div>
</div>





            <div id="footer" class="footer">
    <div class="padding-global">
        <div class="container-1600">
            <div class="margin-bottom-64 set-margin-bottom-48">
                <div class="footer-component">
                    <div class="footer-main-box"><a href="/" aria-current="page" class="w-inline-block w--current">
                            <div class="footer-logo w-embed">
                                <img src="assets/logo.png" width="142" alt="Logo" class="logo-image">

                            </div>
                        </a>


                    </div>
                    <div class="footer-links-block">
                        <div class="footer-links-box hide-this">
                            <div class="margin-bottom-16">
                                <div>Home</div>
                            </div>
                            <div class="footer-links"><a href="#" class="footer-link">Overview</a><a
                                    href="/solutions/features" class="footer-link">Features</a><a
                                    href="/solutions/use-cases" class="footer-link">Solutions</a><a href="#"
                                    class="footer-link">Demo</a><a href="/pricing" class="footer-link">Pricing</a></div>
                        </div>

                        <div class="footer-links-box">
                            <div class="margin-bottom-16">
                                <div>Products</div>
                            </div>
                            <div class="footer-links">
                                <a href="/meta.php" class="footer-link">Meta</a>
                                <a href="/tiktok.php" class="footer-link">TikTok</a>
                                <a href="/google.php" class="footer-link">Google</a>

                            </div>
                        </div>
                        <div class="footer-links-box">
                            <div class="text-start d-inline-block">
                                <p class="text-lg title-follow neutral-0" style="margin-bottom: 10px;">Contact us
                                </p>
                                <div class="box-socials-footer">
                                    <a class="icon-socials icon-instagram" href="<?php echo $config["telegram1"] ?>"
                                        target="_blank">
                                        <img style="width: 32px;     padding-right: 10px;" alt="AdsAsia"
                                            src="https://static.cdnlogo.com/logos/t/39/telegram.svg"></a>
                                    <a class="icon-socials icon-instagram" href="<?php echo $config["telegram2"] ?>"
                                        target="_blank">
                                        <img style="width: 32px;     padding-right: 10px;" alt="AdsAsia"
                                            src="https://static.cdnlogo.com/logos/t/39/telegram.svg"></a>

                                            <a class="icon-socials icon-instagram" href="<?php echo $config["instagram"] ?>"
                                            target="_blank">
                                            <img style="width: 32px;     padding-right: 10px;" alt="AdsAsia"
                                                src="https://cdn-icons-png.flaticon.com/512/174/174855.png"></a>

                                    <a class="icon-socials icon-twitter" href="<?php echo $config["whatsapp"] ?>"
                                        target="_blank">
                                        <img style="width: 32px;     padding-right: 10px;" alt="AdsAsia"
                                            src="https://upload.wikimedia.org/wikipedia/commons/thumb/6/6b/WhatsApp.svg/1024px-WhatsApp.svg.png?20220228223904">
                                    </a>

                                </div>
                                <p></p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="copyright-component">
                <div class="text-color-gray-300">© <span class="year">2025</span> Adsasia. All rights
                    reserved.</div>

            </div>
        </div>
    </div>
    <div class="contact-us-overlay-wrapper">
        <div class="contact-link-wrapper"><a data-tab="contacts" href="#" class="contact-link red w-inline-block">
                <div class="embed w-embed"><svg width="44" height="44" viewBox="0 0 44 44" fill="none"
                        xmlns="http://www.w3.org/2000/svg">
                        <path
                            d="M22.0003 10C29.3337 10 35.3337 14.7733 35.3337 20.6667C35.3337 26.56 29.3337 31.3333 22.0003 31.3333C20.347 31.3333 18.7603 31.0933 17.2937 30.6667C13.4003 34 8.66699 34 8.66699 34C11.7737 30.8933 12.267 28.8 12.3337 28C10.067 26.0933 8.66699 23.5067 8.66699 20.6667C8.66699 14.7733 14.667 10 22.0003 10Z"
                            fill="white" />
                    </svg></div>
                <div class="hide">Message</div>
            </a></div>
        <div class="footer-full-link-wrapper">
            <div class="footer-contact-wrapper">
                <div class="flex-full">
                    <div class="footer-contact-links-wrapper"><a href="<?php echo $config[" whatsapp"] ?>" target="_blank"
                            class="footer-link-box w-inline-block">
                            <div class="fix-box-24">
                                <div class="embed w-embed"><svg width="21" height="22" viewBox="0 0 21 22" fill="none"
                                        xmlns="http://www.w3.org/2000/svg">
                                        <g clip-path="url(#clip0_1_13877)">
                                            <path
                                                d="M10.5026 0.5H10.4974C4.70794 0.5 0 5.20925 0 11C0 13.2969 0.74025 15.4257 1.99894 17.1543L0.690375 21.0551L4.72631 19.7649C6.38663 20.8647 8.36719 21.5 10.5026 21.5C16.2921 21.5 21 16.7894 21 11C21 5.21056 16.2921 0.5 10.5026 0.5Z"
                                                fill="#4CAF50" />
                                            <path
                                                d="M16.6123 15.3273C16.359 16.0426 15.3536 16.6359 14.5517 16.8091C14.0031 16.9259 13.2864 17.0191 10.8741 16.019C7.78838 14.7406 5.80126 11.6051 5.64638 11.4016C5.49807 11.1982 4.39951 9.7413 4.39951 8.23455C4.39951 6.7278 5.16469 5.99412 5.47313 5.67912C5.72644 5.42055 6.14513 5.30243 6.54676 5.30243C6.67669 5.30243 6.79351 5.30899 6.89851 5.31424C7.20694 5.32737 7.36182 5.34574 7.56526 5.83268C7.81857 6.44299 8.43544 7.94974 8.50894 8.10462C8.58376 8.25949 8.65857 8.46949 8.55357 8.67293C8.45513 8.88293 8.36851 8.97612 8.21363 9.15462C8.05876 9.33312 7.91176 9.46962 7.75688 9.66124C7.61513 9.82793 7.45501 10.0064 7.63351 10.3149C7.81201 10.6167 8.42888 11.6234 9.33713 12.4319C10.5092 13.4754 11.4594 13.8087 11.7994 13.9505C12.0527 14.0555 12.3546 14.0306 12.5396 13.8337C12.7746 13.5804 13.0646 13.1604 13.3599 12.7469C13.5699 12.4503 13.8351 12.4136 14.1133 12.5186C14.3968 12.617 15.897 13.3586 16.2054 13.5121C16.5139 13.667 16.7173 13.7405 16.7921 13.8704C16.8656 14.0004 16.8656 14.6107 16.6123 15.3273Z"
                                                fill="#FAFAFA" />
                                        </g>
                                        <defs>
                                            <clipPath id="clip0_1_13877">
                                                <rect width="21" height="21" fill="white"
                                                    transform="translate(0 0.5)" />
                                            </clipPath>
                                        </defs>
                                    </svg></div>
                            </div>
                            <div>WhatsApp</div>
                            <div class="fix-box-16">
                                <div class="embed footer-link w-embed"><svg width="16" height="16" viewBox="0 0 16 16"
                                        fill="none" xmlns="http://www.w3.org/2000/svg">
                                        <path
                                            d="M3.33334 7.99998H12.6667M12.6667 7.99998L8.00001 3.33331M12.6667 7.99998L8.00001 12.6666"
                                            stroke="#101828" stroke-width="1.5" stroke-linecap="round"
                                            stroke-linejoin="round" />
                                    </svg></div>
                            </div>
                        </a>
                        <div class="contact-link-line"></div><a href="<?php echo $config[" telegram"] ?>" target="_blank"
                            class="footer-link-box w-inline-block">
                            <div class="fix-box-24">
                                <div class="embed w-embed"><svg width="24" height="24" viewBox="0 0 24 24" fill="none"
                                        xmlns="http://www.w3.org/2000/svg">
                                        <path
                                            d="M11.5 23C17.299 23 22 18.299 22 12.5C22 6.70101 17.299 2 11.5 2C5.70101 2 1 6.70101 1 12.5C1 18.299 5.70101 23 11.5 23Z"
                                            fill="#039BE5" />
                                        <path
                                            d="M5.80485 12.2727L15.9286 8.36931C16.3985 8.19956 16.8089 8.48393 16.6566 9.19443L16.6575 9.19356L14.9337 17.3144C14.806 17.8902 14.4639 18.0302 13.9852 17.7589L11.3602 15.8243L10.0941 17.0441C9.9541 17.1841 9.83598 17.3022 9.56473 17.3022L9.7511 14.6308L14.6161 10.2357C14.8279 10.0493 14.5689 9.94431 14.2897 10.1298L8.27761 13.9151L5.68585 13.1066C5.12323 12.9281 5.11098 12.5439 5.80485 12.2727Z"
                                            fill="white" />
                                    </svg></div>
                            </div>
                            <div>Telegram</div>
                            <div class="fix-box-16">
                                <div class="embed footer-link w-embed"><svg width="16" height="16" viewBox="0 0 16 16"
                                        fill="none" xmlns="http://www.w3.org/2000/svg">
                                        <path
                                            d="M3.33334 7.99998H12.6667M12.6667 7.99998L8.00001 3.33331M12.6667 7.99998L8.00001 12.6666"
                                            stroke="#101828" stroke-width="1.5" stroke-linecap="round"
                                            stroke-linejoin="round" />
                                    </svg></div>
                            </div>
                        </a>
                        <div class="contact-link-line"></div><a href="mailto:<?php echo $config[" mail"] ?>"
                            class="footer-link-box w-inline-block">
                            <div class="fix-box-24">
                                <div class="embed w-embed"><svg width="24" height="24" viewBox="0 0 24 24" fill="none"
                                        xmlns="http://www.w3.org/2000/svg">
                                        <path
                                            d="M13.9229 14.2445C13.4253 14.5762 12.8472 14.7516 12.2513 14.7516C11.6553 14.7516 11.0773 14.5762 10.5796 14.2445L2.38318 8.78001C2.33771 8.7497 2.2934 8.71809 2.25 8.68559V17.6397C2.25 18.6663 3.08311 19.4811 4.09136 19.4811H20.4111C21.4377 19.4811 22.2525 18.648 22.2525 17.6397V8.68555C22.209 8.71813 22.1646 8.74981 22.119 8.78017L13.9229 14.2445Z"
                                            fill="#667085" />
                                        <path
                                            d="M3.0333 7.80479L11.2298 13.2693C11.54 13.4762 11.8956 13.5796 12.2512 13.5796C12.6068 13.5796 12.9625 13.4761 13.2727 13.2693L21.4692 7.80479C21.9597 7.47799 22.2525 6.93105 22.2525 6.34074C22.2525 5.32573 21.4267 4.5 20.4118 4.5H4.09074C3.07577 4.50004 2.25 5.32577 2.25 6.34171C2.25 6.93105 2.54285 7.47799 3.0333 7.80479Z"
                                            fill="#667085" />
                                    </svg></div>
                            </div>
                            <div>Email us</div>
                            <div class="fix-box-16">
                                <div class="embed footer-link w-embed"><svg width="16" height="16" viewBox="0 0 16 16"
                                        fill="none" xmlns="http://www.w3.org/2000/svg">
                                        <path
                                            d="M3.33334 7.99998H12.6667M12.6667 7.99998L8.00001 3.33331M12.6667 7.99998L8.00001 12.6666"
                                            stroke="#101828" stroke-width="1.5" stroke-linecap="round"
                                            stroke-linejoin="round" />
                                    </svg></div>
                            </div>
                        </a>

                    </div>
                    <div class="hide w-embed">
                        <style>
                            .footer-link-box:hover .fix-box-16 .embed {
                                transform: translateX(0);
                            }
                        </style>
                    </div>
                </div>
                <div data-tab="contact-close" class="footer-close-button">
                    <div class="embed w-embed"><svg width="32" height="32" viewBox="0 0 32 32" fill="none"
                            xmlns="http://www.w3.org/2000/svg">
                            <path d="M24 8L8 24M8 8L24 24" stroke="white" stroke-width="2" stroke-linecap="round"
                                stroke-linejoin="round" />
                        </svg></div>
                </div>
            </div>
        </div>
    </div>
</div>

        </div>
    </div>



    <script src="https://d3e54v103j8qbb.cloudfront.net/js/jquery-3.5.1.min.dc5e7f18c8.js?site=668b3733f80ed0dcd2c46207"
    type="text/javascript" integrity="sha256-9/aliU8dGd2tb6OSsuzixeV4y/faTqgFtohetphbbj0="
    crossorigin="anonymous"></script>
<script src="https://cdn.prod.website-files.com/668b3733f80ed0dcd2c46207/js/agency-aurora.schunk.4a394eb5af8156f2.js"
    type="text/javascript"></script>
<script src="https://cdn.prod.website-files.com/668b3733f80ed0dcd2c46207/js/agency-aurora.schunk.c2aa238619ecee8d.js"
    type="text/javascript"></script>
<script src="https://cdn.prod.website-files.com/668b3733f80ed0dcd2c46207/js/agency-aurora.schunk.1c7a69805f298c42.js"
    type="text/javascript"></script>
<script src="https://cdn.prod.website-files.com/668b3733f80ed0dcd2c46207/js/agency-aurora.b4d15712.822708d2ff0b0f1b.js"
    type="text/javascript"></script><!-- Auto Update Year -->

<script>
    var d = new Date();
    var n = d.getFullYear();
    $('.year').text(n);

    $('.auto-left-arrow').on('click', function (e) {
        e.preventDefault();

        var number = $(this).attr('data-button-left');

        $('.auto-left-button[data-left=' + number + ']').trigger('click');
    });

    $('.auto-right-arrow').on('click', function (e) {
        e.preventDefault();

        var number = $(this).attr('data-button-right');

        $('.auto-right-button[data-right=' + number + ']').trigger('click');
    });

    $('[data-link][data-to="Use Case"]').on('click', function (e) {
        e.preventDefault();
        var pro = window.location.protocol;
        var host = window.location.hostname;
        var url = pro + "//" + host + "/solutions/use-cases";

        var href = window.location.href;

        // detect if href are the same or not
        if (href === url) {
            toSection();
        } else {
            localStorage.setItem("is_dropdown", 'yes');
            window.location.href = url;
        }
    });

    $('[data-link][data-to="Features"]').on('click', function (e) {
        e.preventDefault();
        var pro = window.location.protocol;
        var host = window.location.hostname;
        var url = pro + "//" + host + "/solutions/features";

        var href = window.location.href;

        var link = $(this).attr('data-link');

        // detect if href are the same or not
        if (href === url) {
            localStorage.setItem("feature_to", link);
            toFeature();
        } else {
            localStorage.setItem("is_feature", 'yes');
            localStorage.setItem("feature_to", link);
            window.location.href = url;
        }
    });

    let getDropdown = localStorage.getItem("is_dropdown");

    if (getDropdown == 'yes') {
        toSection();
    }

    let getFeatureDropdown = localStorage.getItem("is_feature");
    if (getFeatureDropdown == 'yes') {
        toFeature();
    }

    function toSection() {
        $('html, body').animate({
            scrollTop: $("#business-section").offset().top
        }, 500);
        localStorage.setItem("is_dropdown", 'no');
    }

    function toFeature() {
        var link = localStorage.getItem("feature_to");
        var to = '';

        if (link == 'Agency') {
            to = 'agency-accounts';
        }

        if (link == 'Cashback') {
            to = 'cashback';
        }

        if (link == 'Dashboard') {
            to = 'dashboard';
        }

        if (link == 'Reselling') {
            to = 'reselling-program';
        }

        if (link == 'Affiliate') {
            to = 'affiliate-program';
        }

        $('html, body').animate({
            scrollTop: $("#" + to).offset().top
        }, 500);
        localStorage.setItem("is_feature", 'no');
    }

    const formSubmitEvent = (function () {
        const init = ({
            onlyWorkOnThisFormName,
            onSuccess,
            onFail
        }) => {
            $(document).ajaxComplete(function (event, xhr, settings) {
                if (settings.url.includes("https://webflow.com/api/v1/form/")) {
                    const isSuccessful = xhr.status === 200
                    const isWorkOnAllForm = onlyWorkOnThisFormName == undefined
                    const isCorrectForm = !isWorkOnAllForm && settings.data.includes(getSanitizedFormName(onlyWorkOnThisFormName));

                    if (isWorkOnAllForm) {
                        if (isSuccessful) {
                            onSuccess()
                        } else {
                            onFail()
                        }
                    } else if (isCorrectForm) {
                        if (isSuccessful) {
                            onSuccess()
                        } else {
                            onFail()
                        }
                    }
                }
            });
        }
        function getSanitizedFormName(name) {
            return name.replaceAll(" ", "+")
        }
        return {
            init
        }
    })()
    $('#subscribe-btn').on('click', function () {

        var email = $('#footer-email').val();
        let pattern = /^\b[A-Z0-9._%-]+@[A-Z0-9.-]+\.[A-Z]{2,4}\b$/i;

        if (email !== '' && pattern.test(email)) {
            $('#footer-email').attr('data-check', 'active');
            $('#subscribe-form').submit();
            return;
        }

        $('#footer-email').addClass('error');
        $('#error-message').text("Please enter a valid email address");
    });

    $('#footer-email').on('input', function () {
        $(this).removeClass('error');
        $(this).removeClass('warning');
    });

    formSubmitEvent.init({
        onlyWorkOnThisFormName: "Subscribe Form",
        onSuccess: () => {
            $('#subscribe-form').css('display', 'flex');
            $('#subscribe-success').css('display', 'none');
            $('#subscribe-error').css('display', 'none');

            if ($('#footer-email').attr('data-check') !== 'active') {
                return;
            }

            $('#footer-email').addClass('success');
            $('#error-message').text("You're in, thanks for subscribing!");
            $('#footer-email').attr('data-check', 'inactive');
        },
        onFail: () => {
            $('#footer-email').attr('data-check', 'inactive');
        }
    })

    function getURLParams(url) {
        return Object.fromEntries(new URL(url).searchParams.entries());
    }

    function setCookie(cname, cvalue, exdays) {
        const d = new Date();
        d.setTime(d.getTime() + (exdays * 24 * 60 * 60 * 1000));
        let expires = "expires=" + d.toUTCString();
        document.cookie = cname + "=" + cvalue + ";" + expires + ";path=/";
    }

    function toOnboarding(referrerName) {
        var current_url = window.location.href;
        var url_object = new URL(current_url);
        var protocol = url_object.protocol;
        var domain = url_object.hostname;
        var last = window.location.href.split("/").pop();
        var getName = referrerName;

        if (last === 'onboarding') {
            last = 'stm';
        }
        if (last === 'dubai' || last === 'awc') {
            last = 'AWDubai'
        }

        if (last === 'events') {
            //last = 'new-york'
            //last = 'europe'
            last = 'malta-2024'
        }

        // var replaceUrl = protocol + '//' + domain + '/onboarding?ref=' + last;
        var replaceUrl = 'https://vantage.agency-aurora.com/?ref=' + referrerName;
        localStorage.setItem("toUrl", replaceUrl);
        localStorage.setItem("refName", referrerName);
        localStorage.setItem("onboardingForm", true);
        if (last === 'AWDubai' || last === 'milan' || last === 'new-york' || last === 'europe' || last === 'malta-2024') {
            window.location.href = replaceUrl;
            return;
        }
        window.location.replace(replaceUrl);
    }

    $(document).ready(function () {
        var currentURL = window.location.href;
        var params = getURLParams(currentURL);
        console.log(currentURL);
        console.log(params);
        if ("ref" in params) {
            //document.cookie = "ref="+ params['ref'] +"; path=/";
            var fromURL = localStorage.getItem("toUrl");
            var refName = localStorage.getItem("refName");
            console.log("From: " + fromURL);
            console.log("Ref: " + refName);

            if (refName == 'velocityprofits') {
                document.title = "Client Onboarding | Velocity Profits";
            }

            if (currentURL === fromURL && refName !== '') {
                setCookie('ref', refName, 7);
                return;
            }

            setCookie('ref', params['ref'], 7);
            localStorage.setItem("toUrl", "");
            localStorage.setItem("refName", "");
            localStorage.setItem("onboardingForm", false);
        }
    });
</script>
<script>
    $(document).on('click', '[data-tab="contacts"]', function (e) {
        e.preventDefault();
        $(this).addClass('close');
        setTimeout(function () {
            $('.contact-link-wrapper').addClass('hide');
            $('.footer-full-link-wrapper').addClass('show');
        }, 205);

        setTimeout(function () {
            $('.footer-contact-wrapper').addClass('show');
        }, 210);
    });

    $(document).on('click', '[data-tab="contact-close"]', function (e) {
        e.preventDefault();
        $('.footer-contact-wrapper').removeClass('show');
        setTimeout(function () {
            $('.contact-link-wrapper').removeClass('hide');
            $('.footer-full-link-wrapper').removeClass('show');
        }, 205);
        setTimeout(function () {
            $('[data-tab="contacts"]').removeClass('close');
        }, 210);
    });
</script>

<script src="https://cdn.jsdelivr.net/npm/@splidejs/splide@4.1.4/dist/js/splide.min.js"></script>
<script>
    var splide = new Splide('.splide', {
        type: 'loop',
        autoWidth: true,
        autoplay: true,
        interval: 8000,
        speed: 1000,
        gap: '1.5rem',
        classes: {
            pagination: 'splide__pagination meta-hero-progress-bar',
            page: 'splide__pagination__page slider-dot',
        },
        //breakpoints: {
        //767: {
        //pagination: false,
        //autoWidth: false,
        //},
        //},
    });

    splide.mount();

    var noToggle = false;
    $(".infrastracture-box").on('mouseover', function () {
        var el = $(this);

        el.children('.ad-bg-box').css('opacity', '1');
        el.find('.infra-button').css('background-color', '#d5283a');
    });

    $(".infrastracture-box").on('mouseout', function () {
        var el = $(this);

        el.children('.ad-bg-box').css('opacity', '0');
        el.find('.infra-button').css('background-color', '#344054');
    });

    function getRandomInt(min, max, except) {
        min = Math.ceil(min);
        max = Math.floor(max);
        var num = Math.floor(Math.random() * (max - min + 1)) + min;
        if (except !== 'not') {
            while (num === except) {
                num = Math.floor(Math.random() * (max - min + 1)) + min;
            }
        }
        return num;
    }

    async function animateUserIcons(el) {
        animateIconChangeColor(el, 'F04438');
        await wait(1500);
        animateSetOpacity(el, '0')
        await wait(1500);
        animateSetOpacity(el, '1')
        animateIconChangeColor(el, '17B26A');
        await wait(1500);
        animateIconChangeColor(el, '667085');
        await wait(2000);
        animateUserIcons(el);
    }

    async function animateNotification(el) {
        el.find('[data-cashback-notification]').attr('data-appear', 'true');
        await wait(5000);
        el.find('[data-cashback-notification]').attr('data-appear', 'false');
        await wait(2500);
        animateNotification(el);
    }

    function createRandomArray(range) {
        let array = [];
        let currentIndex = range;
        for (let i = 0; i < range; i++) {
            array[i] = i;
        }

        while (currentIndex != 0) {
            // Pick a remaining element...
            let randomIndex = Math.floor(Math.random() * currentIndex);
            currentIndex--;

            // And swap it with the current element.
            [array[currentIndex], array[randomIndex]] = [
                array[randomIndex], array[currentIndex]];
        }
        return array;
    }

    function observeUserIconMutation(el) {
        var config = { attributes: true, childList: true, characterData: true };

        el.find('[data-animate-user-icon]').each(function () {
            var target = this;
            var observer = new MutationObserver(function (mutations) {
                mutations.forEach(function (mutation) {
                    console.log(target.style.offsetDistance);
                    if (target) {

                    }
                });
            });

            observer.observe(target, config);
        });
    }

    function animateIconChangeColor(el, color) {
        let icon1 = el.find('[data-animation-user-icon="6"]');
        let icon2 = el.find('[data-animation-user-icon="17"]');
        let icon3 = el.find('[data-animation-user-icon="22"]');
        icon1.find('rect').css('fill', '#' + color);
        icon2.find('rect').css('fill', '#' + color);
        icon3.find('rect').css('fill', '#' + color);
    }

    function animateSetOpacity(el, opaque) {
        let icon1 = el.find('[data-animation-user-icon="6"]');
        let icon2 = el.find('[data-animation-user-icon="17"]');
        let icon3 = el.find('[data-animation-user-icon="22"]');
        icon1.css('opacity', opaque);
        icon2.css('opacity', opaque);
        icon3.css('opacity', opaque);
    }

    function opacityOn(el, display) {
        if (display === undefined) {
            display = 'block';
        }

        el.css('opacity', '0');
        el.css('display', display);

        el.animate({
            opacity: "1",
        }, 200, 'linear');
    }

    function opacityOff(el) {
        el.animate({
            opacity: "0",
        }, 200, 'linear', function () {
            el.css('display', 'none');
        });
    }

    function scaleUp(el) {
        el.css('transform', 'scale(0)');
        el.css('display', 'block');
        el.css('borderSpacing', 1).animate({
            borderSpacing: 1.3
        }, {
            step: function (now, fx) {
                $(this).css('transform', 'scale(1)');
            },
            duration: 'fast'
        });
    }

    var buttonPlays = 0;

    function wait(seconds) {
        return new Promise(resolve => {
            setTimeout(resolve, seconds);
        });
    }

    function scaleDown(el) {
        el.css('borderSpacing', 1).animate({
            borderSpacing: 1
        }, {
            step: function (now, fx) {
                var inside = $(this);
                inside.css('transform', 'scale(0)');
                setTimeout(function () {
                    inside.css('display', 'none');
                }, 300);
            },
            duration: 'fast',
        });
    }

    $.fn.isInViewport = function () {
        let elementTop = $(this).offset().top;
        let elementBottom = elementTop + $(this).outerHeight();

        let viewportTop = $(window).scrollTop();
        let viewportBottom = viewportTop + window.innerHeight;

        return elementBottom > viewportTop && elementTop < viewportBottom;
    };

    let hasBeenAnimated = false;

    function animate() {
        $('.counter-number').each(function () {
            $(this).prop('Counter', 0).animate({
                Counter: $(this).text()
            }, {
                duration: 1500,
                easing: 'swing',
                step: function (now) {
                    $(this).text(Math.ceil(now));
                }
            });
        });
    }

    async function adSectionAnimate() {
        firstAd();
        await wait(150);
        secondAd();
        await wait(150);
        thirdAd();
        await wait(150);
        fourthAd();
    }

    async function firstAd() {
        $('[data-anim-ad-box=1]').attr('data-show', 'true');
        await wait(300);
        $('[data-whitelist-content=1]').attr('data-show', 'true');
        await wait(300);
        // the animations
        $('[data-whitelist-logo="aurora"]').attr('data-show', 'true');
        await wait(200);
        var delay = 100;
        for (let i = 1; i <= 7; i++) {
            $('[data-whitelist-logo="' + i + '"]').attr('data-show', 'true');
            await wait(delay);
        }
    }

    async function secondAd() {
        $('[data-anim-ad-box=2]').attr('data-show', 'true');
        // number counter
        await wait(300);
        $('[data-whitelist-content=2]').attr('data-show', 'true');
        await wait(300);
        $('[data-whitelist-content="second"]').attr('data-show', 'true');
        await wait(150);
        $('[data-whitelist-number="7"]').prop('Counter', 0).animate({
            Counter: 7
        }, {
            duration: 800,
            easing: 'swing',
            step: function (now) {
                $(this).text(Math.ceil(now));
            }
        });
    }

    async function thirdAd() {
        $('[data-anim-ad-box=3]').attr('data-show', 'true');
        // ??
        await wait(300);
        $('[data-whitelist-content=3]').attr('data-show', 'true');
        await wait(150);
        $('[data-whitelist-image-box="image"]').attr('data-show', 'true');
    }

    async function fourthAd() {
        $('[data-anim-ad-box=4]').attr('data-show', 'true');
        // ??
        await wait(300);
        $('[data-whitelist-content=4]').attr('data-show', 'true');
        await wait(120);
        animateSvg();
    }

    function detectOffset(el) {
        let f = $(el).offset().top - $(window).scrollTop();
        return f;
    }

    $(window).scroll(function () {
        if ($('.scale-component').isInViewport() && !hasBeenAnimated) {
            hasBeenAnimated = true;
            animate();
        }

        if ($('[data-anim-container="advertising"]').isInViewport && $('[data-anim-container="advertising"]').attr('data-show') === "false") {
            let getOffset = detectOffset('[data-anim-container="advertising"]');
            if (getOffset <= 120) {
                $('[data-anim-container="advertising"]').attr('data-show', 'true');
                adSectionAnimate();
            }
        }

        $('[data-feature-image-box][data-show="false"]').each(function () {
            var el = $(this);
            var num = el.attr('data-anim-show-up');
            let getOffset = detectOffset('[data-anim-show-up="' + num + '"]');

            if (getOffset <= 300) {
                el.attr('data-show', 'true');
            }
        });

        $('[data-anim-show-up][data-show="false"]').each(function () {
            var el = $(this);
            var num = el.attr('data-anim-show-up');
            let getOffset = detectOffset('[data-anim-show-up="' + num + '"]');
            let height = screen.height;
            let percent = height * 0.80; // 85 percent

            if (getOffset <= percent) {
                console.log("yes");
                el.attr('data-show', 'true');
            }
        });
    });

    $('[svg="animated"]').css({
        opacity: 0,
        transition: "opacity 400ms ease"
    });

    function animateSvg(el) {
        $('[svg="animated"] path').each(function () {
            var pathLength = this.getTotalLength();
            $(this).attr({
                "stroke-dasharray": pathLength,
                "stroke-dashoffset": pathLength
            });
            var svgAnimated = $(this).closest('[svg="animated"]');
            var animationDuration = svgAnimated.attr('svg-animation-time') || 5000;
            $(svgAnimated).css("opacity", 1);
            $(this).css({
                transition: "stroke-dashoffset " + animationDuration + "ms ease-out",
                "stroke-dashoffset": 0
            });

        });
    }


    function scrollToContact() {
        $('html, body').animate({
            scrollTop: $('#contact').offset().top
        }, 600); // 600ms là thời gian scroll
    }

</script>

    






</body>

</html>











